# Cómo sacar una versión nueva de RecLite

La app revisa los *Releases* de GitHub (`Updater.REPO`, hoy `Victordelaxx33/RecLite`).

1. En `app/build.gradle` sube `versionName` (ej. `"2.9"`) y `versionCode` (+1).
2. Compila el APK.
3. En GitHub: **Releases → Draft a new release**.
   - Tag: `v2.9` (el número debe coincidir con `versionName`).
   - Título: lo que quieras, ej. `RecLite 2.9`.
   - Descripción: los cambios, una línea por cambio con `- ` al inicio. Eso es lo que verán los usuarios en el botón de novedades (el periódico).
   - Adjunta el `.apk` al release (el botón **Descargar** lo usa; si no hay APK abre la página del release).
4. **Publish release**.

Los usuarios con una versión menor verán un aviso al abrir la app y un punto rojo en el botón del periódico.

## Telegram
Telegram no deja leer un canal desde la app sin un bot, así que el aviso va por GitHub.
Publica también el mensaje en tu canal y pon el enlace en `Updater.TELEGRAM_URL`
(ej. `"https://t.me/tucanal"`): saldrá un botón "Canal de Telegram" en las novedades.

## Si tu repositorio se llama distinto
Cambia `Updater.REPO` en `app/src/main/java/com/leo/grabapantalla/Updater.java`.
El repositorio debe ser público para que la app pueda leerlo sin cuenta.
