package com.leo.grabapantalla;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Iconos dibujados con Canvas (sin recursos). Cuadricula de 24x24. */
public class IconView extends View {
    public static final int REC = 0, STOP = 1, PAUSE = 2, PLAY = 3, SETTINGS = 4, LIBRARY = 5, SHARE = 6, TRASH = 7,
            EDIT = 8, IMAGE = 9, MIC = 10, MICOFF = 11, SPEED = 12, STORAGE = 13, CHIP = 14, SHAKE = 15, CHECK = 16,
            TIMER = 17, PALETTE = 18, BOLT = 19, INFO = 20, RES = 21, LOGO = 22, VIDEO = 23, STACK = 24, RESET = 25, SPEAKER = 26,
            STAR = 27, GAME = 28, LEAF = 29, HELP = 30, CHEVRON = 31, SCALE = 32, BELL = 33, OVERLAY = 34, CUT = 35, TIKTOK = 36, DISCORD = 37, NEWS = 38;

    int type, color;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    RectF rf = new RectF();
    Path path = new Path();

    public IconView(Context c, int type, int color) {
        super(c);
        this.type = type;
        this.color = color;
    }

    public void setColor(int c) { color = c; invalidate(); }
    public void setType(int t) { type = t; invalidate(); }

    void stroke(float w) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); }
    void fill() { p.setStyle(Paint.Style.FILL); }
    void fillRound() { p.setStyle(Paint.Style.FILL_AND_STROKE); p.setStrokeWidth(1.6f); p.setStrokeJoin(Paint.Join.ROUND); }
    void rr(Canvas c, float l, float t, float r, float b, float rad) { rf.set(l, t, r, b); c.drawRoundRect(rf, rad, rad, p); }
    void ln(Canvas c, float a, float b, float x, float y) { c.drawLine(a, b, x, y, p); }
    void poly(Canvas c, boolean close, float... v) {
        path.reset();
        path.moveTo(v[0], v[1]);
        for (int i = 2; i < v.length; i += 2) path.lineTo(v[i], v[i + 1]);
        if (close) path.close();
        c.drawPath(path, p);
    }

    @Override protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight()) / 24f;
        c.save();
        c.translate((getWidth() - 24 * s) / 2f, (getHeight() - 24 * s) / 2f);
        c.scale(s, s);
        p.setShader(null);
        p.setColor(color);
        switch (type) {
            case REC: stroke(2); c.drawCircle(12, 12, 9, p); fill(); c.drawCircle(12, 12, 5, p); break;
            case STOP: fill(); rr(c, 6, 6, 18, 18, 2.5f); break;
            case PAUSE: fill(); rr(c, 6, 5, 10.5f, 19, 1.2f); rr(c, 13.5f, 5, 18, 19, 1.2f); break;
            case PLAY: fillRound(); poly(c, true, 8, 5.5f, 18.5f, 12, 8, 18.5f); break;
            case SETTINGS:
                stroke(2); c.drawCircle(12, 12, 6.4f, p); c.drawCircle(12, 12, 2.4f, p);
                stroke(3.2f);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    float cx = (float) Math.cos(a), cy = (float) Math.sin(a);
                    ln(c, 12 + cx * 8f, 12 + cy * 8f, 12 + cx * 9.6f, 12 + cy * 9.6f);
                }
                break;
            case LIBRARY: stroke(2); rr(c, 3, 5, 21, 19, 3.5f); fillRound(); poly(c, true, 10, 9.4f, 15, 12, 10, 14.6f); break;
            case SHARE:
                stroke(1.8f); ln(c, 8.3f, 10.8f, 15.7f, 6.7f); ln(c, 8.3f, 13.2f, 15.7f, 17.3f);
                fill(); c.drawCircle(18, 5.5f, 2.8f, p); c.drawCircle(6, 12, 2.8f, p); c.drawCircle(18, 18.5f, 2.8f, p);
                break;
            case TRASH:
                stroke(2); ln(c, 4.5f, 7, 19.5f, 7); poly(c, false, 9, 7, 9, 4.5f, 15, 4.5f, 15, 7);
                rr(c, 6.5f, 7, 17.5f, 20, 2.2f); ln(c, 10, 11, 10, 16); ln(c, 14, 11, 14, 16);
                break;
            case EDIT:
                stroke(1.9f); poly(c, true, 4, 20, 5, 15.5f, 16, 4.5f, 19.5f, 8, 8.5f, 19); ln(c, 14, 6.5f, 17.5f, 10);
                break;
            case IMAGE:
                stroke(2); rr(c, 3, 4, 21, 20, 3); poly(c, false, 4, 18, 9.5f, 12.5f, 13, 16, 15.5f, 13.5f, 20, 18);
                fill(); c.drawCircle(8.5f, 9.5f, 1.8f, p);
                break;
            case MIC: case MICOFF:
                stroke(2); rr(c, 9, 3, 15, 14, 3); rf.set(6, 6, 18, 18); c.drawArc(rf, 0, 180, false, p);
                ln(c, 12, 18, 12, 21); ln(c, 9, 21, 15, 21);
                if (type == MICOFF) { p.setColor(Theme.REC_SOFT); stroke(2.2f); ln(c, 4.5f, 4.5f, 19.5f, 19.5f); }
                break;
            case SPEED:
                stroke(2); rf.set(3, 5, 21, 23); c.drawArc(rf, 180, 180, false, p); ln(c, 12, 14, 17, 8.5f);
                fill(); c.drawCircle(12, 14, 1.7f, p);
                break;
            case STORAGE: stroke(2); rr(c, 3, 6, 21, 18, 3.5f); ln(c, 7, 12, 8, 12); ln(c, 11.5f, 12, 17, 12); break;
            case CHIP:
                stroke(2); rr(c, 7, 7, 17, 17, 2);
                stroke(1.8f);
                ln(c, 10, 3.5f, 10, 7); ln(c, 14, 3.5f, 14, 7); ln(c, 10, 17, 10, 20.5f); ln(c, 14, 17, 14, 20.5f);
                ln(c, 3.5f, 10, 7, 10); ln(c, 3.5f, 14, 7, 14); ln(c, 17, 10, 20.5f, 10); ln(c, 17, 14, 20.5f, 14);
                break;
            case SHAKE:
                stroke(2); rr(c, 8, 3.5f, 16, 20.5f, 2.5f);
                ln(c, 4.5f, 9, 4.5f, 15); ln(c, 19.5f, 9, 19.5f, 15); ln(c, 1.8f, 10.5f, 1.8f, 13.5f); ln(c, 22.2f, 10.5f, 22.2f, 13.5f);
                break;
            case CUT:
                stroke(2); c.drawCircle(6.5f, 17.5f, 2.6f, p); c.drawCircle(17.5f, 17.5f, 2.6f, p);
                ln(c, 8.3f, 15.6f, 18.5f, 4f); ln(c, 15.7f, 15.6f, 5.5f, 4f);
                break;
            case CHECK: stroke(2.4f); poly(c, false, 5, 12.5f, 10, 17.5f, 19, 7); break;
            case TIMER:
                stroke(2); c.drawCircle(12, 13.5f, 8, p); ln(c, 12, 13.5f, 12, 9); ln(c, 9.5f, 2.8f, 14.5f, 2.8f);
                break;
            case PALETTE:
                stroke(2); c.drawCircle(12, 12, 9, p); fill();
                c.drawCircle(8, 10, 1.5f, p); c.drawCircle(12, 7.5f, 1.5f, p); c.drawCircle(16, 10, 1.5f, p); c.drawCircle(9.5f, 15, 1.5f, p);
                break;
            case BOLT: fillRound(); poly(c, true, 13, 2.5f, 5.5f, 13, 11.5f, 13, 10.5f, 21.5f, 18.5f, 10.5f, 12.5f, 10.5f); break;
            case INFO: stroke(2); c.drawCircle(12, 12, 9, p); ln(c, 12, 11, 12, 16.5f); fill(); c.drawCircle(12, 7.9f, 1.25f, p); break;
            case RES:
                stroke(2.2f);
                poly(c, false, 4, 9, 4, 4, 9, 4); poly(c, false, 15, 4, 20, 4, 20, 9);
                poly(c, false, 20, 15, 20, 20, 15, 20); poly(c, false, 9, 20, 4, 20, 4, 15);
                break;
            case VIDEO: stroke(2); rr(c, 3, 6, 16, 18, 3); fillRound(); poly(c, true, 16, 10.5f, 21, 7.5f, 21, 16.5f, 16, 13.5f); break;
            case STACK: stroke(2.2f); ln(c, 4, 7, 20, 7); ln(c, 4, 12, 20, 12); ln(c, 4, 17, 14, 17); break;
            case RESET: stroke(2); rf.set(4.5f, 4.5f, 19.5f, 19.5f); c.drawArc(rf, 30, 280, false, p); poly(c, false, 17.5f, 2.5f, 17.5f, 7, 13, 7); break;
            case SPEAKER:
                fillRound(); poly(c, true, 4, 9.5f, 8, 9.5f, 12.5f, 5.5f, 12.5f, 18.5f, 8, 14.5f, 4, 14.5f);
                stroke(2); rf.set(7, 7, 17, 17); c.drawArc(rf, -45, 90, false, p); rf.set(4, 4, 20, 20); c.drawArc(rf, -45, 90, false, p);
                break;
            case STAR:
                fillRound(); path.reset();
                for (int i = 0; i < 10; i++) {
                    double a = -Math.PI / 2 + i * Math.PI / 5;
                    float r = (i % 2 == 0) ? 9.3f : 4.1f;
                    float x = 12 + (float) Math.cos(a) * r, y = 12.8f + (float) Math.sin(a) * r;
                    if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
                }
                path.close(); c.drawPath(path, p);
                break;
            case GAME:
                stroke(2); rr(c, 2.5f, 7, 21.5f, 18, 5);
                ln(c, 7.5f, 10, 7.5f, 15); ln(c, 5, 12.5f, 10, 12.5f);
                fill(); c.drawCircle(16, 11.2f, 1.3f, p); c.drawCircle(18.5f, 14, 1.3f, p);
                break;
            case LEAF:
                stroke(2); path.reset(); path.moveTo(5, 19); path.quadTo(3.5f, 7.5f, 19.5f, 4.5f); path.quadTo(20.5f, 17.5f, 5, 19); path.close();
                c.drawPath(path, p); ln(c, 5, 19, 13, 11);
                break;
            case HELP:
                stroke(2); c.drawCircle(12, 12, 9, p);
                rf.set(8.8f, 6.5f, 15.2f, 12.5f); c.drawArc(rf, 180, 270, false, p);
                ln(c, 12, 12.5f, 12, 14.3f);
                fill(); c.drawCircle(12, 17.3f, 1.2f, p);
                break;
            case NEWS:
                stroke(2); rr(c, 3.5f, 4.5f, 20.5f, 19.5f, 3f);
                fill(); rr(c, 6.5f, 8f, 11.5f, 12.5f, 1f);
                stroke(2); ln(c, 14, 9, 17.5f, 9); ln(c, 14, 12.5f, 17.5f, 12.5f); ln(c, 6.5f, 16, 17.5f, 16);
                break;
            case CHEVRON: stroke(2.4f); poly(c, false, 9, 5, 16, 12, 9, 19); break;
            case SCALE:
                stroke(2); ln(c, 12, 4, 12, 19); ln(c, 7, 20, 17, 20); ln(c, 5, 7.5f, 19, 7.5f);
                ln(c, 6, 7.5f, 6, 12); ln(c, 18, 7.5f, 18, 12);
                rf.set(3, 9, 9, 15); c.drawArc(rf, 0, 180, false, p);
                rf.set(15, 9, 21, 15); c.drawArc(rf, 0, 180, false, p);
                break;
            case BELL:
                stroke(2); rf.set(6, 4.5f, 18, 16.5f); c.drawArc(rf, 180, 180, false, p);
                ln(c, 6, 10.5f, 6, 16); ln(c, 18, 10.5f, 18, 16); ln(c, 4.5f, 17.5f, 19.5f, 17.5f);
                fill(); c.drawCircle(12, 20.3f, 1.4f, p);
                break;
            case OVERLAY:
                stroke(2); rr(c, 3, 4, 15, 15, 2.5f); rr(c, 9, 9, 21, 20, 2.5f);
                break;
            case TIKTOK:
                stroke(2.2f); ln(c, 13.2f, 4, 13.2f, 15.6f); c.drawCircle(10, 16.6f, 3.2f, p);
                path.reset(); path.moveTo(13.2f, 4); path.cubicTo(13.6f, 6.6f, 15.6f, 8.1f, 18.8f, 8.3f); c.drawPath(path, p);
                break;
            case DISCORD:
                stroke(2); rr(c, 3.5f, 6, 20.5f, 17, 5.5f); ln(c, 8, 17, 6.5f, 19.5f); ln(c, 16, 17, 17.5f, 19.5f);
                fill(); c.drawCircle(9, 11.6f, 1.6f, p); c.drawCircle(15, 11.6f, 1.6f, p);
                break;
            case LOGO:
                c.restore();
                drawLogo(c);
                return;
        }
        c.restore();
    }

    void drawLogo(Canvas c) {
        float w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, w, h, Theme.PRI, Theme.PRI_C, Shader.TileMode.CLAMP));
        rf.set(0, 0, w, h);
        c.drawRoundRect(rf, w * 0.3f, w * 0.3f, p);
        p.setShader(null);
        p.setColor(Theme.ON_PRI_C);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w * 0.07f);
        rf.set(w * 0.3f, w * 0.2f, w * 0.7f, w * 0.8f);
        c.drawRoundRect(rf, w * 0.1f, w * 0.1f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Theme.REC);
        c.drawCircle(w / 2f, h / 2f, w * 0.1f, p);
    }
}
