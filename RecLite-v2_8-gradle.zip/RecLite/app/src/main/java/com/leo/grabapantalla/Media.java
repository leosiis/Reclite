package com.leo.grabapantalla;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.LruCache;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Media {
    public static class Info { public Bitmap thumb; public long dur, bitrate; public int w, h, fps; public String codec = ""; }
    public interface Cb { void done(Info i); }
    public interface Done { void done(boolean ok); }

    static final ExecutorService EX = Executors.newSingleThreadExecutor();
    static final Handler UI = new Handler(Looper.getMainLooper());
    static final LruCache<String, Info> CACHE = new LruCache<String, Info>(24);

    static String key(File f) { return f.getAbsolutePath() + "|" + f.lastModified() + "|" + f.length(); }

    public static void load(final File f, final Cb cb) {
        final String k = key(f);
        Info c = CACHE.get(k);
        if (c != null) { cb.done(c); return; }
        EX.execute(new Runnable() {
            public void run() {
                final Info i = new Info();
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                try {
                    r.setDataSource(f.getAbsolutePath());
                    i.dur = parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
                    i.w = (int) parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                    i.h = (int) parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                    i.bitrate = parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE));
                    if (android.os.Build.VERSION.SDK_INT >= 28 && i.dur > 0) {
                        long fc = parse(r.extractMetadata(32));   // METADATA_KEY_VIDEO_FRAME_COUNT
                        if (fc > 0) i.fps = (int) Math.round(fc * 1000.0 / i.dur);
                    }
                    try {
                        MediaExtractor ex = new MediaExtractor();
                        try {
                            ex.setDataSource(f.getAbsolutePath());
                            for (int t = 0; t < ex.getTrackCount(); t++) {
                                String mm = ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME);
                                if (mm != null && mm.startsWith("video/")) {
                                    i.codec = mm.contains("hevc") ? "HEVC" : (mm.contains("avc") ? "H.264" : mm.substring(6).toUpperCase(Locale.US));
                                    if (i.fps == 0 && ex.getTrackFormat(t).containsKey(MediaFormat.KEY_FRAME_RATE))
                                        i.fps = ex.getTrackFormat(t).getInteger(MediaFormat.KEY_FRAME_RATE);
                                    break;
                                }
                            }
                        } finally { try { ex.release(); } catch (Throwable x) {} }
                    } catch (Throwable x) {}
                    Bitmap b = r.getFrameAtTime(300000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (b == null) b = r.getFrameAtTime();
                    if (b != null) {
                        int m = Math.max(b.getWidth(), b.getHeight());
                        if (m > 180) {
                            float sc = 180f / m;
                            b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)),
                                    Math.max(1, Math.round(b.getHeight() * sc)), true);
                        }
                        i.thumb = b;
                    }
                } catch (Throwable e) {
                } finally {
                    try { r.release(); } catch (Throwable e) {}
                }
                CACHE.put(k, i);
                UI.post(new Runnable() { public void run() { cb.done(i); } });
            }
        });
    }

    /** "1080×2400 · 60 fps · HEVC · 12.4 Mbps" con lo que se pueda saber del archivo. */
    public static String spec(Info i) {
        StringBuilder b = new StringBuilder();
        if (i.w > 0) b.append(i.w).append("×").append(i.h);
        if (i.fps > 0) b.append(b.length() > 0 ? " · " : "").append(i.fps).append(" fps");
        if (i.codec.length() > 0) b.append(b.length() > 0 ? " · " : "").append(i.codec);
        if (i.bitrate > 0) b.append(b.length() > 0 ? " · " : "").append(String.format(Locale.US, "%.1f", i.bitrate / 1000000.0)).append(" Mbps");
        return b.toString();
    }

    static long parse(String s) {
        try { return Long.parseLong(s); } catch (Exception e) { return 0; }
    }

    public static File[] list(Context c) {
        File[] fs = Cfg.dir(c).listFiles(new FilenameFilter() {
            public boolean accept(File d, String n) { return n.endsWith(".mp4"); }
        });
        if (fs == null) return new File[0];
        Arrays.sort(fs, new Comparator<File>() {
            public int compare(File a, File b) {
                long x = a.lastModified(), y = b.lastModified();
                return x < y ? 1 : (x > y ? -1 : 0);
            }
        });
        return fs;
    }

    public static boolean canExport(Context c) {
        return android.os.Build.VERSION.SDK_INT >= 29 || android.os.Build.VERSION.SDK_INT < 23
                || c.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED;
    }

    /** Copia a Movies/GrabaPantalla (bloqueante). */
    public static void exportSync(Context c, File f) throws Exception {
        OutputStream os;
        File o = null;
        Uri u = null;
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put("_display_name", f.getName());
            v.put("mime_type", "video/mp4");
            v.put("relative_path", "Movies/GrabaPantalla");
            v.put("is_pending", 1);
            u = c.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new Exception("insert");
            os = c.getContentResolver().openOutputStream(u);
        } else {
            File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "GrabaPantalla");
            d.mkdirs();
            o = new File(d, f.getName());
            os = new FileOutputStream(o);
        }
        InputStream is = new FileInputStream(f);
        byte[] buf = new byte[65536];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        is.close();
        os.close();
        if (u != null) {
            ContentValues v = new ContentValues();
            v.put("is_pending", 0);
            c.getContentResolver().update(u, v, null, null);
        }
        if (o != null) MediaScannerConnection.scanFile(c, new String[]{o.getPath()}, null, null);
    }

    public static void export(final Context c, final File f, final Done cb) {
        new Thread(new Runnable() {
            public void run() {
                boolean ok;
                try { exportSync(c, f); ok = true; } catch (Exception e) { ok = false; }
                final boolean r = ok;
                UI.post(new Runnable() { public void run() { cb.done(r); } });
            }
        }).start();
    }

    // ---------- formatos ----------

    public static String bytes(long b) {
        if (b >= 1073741824L) return String.format(Locale.US, "%.1f GB", b / 1073741824.0);
        return String.format(Locale.US, "%.0f MB", b / 1048576.0);
    }

    public static String time(long s) {
        return s >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                : String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    public static String when(long ts) {
        Calendar a = Calendar.getInstance(), b = Calendar.getInstance();
        b.setTimeInMillis(ts);
        String hm = new SimpleDateFormat("HH:mm", Locale.US).format(new Date(ts));
        int d = a.get(Calendar.DAY_OF_YEAR) - b.get(Calendar.DAY_OF_YEAR);
        if (a.get(Calendar.YEAR) == b.get(Calendar.YEAR)) {
            if (d == 0) return "Hoy " + hm;
            if (d == 1) return "Ayer " + hm;
        }
        return new SimpleDateFormat("d MMM HH:mm", new Locale("es")).format(new Date(ts));
    }
}
