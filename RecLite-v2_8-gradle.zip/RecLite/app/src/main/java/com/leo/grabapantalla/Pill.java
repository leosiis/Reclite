package com.leo.grabapantalla;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

/** Aviso inferior redondeado y negro (reemplaza al Toast normal). */
public class Pill {
    static Toast cur;

    public static void show(Context c, String msg, boolean lng) {
        try {
            Context a = c.getApplicationContext() != null ? c.getApplicationContext() : c;
            float d = a.getResources().getDisplayMetrics().density;
            TextView tv = new TextView(a);
            tv.setText(msg);
            tv.setTextColor(0xFFFFFFFF);
            tv.setTextSize(14);
            tv.setGravity(Gravity.CENTER);
            Fonts.init(a);
            tv.setTypeface(Fonts.semi);
            tv.setMaxWidth((int) (a.getResources().getDisplayMetrics().widthPixels * 0.86f));
            tv.setPadding((int) (20 * d), (int) (12 * d), (int) (20 * d), (int) (12 * d));
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF000000);
            g.setCornerRadius(28 * d);
            g.setStroke((int) Math.max(1, d), 0x33FFFFFF);
            tv.setBackground(g);
            if (cur != null) { try { cur.cancel(); } catch (Throwable e) {} }
            Toast t = new Toast(a);
            t.setView(tv);
            t.setDuration(lng ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT);
            t.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, (int) (96 * d));
            cur = t;
            t.show();
        } catch (Throwable e) {
            Toast.makeText(c, msg, lng ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show();
        }
    }
}
