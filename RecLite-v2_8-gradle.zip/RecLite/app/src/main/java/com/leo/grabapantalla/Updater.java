package com.leo.grabapantalla;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Avisos de versiones nuevas y novedades, leidos de los "Releases" de GitHub.
 *
 * COMO SACAR UNA VERSION NUEVA:
 *  1) Sube versionName / versionCode en app/build.gradle (ej. "2.8").
 *  2) En GitHub: Releases > "Draft a new release" > Tag "v2.8" (o "2.8").
 *  3) En el titulo y la descripcion escribe los cambios (lista con "- ").
 *  4) Adjunta el .apk como archivo del release (el boton Descargar lo usa; si no hay, abre el release).
 *  5) Publica. Los usuarios veran el aviso al abrir la app y el punto rojo en el boton de novedades.
 *
 * Si usas Telegram, pon el enlace de tu canal en TELEGRAM_URL y saldra un boton en las novedades.
 */
public class Updater {
    /** "usuario/repositorio" de GitHub donde publicas los releases. CAMBIALO si tu repo se llama distinto. */
    public static final String REPO = "Victordelaxx33/RecLite";
    /** Enlace de tu canal de Telegram (ej. "https://t.me/tucanal"). Vacio = no se muestra el boton. */
    public static final String TELEGRAM_URL = "";

    static final long EVERY = 6L * 3600L * 1000L;   // revisa como mucho cada 6 h (salvo al abrir las novedades)

    public static class Rel {
        public String tag = "", name = "", body = "", url = "", apk = "", date = "";
    }

    public interface Cb { void done(ArrayList<Rel> list, boolean online); }

    public static String releasesPage() { return "https://github.com/" + REPO + "/releases"; }

    /** versionName instalada, ej. "2.7". */
    public static String current(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; }
        catch (Throwable e) { return "0"; }
    }

    static int[] nums(String v) {
        ArrayList<Integer> r = new ArrayList<Integer>();
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i <= v.length(); i++) {
            char ch = i < v.length() ? v.charAt(i) : ' ';
            if (ch >= '0' && ch <= '9') cur.append(ch);
            else if (cur.length() > 0) {
                try { r.add(Integer.valueOf(Integer.parseInt(cur.toString()))); } catch (Throwable e) { r.add(Integer.valueOf(0)); }
                cur.setLength(0);
            }
        }
        int[] o = new int[r.size()];
        for (int i = 0; i < o.length; i++) o[i] = r.get(i).intValue();
        return o;
    }

    /** >0 si a es mas nueva que b ("v2.10" > "2.9"). */
    public static int cmp(String a, String b) {
        int[] x = nums(a), y = nums(b);
        int n = Math.max(x.length, y.length);
        for (int i = 0; i < n; i++) {
            int p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0;
            if (p != q) return p > q ? 1 : -1;
        }
        return 0;
    }

    public static boolean isNewer(Context c, Rel r) { return r != null && cmp(r.tag, current(c)) > 0; }

    /** Release mas nuevo de la lista (la API ya los da del mas reciente al mas viejo, pero comparamos por si acaso). */
    public static Rel latest(ArrayList<Rel> l) {
        Rel best = null;
        for (int i = 0; i < l.size(); i++) if (best == null || cmp(l.get(i).tag, best.tag) > 0) best = l.get(i);
        return best;
    }

    /** Ultimo release guardado de la vez anterior (sin red). */
    public static Rel cachedLatest(Context c) {
        try { return latest(parse(c.getSharedPreferences("upd", 0).getString("json", "[]"))); }
        catch (Throwable e) { return null; }
    }

    public static void load(final Activity a, final boolean force, final Cb cb) {
        final SharedPreferences p = a.getSharedPreferences("upd", 0);
        final long last = p.getLong("t", 0);
        if (!force && System.currentTimeMillis() - last < EVERY && p.contains("json")) {
            try { cb.done(parse(p.getString("json", "[]")), true); return; } catch (Throwable e) {}
        }
        new Thread(new Runnable() {
            public void run() {
                ArrayList<Rel> res = null;
                boolean online = false;
                try {
                    String txt = get("https://api.github.com/repos/" + REPO + "/releases?per_page=10");
                    res = parse(txt);
                    p.edit().putString("json", txt).putLong("t", System.currentTimeMillis()).apply();
                    online = true;
                } catch (Throwable e) {
                    try { res = parse(p.getString("json", "[]")); } catch (Throwable e2) { res = new ArrayList<Rel>(); }
                }
                final ArrayList<Rel> fr = res;
                final boolean fo = online;
                a.runOnUiThread(new Runnable() { public void run() { if (!a.isFinishing()) cb.done(fr, fo); } });
            }
        }).start();
    }

    static String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", "RecLite");
        if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
        InputStream in = c.getInputStream();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        c.disconnect();
        return o.toString("UTF-8");
    }

    static ArrayList<Rel> parse(String txt) throws Exception {
        ArrayList<Rel> out = new ArrayList<Rel>();
        JSONArray arr = new JSONArray(txt);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            if (o.optBoolean("draft") || o.optBoolean("prerelease")) continue;
            Rel r = new Rel();
            r.tag = o.optString("tag_name", "");
            r.name = o.optString("name", "");
            r.body = o.optString("body", "");
            r.url = o.optString("html_url", "");
            String d = o.optString("published_at", "");
            r.date = d.length() >= 10 ? d.substring(8, 10) + "/" + d.substring(5, 7) + "/" + d.substring(0, 4) : "";
            JSONArray as = o.optJSONArray("assets");
            if (as != null) {
                for (int k = 0; k < as.length(); k++) {
                    JSONObject f = as.getJSONObject(k);
                    if (f.optString("name", "").toLowerCase().endsWith(".apk")) { r.apk = f.optString("browser_download_url", ""); break; }
                }
            }
            if (r.tag.length() > 0) out.add(r);
        }
        return out;
    }

    /** "v2.8" -> "2.8" */
    public static String ver(Rel r) {
        String t = r.tag;
        while (t.length() > 0 && !Character.isDigit(t.charAt(0))) t = t.substring(1);
        return t.length() > 0 ? t : r.tag;
    }

    /** Quita la sintaxis de Markdown de GitHub para mostrarla como texto limpio. */
    public static String clean(String md) {
        if (md == null) return "";
        String[] ls = md.replace("\r", "").split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ls.length; i++) {
            String l = ls[i].trim();
            if (l.startsWith("#")) {
                while (l.startsWith("#")) l = l.substring(1);
                l = l.trim();
            } else if (l.startsWith("- ") || l.startsWith("* ") || l.startsWith("+ ")) {
                l = "•  " + l.substring(2).trim();
            }
            l = l.replace("**", "").replace("__", "").replace("`", "");
            l = l.replaceAll("!?\\[([^\\]]*)\\]\\([^)]*\\)", "$1");
            if (l.length() == 0 && (sb.length() == 0 || sb.toString().endsWith("\n\n"))) continue;
            sb.append(l).append('\n');
        }
        return sb.toString().trim();
    }
}
