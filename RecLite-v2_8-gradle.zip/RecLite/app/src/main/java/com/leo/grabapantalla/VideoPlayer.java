package com.leo.grabapantalla;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.os.Build;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.File;

/**
 * Reproductor a pantalla completa:
 *  - barra de progreso con tiempo actual / total (mm:ss),
 *  - se puede arrastrar la barra con el video en pausa y se ve el cuadro exacto,
 *  - saltos de -10 s / +10 s (botones o doble toque a los lados),
 *  - velocidad 0,5x / 1x / 1,5x / 2x,
 *  - los controles se ocultan solos mientras reproduce; un toque los muestra u oculta.
 */
public class VideoPlayer {
    static final float[] SPEEDS = {0.5f, 1f, 1.5f, 2f};
    static final String[] SPEED_TXT = {"0,5x", "1x", "1,5x", "2x"};

    final Activity act;
    final File file;
    final Runnable onFail;
    final float den;

    Dialog d;
    VideoView vv;
    MediaPlayer mp;
    FrameLayout ctl;
    SeekBar sb;
    TextView tvCur, tvTot, tvSpeed, tvBubble;
    IconView playIc;

    int dur = 0, speedIdx = 1;
    boolean prepared, dragging, resumeAfter, ended, shown = true, closed;
    long lastTouch, lastSeekAt, bubbleUntil;

    public VideoPlayer(Activity a, File f, Runnable onFail) {
        act = a;
        file = f;
        this.onFail = onFail;
        den = a.getResources().getDisplayMetrics().density;
    }

    int dp(int v) { return (int) (v * den + 0.5f); }

    TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(act);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        Fonts.init(act);
        v.setTypeface(bold ? Fonts.semi : Fonts.reg);
        return v;
    }

    GradientDrawable shape(int fill, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        return g;
    }

    // ---------------------------------------------------------------- construccion

    public void show() {
        d = new Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout root = new FrameLayout(act);
        root.setBackgroundColor(0xFF000000);
        root.setKeepScreenOn(true);

        vv = new VideoView(act);
        root.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        // capa que recibe los toques: 1 toque = mostrar/ocultar, doble toque = saltar 10 s
        View tap = new View(act);
        final android.view.GestureDetector gd = new android.view.GestureDetector(act, new android.view.GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { setShown(!shown); return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                float x = e.getX();
                int total = act.getResources().getDisplayMetrics().widthPixels;
                if (x < total / 3f) skip(-10000);
                else if (x > total * 2f / 3f) skip(10000);
                else toggle();
                return true;
            }
            @Override public boolean onDown(MotionEvent e) { return true; }
        });
        tap.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) { return gd.onTouchEvent(e); }
        });
        root.addView(tap, new FrameLayout.LayoutParams(-1, -1));

        ctl = new FrameLayout(act);
        root.addView(ctl, new FrameLayout.LayoutParams(-1, -1));

        // ----- barra superior: nombre + cerrar
        FrameLayout top = new FrameLayout(act);
        top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xB0000000, 0}));
        top.setPadding(dp(16), dp(28), dp(16), dp(24));
        TextView name = text(file.getName(), 14, 0xFFFFFFFF, true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL | Gravity.START);
        np.rightMargin = dp(56);
        top.addView(name, np);
        TextView x = text("✕", 20, 0xFFFFFFFF, true);
        x.setGravity(Gravity.CENTER);
        x.setBackground(shape(0x66000000, 22));
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
        top.addView(x, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END | Gravity.CENTER_VERTICAL));
        ctl.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // ----- centro: -10 / play-pausa / +10
        LinearLayout mid = new LinearLayout(act);
        mid.setGravity(Gravity.CENTER);
        mid.addView(skipBtn("−10", -10000));
        FrameLayout pb = new FrameLayout(act);
        pb.setBackground(shape(Theme.PRI, 36));
        playIc = new IconView(act, IconView.PLAY, Theme.ON_PRI);
        pb.addView(playIc, new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
        pb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggle(); } });
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(72), dp(72));
        pp.leftMargin = dp(24);
        pp.rightMargin = dp(24);
        mid.addView(pb, pp);
        mid.addView(skipBtn("+10", 10000));
        ctl.addView(mid, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        // ----- burbuja grande con el tiempo (al arrastrar o saltar)
        tvBubble = text("00:00 / 00:00", 22, 0xFFFFFFFF, true);
        tvBubble.setGravity(Gravity.CENTER);
        tvBubble.setPadding(dp(18), dp(10), dp(18), dp(10));
        tvBubble.setBackground(shape(0xB0000000, 18));
        tvBubble.setAlpha(0f);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        bp.topMargin = dp(110);
        root.addView(tvBubble, bp);

        // ----- barra inferior: tiempo, progreso, velocidad
        LinearLayout bot = new LinearLayout(act);
        bot.setOrientation(LinearLayout.VERTICAL);
        bot.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0xC0000000, 0}));
        bot.setPadding(dp(16), dp(36), dp(16), dp(24));

        LinearLayout row = new LinearLayout(act);
        row.setGravity(Gravity.CENTER_VERTICAL);
        tvCur = text("00:00", 13, 0xFFFFFFFF, true);
        tvTot = text("00:00", 13, 0xCCFFFFFF, false);
        sb = new SeekBar(act);
        sb.setMax(1000);
        sb.setPadding(dp(14), dp(8), dp(14), dp(8));
        tint(sb);
        row.addView(tvCur, new LinearLayout.LayoutParams(-2, -2));
        row.addView(sb, new LinearLayout.LayoutParams(0, dp(40), 1));
        row.addView(tvTot, new LinearLayout.LayoutParams(-2, -2));
        bot.addView(row, new LinearLayout.LayoutParams(-1, -2));

        tvSpeed = text(SPEED_TXT[speedIdx], 13, 0xFFFFFFFF, true);
        tvSpeed.setGravity(Gravity.CENTER);
        tvSpeed.setPadding(dp(16), 0, dp(16), 0);
        tvSpeed.setBackground(shape(0x66000000, 18));
        tvSpeed.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { cycleSpeed(); } });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, dp(36));
        sp.gravity = Gravity.END;
        sp.topMargin = dp(4);
        bot.addView(tvSpeed, sp);
        ctl.addView(bot, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean user) {
                if (!user) return;
                touched();
                upd(v);
                bubble(v);
                long now = SystemClock.uptimeMillis();
                if (now - lastSeekAt > 70) { lastSeekAt = now; seekTo(v); }   // se ve el cuadro mientras arrastras, aun en pausa
            }
            public void onStartTrackingTouch(SeekBar s) {
                dragging = true;
                resumeAfter = vv.isPlaying();
                if (resumeAfter) vv.pause();
            }
            public void onStopTrackingTouch(SeekBar s) {
                seekTo(s.getProgress());
                dragging = false;
                ended = false;
                if (resumeAfter) { vv.start(); applySpeed(); }
                resumeAfter = false;
                updIcon();
                touched();
            }
        });

        vv.setVideoPath(file.getAbsolutePath());
        vv.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer m) {
                mp = m;
                prepared = true;
                dur = Math.max(1, m.getDuration());
                sb.setMax(dur);
                tvTot.setText(Media.time(dur / 1000));
                upd(0);
                vv.start();
                applySpeed();
                updIcon();
                touched();
            }
        });
        vv.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer m) {
                ended = true;
                upd(dur);
                updIcon();
                setShown(true);
            }
        });
        vv.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            public boolean onError(MediaPlayer m, int what, int extra) {
                d.dismiss();
                if (onFail != null) onFail.run();
                return true;
            }
        });

        d.setContentView(root);
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            public void onDismiss(android.content.DialogInterface di) {
                closed = true;
                try { vv.stopPlayback(); } catch (Throwable e) {}
            }
        });
        d.show();
        touched();
        tick();
    }

    View skipBtn(String label, final int delta) {
        TextView b = text(label, 15, 0xFFFFFFFF, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(0x66000000, 26));
        b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { skip(delta); } });
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));
        return b;
    }

    void tint(SeekBar s) {
        try {
            s.setProgressTintList(ColorStateList.valueOf(Theme.PRI));
            s.setThumbTintList(ColorStateList.valueOf(Theme.PRI));
            s.setProgressBackgroundTintList(ColorStateList.valueOf(0x55FFFFFF));
        } catch (Throwable e) {}
    }

    // ---------------------------------------------------------------- acciones

    void toggle() {
        if (!prepared) return;
        if (vv.isPlaying()) {
            vv.pause();
        } else {
            if (ended || vv.getCurrentPosition() >= dur - 150) { seekTo(0); ended = false; }
            vv.start();
            applySpeed();
        }
        updIcon();
        touched();
    }

    void skip(int deltaMs) {
        if (!prepared) return;
        int target = Math.max(0, Math.min(dur, vv.getCurrentPosition() + deltaMs));
        if (dragging) return;
        ended = false;
        seekTo(target);
        upd(target);
        bubble(target);
        touched();
    }

    /** Salta al cuadro pedido (exacto en Android 8+; en versiones viejas, al cuadro clave mas cercano). */
    void seekTo(int ms) {
        if (!prepared) return;
        ms = Math.max(0, Math.min(dur, ms));
        try {
            if (Build.VERSION.SDK_INT >= 26 && mp != null) mp.seekTo(ms, MediaPlayer.SEEK_CLOSEST);
            else vv.seekTo(ms);
        } catch (Throwable e) {
            try { vv.seekTo(ms); } catch (Throwable e2) {}
        }
    }

    void cycleSpeed() {
        speedIdx = (speedIdx + 1) % SPEEDS.length;
        tvSpeed.setText(SPEED_TXT[speedIdx]);
        if (vv.isPlaying()) applySpeed();   // en pausa se aplica al reanudar (si no, algunos equipos arrancan solos)
        touched();
    }

    void applySpeed() {
        if (Build.VERSION.SDK_INT < 23 || mp == null) return;
        try { mp.setPlaybackParams(new PlaybackParams().setSpeed(SPEEDS[speedIdx])); } catch (Throwable e) {}
    }

    // ---------------------------------------------------------------- interfaz

    void upd(int pos) {
        pos = Math.max(0, Math.min(dur, pos));
        tvCur.setText(Media.time(pos / 1000));
        if (!dragging) sb.setProgress(pos);
    }

    void updIcon() { playIc.setType(vv.isPlaying() ? IconView.PAUSE : IconView.PLAY); }

    void bubble(int pos) {
        tvBubble.setText(Media.time(pos / 1000) + " / " + Media.time(dur / 1000));
        tvBubble.animate().cancel();
        tvBubble.setAlpha(1f);
        bubbleUntil = SystemClock.uptimeMillis() + 900;
    }

    void touched() { lastTouch = SystemClock.uptimeMillis(); if (!shown) setShown(true); }

    void setShown(boolean s) {
        shown = s;
        lastTouch = SystemClock.uptimeMillis();
        ctl.animate().cancel();
        if (s) {
            ctl.setVisibility(View.VISIBLE);
            ctl.animate().alpha(1f).setDuration(180).start();
        } else {
            // al ocultarse sale de la vista (GONE) para que sus botones no se coman los toques
            ctl.animate().alpha(0f).setDuration(180).withEndAction(new Runnable() {
                public void run() { if (!shown) ctl.setVisibility(View.GONE); }
            }).start();
        }
    }

    /** Cada 200 ms: mueve la barra, actualiza el tiempo y oculta los controles solos. */
    void tick() {
        if (closed || sb == null) return;
        long now = SystemClock.uptimeMillis();
        if (prepared && !dragging) {
            try { upd(ended ? dur : vv.getCurrentPosition()); } catch (Throwable e) {}
            updIcon();
        }
        if (tvBubble.getAlpha() > 0f && now > bubbleUntil && !dragging) tvBubble.animate().alpha(0f).setDuration(250).start();
        if (shown && !dragging && prepared && vv.isPlaying() && now - lastTouch > 3500) setShown(false);
        sb.postDelayed(new Runnable() { public void run() { tick(); } }, 200);
    }
}
