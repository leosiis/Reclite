package com.leo.grabapantalla;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.animation.DecelerateInterpolator;

/**
 * Fondo de la app: un solo color liso, el del tema.
 * Solo anima durante ~0,5 s cuando cambias de tema o de modo:
 * el color del fondo y de las barras del sistema se funden en vez de saltar.
 */
public class Bg {
    /** Color que se vio la última vez (sobrevive al recrear la pantalla) para animar desde ahí. */
    static int last;
    static boolean hasLast;

    final ColorDrawable fill = new ColorDrawable();
    ValueAnimator anim;

    public Bg(Context c) {
        fill.setColor(target()[0]);
    }

    public Drawable drawable() { return fill; }

    /** Fondo ya pintado con el color actual del tema (para pantallas que se superponen, como el tutorial). */
    public static Drawable solid(Context c) { return new Bg(c).fill; }

    /** {arriba, medio, abajo}: los tres iguales (fondo liso) según el tema actual. */
    public static int[] target() {
        int bg = Theme.BG;
        return new int[]{bg, bg, bg};
    }

    /** Aplica el fondo a la ventana y a las barras; si hay un color anterior, los funde. */
    public void show(final Activity a, boolean animate) {
        final int to = target()[0];
        final int from = animate && hasLast ? last : to;
        last = to;
        hasLast = true;
        bars(a, to);
        fill.setColor(from);
        if (from == to) return;
        final ArgbEvaluator ev = new ArgbEvaluator();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(520);
        anim.setInterpolator(new DecelerateInterpolator(1.4f));
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator va) {
                float t = ((Float) va.getAnimatedValue()).floatValue();
                int cur = ((Integer) ev.evaluate(t, Integer.valueOf(from), Integer.valueOf(to))).intValue();
                fill.setColor(cur);
                bars(a, cur);
            }
        });
        anim.start();
    }

    static void bars(Activity a, int c) {
        try {
            a.getWindow().setStatusBarColor(c | 0xFF000000);
            a.getWindow().setNavigationBarColor(c | 0xFF000000);
        } catch (Throwable e) {}
    }

    public void stop() {
        if (anim != null) { anim.cancel(); anim = null; }
    }
}
