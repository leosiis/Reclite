package com.leo.grabapantalla;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;

/**
 * Paleta Material 3.
 * Indice 0 = Material You AUTOMATICO:
 *  - Android 12+: colores del sistema (los del fondo de pantalla).
 *  - Android 8.1 a 11: se genera la paleta con el color principal del fondo de pantalla.
 *  - Antes: paleta violeta por defecto.
 *  Sigue solo el modo claro / oscuro del sistema (si AMOLED esta activo se fuerza oscuro).
 */
public class Theme {
    public static int BG, SURF, SURF2, SURF3, PRI, ON_PRI, PRI_C, ON_PRI_C, SEC_C, ON_SEC_C, TXT, TXT2, OUTLINE;
    public static int REC, REC_C, ON_REC_C, REC_SOFT, RIPPLE;
    public static boolean LIGHT, AMO;

    public static final String[] NAMES = {"Material You", "Lavanda", "Océano", "Menta", "Coral", "Ámbar"};

    // BG, SURF, SURF2, SURF3, PRI, ON_PRI, PRI_C, ON_PRI_C, SEC_C, ON_SEC_C, TXT, TXT2, OUTLINE
    static final int[][] P = {
        {0xFF111318, 0xFF1A1C20, 0xFF282A2F, 0xFF33353A, 0xFFA8C7FA, 0xFF062E6F, 0xFF0842A0, 0xFFD3E3FD, 0xFF3C4858, 0xFFD7E3F8, 0xFFE2E2E9, 0xFFC4C6D0, 0xFF44474F},
        {0xFF101411, 0xFF181C19, 0xFF272B27, 0xFF323632, 0xFF86D9A3, 0xFF00391E, 0xFF005230, 0xFFA2F5BD, 0xFF3A4B3F, 0xFFD2E8D6, 0xFFE0E3DD, 0xFFC0C9BF, 0xFF414942},
        {0xFF1A1110, 0xFF231918, 0xFF322826, 0xFF3D3231, 0xFFFFB4A8, 0xFF561E16, 0xFF73332A, 0xFFFFDAD4, 0xFF5D3F3A, 0xFFFFDAD4, 0xFFF1DFDC, 0xFFD8C2BE, 0xFF534341},
        {0xFF16130B, 0xFF1E1B13, 0xFF2D2A21, 0xFF38342B, 0xFFE9C16C, 0xFF3E2E04, 0xFF584419, 0xFFFFDF9F, 0xFF4F4632, 0xFFEDE1CF, 0xFFE9E2D4, 0xFFCDC6B4, 0xFF4D4639}
    };
    // La lavanda es la paleta violeta por defecto (tambien sirve de respaldo)
    static final int[] LAVENDER = {0xFF141218, 0xFF1D1B20, 0xFF2B2930, 0xFF36343B, 0xFFD0BCFF, 0xFF381E72, 0xFF4F378B, 0xFFEADDFF, 0xFF4A4458, 0xFFE8DEF8, 0xFFE6E0E9, 0xFFCAC4D0, 0xFF49454F};

    /** Paleta de un tema. idx 0 = Material You (automatico). Para idx > 0 siempre es oscura. */
    static final int[] SEEDS = {0xFF6750A4, 0xFF6750A4, 0xFF1A73E8, 0xFF1E9E64, 0xFFE0594B, 0xFFD9A21B};

    public static int[] palette(Context c, int idx, boolean light) {
        if (idx == 0) {
            int[] p = dynamic(c, light);
            if (p == null) p = seeded(wallpaperSeed(c), light);
            return p;
        }
        if (light) return seeded(SEEDS[Math.min(idx, SEEDS.length - 1)], true);
        if (idx == 1) return LAVENDER;
        return P[Math.min(idx - 2, P.length - 1)];
    }

    public static void init(Context c, int idx, boolean amoled) { init(c, idx, amoled, 0); }

    /** mode: 0 automatico, 1 claro, 2 oscuro (AMOLED siempre fuerza oscuro). */
    public static void init(Context c, int idx, boolean amoled, int mode) {
        boolean sysDark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        AMO = amoled;
        if (amoled || mode == 2) LIGHT = false;
        else if (mode == 1) LIGHT = true;
        else LIGHT = idx == 0 && !sysDark;
        int[] p = palette(c, idx, LIGHT);
        BG = p[0]; SURF = p[1]; SURF2 = p[2]; SURF3 = p[3];
        PRI = p[4]; ON_PRI = p[5]; PRI_C = p[6]; ON_PRI_C = p[7];
        SEC_C = p[8]; ON_SEC_C = p[9]; TXT = p[10]; TXT2 = p[11]; OUTLINE = p[12];
        if (amoled) {
            // negro puro de verdad; las tarjetas casi negras con un borde fino para que se distingan
            BG = 0xFF000000;
            SURF = 0xFF000000;
            SURF2 = mix(SURF2, 0xFF000000, 0.55f);
            SURF3 = mix(SURF3, 0xFF000000, 0.30f);
            OUTLINE = mix(OUTLINE, 0xFF000000, 0.25f);
            TXT = mix(TXT, 0xFFFFFFFF, 0.25f);
        }
        if (LIGHT) {
            REC = 0xFFBA1A1A; REC_C = 0xFFFFDAD6; ON_REC_C = 0xFF410002; REC_SOFT = 0xFFBA1A1A;
            RIPPLE = 0x22000000;
        } else {
            REC = 0xFFFF5449; REC_C = 0xFF93000A; ON_REC_C = 0xFFFFDAD6; REC_SOFT = 0xFFFFB4AB;
            RIPPLE = 0x30FFFFFF;
        }
    }

    // ---------- Android 12+: colores del sistema ----------

    static int[] dynamic(Context c, boolean light) {
        if (Build.VERSION.SDK_INT < 31) return null;
        try {
            Resources r = c.getResources();
            Class<?> k = Class.forName("android.R$color");
            if (light) {
                int n10 = col(r, k, "system_neutral1_10"), n50 = col(r, k, "system_neutral1_50"), n100 = col(r, k, "system_neutral1_100");
                return new int[]{
                    n10, n50, mix(n50, n100, 0.5f), n100,
                    col(r, k, "system_accent1_600"), col(r, k, "system_accent1_0"),
                    col(r, k, "system_accent1_100"), col(r, k, "system_accent1_900"),
                    col(r, k, "system_accent2_100"), col(r, k, "system_accent2_900"),
                    col(r, k, "system_neutral1_900"), col(r, k, "system_neutral2_700"),
                    col(r, k, "system_neutral2_200")
                };
            }
            int n900 = col(r, k, "system_neutral1_900");
            int n800 = col(r, k, "system_neutral1_800");
            int n700 = col(r, k, "system_neutral1_700");
            return new int[]{
                mix(n900, 0xFF000000, 0.35f), n900, n800, mix(n800, n700, 0.6f),
                col(r, k, "system_accent1_200"), col(r, k, "system_accent1_800"),
                col(r, k, "system_accent1_700"), col(r, k, "system_accent1_100"),
                col(r, k, "system_accent2_700"), col(r, k, "system_accent2_100"),
                col(r, k, "system_neutral1_100"), col(r, k, "system_neutral2_200"),
                col(r, k, "system_neutral2_700")
            };
        } catch (Throwable t) {
            return null;
        }
    }

    static int col(Resources r, Class<?> k, String name) throws Exception {
        return r.getColor(k.getField(name).getInt(null));
    }

    // ---------- Android 8.1 a 11: paleta generada con el fondo de pantalla ----------

    static int wallpaperSeed(Context c) {
        int def = 0xFF6750A4;
        if (Build.VERSION.SDK_INT < 27) return def;
        try {
            Object wm = WallpaperManager.getInstance(c);
            Object wc = wm.getClass().getMethod("getWallpaperColors", int.class).invoke(wm, 1);
            if (wc == null) return def;
            Object col = wc.getClass().getMethod("getPrimaryColor").invoke(wc);
            if (col == null) return def;
            return (Integer) col.getClass().getMethod("toArgb").invoke(col);
        } catch (Throwable t) {
            return def;
        }
    }

    static int[] seeded(int seed, boolean light) {
        float[] hsv = new float[3];
        Color.colorToHSV(seed, hsv);
        float h = hsv[0];
        float sa = Math.max(0.30f, Math.min(0.62f, 0.30f + hsv[1] * 0.35f));
        float sb = sa * 0.40f, sn = 0.08f, sv = 0.10f;
        if (light) {
            return new int[]{
                hsl(h, sn, 0.99f), hsl(h, sn, 0.96f), hsl(h, sn, 0.93f), hsl(h, sn, 0.89f),
                hsl(h, sa, 0.40f), 0xFFFFFFFF, hsl(h, sa, 0.90f), hsl(h, sa, 0.12f),
                hsl(h, sb, 0.90f), hsl(h, sb, 0.12f), hsl(h, sn, 0.10f), hsl(h, sv, 0.30f), hsl(h, sv, 0.75f)
            };
        }
        return new int[]{
            hsl(h, sn, 0.07f), hsl(h, sn, 0.09f), hsl(h, sn, 0.15f), hsl(h, sn, 0.20f),
            hsl(h, sa, 0.80f), hsl(h, sa, 0.20f), hsl(h, sa, 0.30f), hsl(h, sa, 0.90f),
            hsl(h, sb, 0.30f), hsl(h, sb, 0.90f), hsl(h, sn, 0.90f), hsl(h, sv, 0.78f), hsl(h, sv, 0.30f)
        };
    }

    static int hsl(float h, float s, float l) {
        float c = (1 - Math.abs(2 * l - 1)) * s;
        float hp = (h % 360f) / 60f;
        float x = c * (1 - Math.abs(hp % 2 - 1));
        float r = 0, g = 0, b = 0;
        switch ((int) hp) {
            case 0: r = c; g = x; break;
            case 1: r = x; g = c; break;
            case 2: g = c; b = x; break;
            case 3: g = x; b = c; break;
            case 4: r = x; b = c; break;
            default: r = c; b = x; break;
        }
        float m = l - c / 2f;
        return Color.rgb(Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255));
    }

    public static int mix(int a, int b, float t) {
        int ar = Color.red(a), ag = Color.green(a), ab = Color.blue(a);
        int br = Color.red(b), bg = Color.green(b), bb = Color.blue(b);
        return Color.rgb(Math.round(ar + (br - ar) * t), Math.round(ag + (bg - ag) * t), Math.round(ab + (bb - ab) * t));
    }
}
