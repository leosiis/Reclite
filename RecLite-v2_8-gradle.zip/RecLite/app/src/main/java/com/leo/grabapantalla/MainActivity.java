package com.leo.grabapantalla;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends Activity {

    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    /** Solo se piden los permisos una vez cada vez que se abre la app (no al girar ni al cambiar de tema). */
    static boolean permsAsked;

    interface BoolCb { void on(boolean v); }

    SharedPreferences sp;
    FrameLayout rootF, host;
    FrameLayout[] navPill = new FrameLayout[3];
    IconView[] navIcon = new IconView[3];
    TextView[] navLabel = new TextView[3];
    int page = 0;
    Bg bgFx;
    boolean wasRec, pulsing, anim, skipResume;
    int lastMode = -1, lastPause = -1, lastHero = -1, permSig;

    // pagina Grabar
    View newsDot;
    static boolean updChecked;
    TextView tvTimer, tvStatus, tvSub, tvHint, tvStore, tvProfTag;
    LinearLayout statusChip;
    RecButton recBtn;
    FrameLayout btnPause;
    IconView btnPauseIcon;
    View recDot;
    GradientDrawable heroBg;
    // perfiles
    int profSel = -2;
    ProfView[] pv = new ProfView[5];
    ProfView[] tpv = new ProfView[5];
    ArrayList<ProfView> mv = new ArrayList<ProfView>();
    ArrayList<Cfg.Mine> mineData = new ArrayList<Cfg.Mine>();
    LinearLayout mineBox;
    int mineSel = -1;   // perfil propio elegido por el usuario (aunque sus numeros coincidan con uno base)
    View navView;
    // seleccion multiple (biblioteca)
    boolean selMode;
    HashSet<String> sel = new HashSet<String>();
    TextView tvDel;
    // pagina Ajustes
    TextView tvSetEst, tvSetHint;
    // tutorial
    FrameLayout tutRoot, tutBody;
    View[] tutDots;
    TextView tutBtn, tutBack, tutLater;
    LinearLayout tutPermList, tutProfList, tutAudList;
    AudView[] tav = new AudView[4];
    int tutIdx;
    float tutDownX;
    Runnable tutAfter;
    ObjectAnimator tutBob;

    // creador (mini menú)
    static final String CREATOR = "Victordelaxx33";
    static final String TIKTOK_URL = "https://www.tiktok.com/@victor.delaxx33";

    static final int TUT_N = 5;
    /** Paso del tutorial al que volver tras recrear la pantalla (cambio de tema en vivo). */
    static int tutResume = -1;

    // ---------- helpers de UI ----------

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    GradientDrawable shape(int fill, int r) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(dp(r));
        return gd;
    }

    /** Fondo de tarjeta: en AMOLED lleva un borde fino para que se distinga del negro. */
    GradientDrawable cardBg(int fill, int r) {
        GradientDrawable gd = shape(fill, r);
        if (Theme.AMO) gd.setStroke(dp(1), Theme.OUTLINE);
        return gd;
    }

    GradientDrawable outline(int stroke, int r) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(0);
        gd.setStroke(dp(1), stroke);
        gd.setCornerRadius(dp(r));
        return gd;
    }

    Drawable rip(Drawable content, int r, int rippleColor) {
        GradientDrawable m = new GradientDrawable();
        m.setColor(0xFF000000);
        m.setCornerRadius(dp(r));
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, m);
    }

    Drawable rip(int fill, int r) { return rip(shape(fill, r), r, Theme.RIPPLE); }

    /** style: 0 normal, 1 medio, 2 fino */
    TextView t(String s, int size, int color, int style) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        Fonts.init(this);
        v.setTypeface(style == 1 ? (size >= 22 ? Fonts.bold : Fonts.semi) : (style == 2 ? Fonts.light : Fonts.reg));
        return v;
    }

    LinearLayout.LayoutParams lp(int w, int h, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        return p;
    }

    LinearLayout vbox(int padDp) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp));
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    IconView icon(int type, int size, int color) {
        IconView v = new IconView(this, type, color);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return v;
    }

    FrameLayout circle(int type, int sizeDp, int iconDp, int fill, int iconColor) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(rip(fill, sizeDp / 2));
        IconView v = new IconView(this, type, iconColor);
        f.addView(v, new FrameLayout.LayoutParams(dp(iconDp), dp(iconDp), Gravity.CENTER));
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return f;
    }

    int g(int k) { return Cfg.get(sp, k); }

    void toast(String s) { Pill.show(this, s, false); }

    ScrollView scroll(LinearLayout inner) {
        ScrollView sv = new ScrollView(this);
        sv.setClipToPadding(false);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.setPadding(dp(16), 0, dp(16), dp(112));
        sv.addView(inner, new ViewGroup.LayoutParams(MATCH, WRAP));
        return sv;
    }

    View.OnClickListener go(final int p) {
        return new View.OnClickListener() { public void onClick(View v) { showPage(p, true); } };
    }

    // ---------- animaciones ----------

    /** Efecto de "hundirse" al tocar. No consume el toque, asi el clic y el ripple siguen funcionando. */
    void press(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View x, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    x.animate().scaleX(0.96f).scaleY(0.96f).setStartDelay(0).setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    x.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(240).setInterpolator(new OvershootInterpolator(2.5f)).start();
                }
                return false;
            }
        });
    }

    void pop(View v) {
        v.setScaleX(0.5f);
        v.setScaleY(0.5f);
        v.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(320).setInterpolator(new OvershootInterpolator(3f)).start();
    }

    void animColor(final GradientDrawable gd, int from, int to) {
        ValueAnimator a = ValueAnimator.ofObject(new ArgbEvaluator(), from, to);
        a.setDuration(280);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator va) { gd.setColor((Integer) va.getAnimatedValue()); }
        });
        a.start();
    }

    void animW(final View v, int to) {
        final ViewGroup.LayoutParams p = v.getLayoutParams();
        ValueAnimator a = ValueAnimator.ofInt(p.width, to);
        a.setDuration(260);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator va) {
                p.width = (Integer) va.getAnimatedValue();
                v.setLayoutParams(p);
            }
        });
        a.start();
    }

    /** pop con un pequeño giro (iconos de la barra inferior) */
    void popRot(View v, float rot) {
        v.setScaleX(0.5f);
        v.setScaleY(0.5f);
        v.setRotation(rot);
        v.animate().scaleX(1f).scaleY(1f).rotation(0f).setStartDelay(0).setDuration(380).setInterpolator(new OvershootInterpolator(3f)).start();
    }

    /** Los bloques de la pagina entran uno tras otro: suben, crecen un poco y aparecen (solo los primeros, es barato). */
    void stagger(LinearLayout c) {
        if (!anim) return;
        int n = Math.min(c.getChildCount(), 8);
        for (int i = 0; i < n; i++) {
            final View v = c.getChildAt(i);
            v.setAlpha(0f);
            v.setTranslationY(dp(26));
            v.setScaleX(0.96f);
            v.setScaleY(0.96f);
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(i * 45L).setDuration(380)
                    .setInterpolator(new DecelerateInterpolator(2f))
                    .withEndAction(new Runnable() { public void run() { v.animate().setStartDelay(0); } }).start();
        }
    }

    /** Interruptor Material 3 con animacion. */
    View sw(boolean initial, final BoolCb cb) {
        final FrameLayout f = new FrameLayout(this);
        final GradientDrawable tr = shape(initial ? Theme.PRI : Theme.SURF3, 16);
        tr.setStroke(dp(2), initial ? Theme.PRI : Theme.OUTLINE);
        f.setBackground(tr);
        final View th = new View(this);
        final GradientDrawable thb = shape(initial ? Theme.ON_PRI : Theme.TXT2, 12);
        th.setBackground(thb);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER_VERTICAL | Gravity.START);
        tp.leftMargin = dp(5);
        f.addView(th, tp);
        th.setTranslationX(initial ? dp(20) : 0);
        final boolean[] st = {initial};
        f.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                st[0] = !st[0];
                boolean on = st[0];
                th.animate().translationX(on ? dp(20) : 0).setStartDelay(0).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
                animColor(tr, on ? Theme.SURF3 : Theme.PRI, on ? Theme.PRI : Theme.SURF3);
                tr.setStroke(dp(2), on ? Theme.PRI : Theme.OUTLINE);
                animColor(thb, on ? Theme.TXT2 : Theme.ON_PRI, on ? Theme.ON_PRI : Theme.TXT2);
                cb.on(on);
            }
        });
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(32)));
        return f;
    }

    // ---------- ciclo de vida ----------

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", 0);
        // instalación nueva: empieza con el perfil que de verdad aguanta este equipo (no con 1080p a 60 fps a ciegas)
        if (!sp.getBoolean("tut_done", false) && !sp.contains(Cfg.KEYS[Cfg.RES_I]) && !sp.contains(Cfg.KEYS[Cfg.FPS_I])) {
            try { Cfg.applyPreset(sp, Cfg.recommended(this)); } catch (Throwable e) {}
        }
        Theme.init(this, g(Cfg.THM_I), g(Cfg.AMO_I) == 1, g(Cfg.MOD_I));
        sysBars();
        if (b != null) page = b.getInt("page", 0);
        skipResume = true;

        rootF = new FrameLayout(this);
        bgFx = new Bg(this);
        rootF.setBackground(bgFx.drawable());
        bgFx.show(this, true);

        LinearLayout col = column();
        col.addView(buildHeader(), new LinearLayout.LayoutParams(MATCH, WRAP));
        host = new FrameLayout(this);
        col.addView(host, new LinearLayout.LayoutParams(MATCH, 0, 1));
        rootF.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM);
        np.setMargins(dp(14), 0, dp(14), dp(14));
        navView = buildNav();
        rootF.addView(navView, np);
        setContentView(rootF);
        showPage(page, b == null);
        handleTile(getIntent());

        if (tutResume >= 0) {
            int st = tutResume;
            tutResume = -1;
            permsAsked = true;
            showTutorial(null, st, false);
        } else if (b == null && !permsAsked) {
            permsAsked = true;
            if (!sp.getBoolean("tut_done", false)) {
                showTutorial(null);   // los permisos se piden dentro del tutorial
            } else {
                rootF.postDelayed(new Runnable() { public void run() { startPermFlow(false); } }, 600);
            }
        }
        if (!updChecked) {
            updChecked = true;
            rootF.postDelayed(new Runnable() { public void run() { checkUpdate(); } }, 1800);
        }
    }

    // ---------- novedades y avisos de version nueva (ver Updater) ----------

    /** Al abrir la app: busca un release nuevo en GitHub y avisa una sola vez por version. */
    void checkUpdate() {
        Updater.load(this, false, new Updater.Cb() {
            public void done(ArrayList<Updater.Rel> list, boolean online) {
                Updater.Rel r = Updater.latest(list);
                if (r == null) return;
                if (newsDot != null && !r.tag.equals(sp.getString("news_seen", ""))) newsDot.setVisibility(View.VISIBLE);
                if (Updater.isNewer(MainActivity.this, r) && !r.tag.equals(sp.getString("upd_told", "")) && tutRoot == null
                        && !RecorderService.recording) {
                    sp.edit().putString("upd_told", r.tag).apply();
                    showUpdate(r);
                }
            }
        });
    }

    void showUpdate(final Updater.Rel r) {
        String ch = Updater.clean(r.body);
        if (ch.length() > 500) ch = ch.substring(0, 500).trim() + "…";
        String msg = "Tienes la " + Updater.current(this) + " y ya está disponible la " + Updater.ver(r) + "."
                + (ch.length() > 0 ? "\n\n" + ch : "");
        dlg("Nueva versión disponible", msg, null, "Descargar", false, new Runnable() {
            public void run() { openLink(r.apk.length() > 0 ? r.apk : (r.url.length() > 0 ? r.url : Updater.releasesPage())); }
        });
    }

    View newsBtn(String label, boolean primary, View.OnClickListener l) {
        TextView b = t(label, 14, primary ? Theme.ON_PRI : Theme.PRI, 1);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setBackground(primary ? rip(Theme.PRI, 20) : rip(outline(Theme.OUTLINE, 20), 20, Theme.RIPPLE));
        b.setOnClickListener(l);
        press(b);
        return b;
    }

    /** Pantalla de novedades: lista de versiones con lo que cambió en cada una. */
    void showNews() {
        final LinearLayout list = column();
        ScrollView sv = new ScrollView(this) {
            @Override protected void onMeasure(int w, int h) {
                int max = (int) (getResources().getDisplayMetrics().heightPixels * 0.58f);
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(max, View.MeasureSpec.AT_MOST));
            }
        };
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(list, new ViewGroup.LayoutParams(MATCH, WRAP));
        list.addView(t("Buscando novedades…", 14, Theme.TXT2, 0));
        dlg("Novedades", "Versión instalada: " + Updater.current(this), sv, null, false, null);
        Updater.load(this, true, new Updater.Cb() {
            public void done(ArrayList<Updater.Rel> rels, boolean online) { fillNews(list, rels, online); }
        });
    }

    void fillNews(LinearLayout list, ArrayList<Updater.Rel> rels, boolean online) {
        list.removeAllViews();
        Updater.Rel top = Updater.latest(rels);
        if (top != null) {
            sp.edit().putString("news_seen", top.tag).apply();
            if (newsDot != null) newsDot.setVisibility(View.GONE);
        }
        if (top != null && Updater.isNewer(this, top)) {
            final Updater.Rel nr = top;
            LinearLayout b = column();
            b.setPadding(dp(14), dp(14), dp(14), dp(14));
            b.setBackground(cardBg(Theme.PRI_C, 20));
            b.addView(t("Hay una versión nueva: " + Updater.ver(top), 15, Theme.ON_PRI_C, 1));
            b.addView(newsBtn("Descargar", true, new View.OnClickListener() {
                public void onClick(View v) { openLink(nr.apk.length() > 0 ? nr.apk : (nr.url.length() > 0 ? nr.url : Updater.releasesPage())); }
            }), lp(WRAP, dp(40), 10));
            list.addView(b, lp(MATCH, WRAP, 0));
        }
        if (rels.isEmpty()) {
            list.addView(t(online ? "Todavía no hay novedades publicadas." : "No se pudo conectar. Revisa tu internet e inténtalo de nuevo.",
                    14, Theme.TXT2, 0), lp(MATCH, WRAP, 4));
        } else if (!online) {
            list.addView(t("Sin conexión: se muestran las últimas novedades guardadas.", 12, Theme.TXT2, 0), lp(MATCH, WRAP, 8));
        }
        String cur = Updater.current(this);
        for (int i = 0; i < rels.size(); i++) {
            Updater.Rel r = rels.get(i);
            LinearLayout card = column();
            card.setPadding(dp(14), dp(12), dp(14), dp(14));
            card.setBackground(cardBg(Theme.SURF2, 20));
            LinearLayout head = hbox();
            head.addView(t("Versión " + Updater.ver(r), 16, Theme.TXT, 1), new LinearLayout.LayoutParams(0, WRAP, 1));
            int c = Updater.cmp(r.tag, cur);
            if (c != 0) {
                if (c > 0) {
                    TextView chip = t("Nueva", 11, Theme.ON_PRI, 1);
                    chip.setPadding(dp(10), dp(3), dp(10), dp(3));
                    chip.setBackground(shape(Theme.PRI, 10));
                    head.addView(chip);
                }
            } else {
                TextView chip = t("Instalada", 11, Theme.ON_PRI_C, 1);
                chip.setPadding(dp(10), dp(3), dp(10), dp(3));
                chip.setBackground(shape(Theme.PRI_C, 10));
                head.addView(chip);
            }
            card.addView(head);
            if (r.date.length() > 0) card.addView(t(r.date, 12, Theme.TXT2, 0), lp(MATCH, WRAP, 1));
            String body = Updater.clean(r.body);
            if (body.length() == 0) body = r.name.length() > 0 && !r.name.equals(r.tag) ? r.name : "Mejoras y correcciones.";
            card.addView(t(body, 14, Theme.TXT, 0), lp(MATCH, WRAP, 8));
            list.addView(card, lp(MATCH, WRAP, 10));
        }
        LinearLayout foot = hbox();
        foot.addView(newsBtn("Todas las versiones", false, new View.OnClickListener() {
            public void onClick(View v) { openLink(Updater.releasesPage()); }
        }), new LinearLayout.LayoutParams(0, dp(40), 1));
        if (Updater.TELEGRAM_URL.length() > 0) {
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, dp(40), 1);
            tl.leftMargin = dp(8);
            foot.addView(newsBtn("Canal de Telegram", false, new View.OnClickListener() {
                public void onClick(View v) { openLink(Updater.TELEGRAM_URL); }
            }), tl);
        }
        list.addView(foot, lp(MATCH, WRAP, 14));
    }

    /** El tile de ajustes rapidos abre la app con este extra para empezar a grabar. */
    void handleTile(Intent i) {
        if (i == null || !i.getBooleanExtra("gp.rec", false)) return;
        i.removeExtra("gp.rec");
        rootF.postDelayed(new Runnable() {
            public void run() {
                if (!RecorderService.recording && !RecorderService.starting) onRecClick();
            }
        }, 350);
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleTile(i);
    }

    void sysBars() {
        int[] bc = Bg.target();
        getWindow().setStatusBarColor(bc[0] | 0xFF000000);
        getWindow().setNavigationBarColor(bc[2] | 0xFF000000);
        getWindow().setBackgroundDrawable(new ColorDrawable(bc[1] | 0xFF000000));
        if (Build.VERSION.SDK_INT >= 23) {
            View d = getWindow().getDecorView();
            int f = d.getSystemUiVisibility();
            if (Theme.LIGHT) f |= 0x2000; else f &= ~0x2000;
            if (Build.VERSION.SDK_INT >= 26) { if (Theme.LIGHT) f |= 0x10; else f &= ~0x10; }
            d.setSystemUiVisibility(f);
        }
    }

    @Override protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        o.putInt("page", page);
    }

    @Override protected void onResume() {
        super.onResume();
        // Material You automatico: si cambio el fondo de pantalla o el modo claro/oscuro, se recoloca solo
        int before = Theme.PRI ^ Theme.BG ^ (Theme.LIGHT ? 1 : 0);
        Theme.init(this, g(Cfg.THM_I), g(Cfg.AMO_I) == 1, g(Cfg.MOD_I));
        if ((Theme.PRI ^ Theme.BG ^ (Theme.LIGHT ? 1 : 0)) != before) { recreate(); return; }
        RecorderService.onChange = new Runnable() { public void run() { refresh(); } };
        wasRec = RecorderService.recording;
        if (tutRoot != null && tutIdx == 0) fillTutPerms();
        if (skipResume) { skipResume = false; return; }
        if (tutRoot == null && (page == 0 || page == 1 || (page == 2 && permSig != sigPerms()))) showPage(page, false);
    }

    @Override protected void onDestroy() {
        if (bgFx != null) bgFx.stop();
        super.onDestroy();
    }

    @Override protected void onPause() {
        RecorderService.onChange = null;
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (tutRoot != null) {
            if (tutIdx > 0) goTut(tutIdx - 1); else endTutorial();
            return;
        }
        super.onBackPressed();
    }

    void fadeRecreate() {
        recreate();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    // ---------- cabecera y navegacion ----------

    View buildHeader() {
        LinearLayout h = hbox();
        h.setPadding(dp(20), dp(14), dp(16), dp(10));
        IconView logo = new IconView(this, IconView.LOGO, 0);
        h.addView(logo, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout names = column();
        names.addView(t("RecLite", 22, Theme.TXT, 1));
        names.addView(t("Graba tu pantalla fácil", 12, Theme.TXT2, 0));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, WRAP, 1);
        tp.leftMargin = dp(12);
        h.addView(names, tp);

        // novedades (periodico): con punto rojo si hay algo sin leer
        FrameLayout news = circle(IconView.NEWS, 44, 22, Theme.SURF2, Theme.TXT2);
        newsDot = new View(this);
        newsDot.setBackground(shape(Theme.REC, 5));
        FrameLayout.LayoutParams dp5 = new FrameLayout.LayoutParams(dp(10), dp(10), Gravity.TOP | Gravity.END);
        dp5.setMargins(0, dp(9), dp(9), 0);
        news.addView(newsDot, dp5);
        Updater.Rel cached = Updater.cachedLatest(this);
        newsDot.setVisibility(cached != null && !cached.tag.equals(sp.getString("news_seen", "")) ? View.VISIBLE : View.GONE);
        news.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showNews(); } });
        press(news);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(dp(44), dp(44));
        nlp.rightMargin = dp(8);
        news.setLayoutParams(nlp);
        h.addView(news);

        FrameLayout help = circle(IconView.HELP, 44, 22, Theme.SURF2, Theme.TXT2);
        help.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showMenu(v); } });
        press(help);
        h.addView(help);
        return h;
    }

    /** Mini menú del signo de interrogación: solo el creador y su TikTok. */
    void showMenu(final View anchor) {
        final int w = dp(210);
        LinearLayout box = vbox(6);
        final PopupWindow pw = new PopupWindow(box, w, WRAP, true);
        pw.setBackgroundDrawable(cardBg(Theme.SURF3, 22));
        if (Build.VERSION.SDK_INT >= 21) pw.setElevation(dp(12));
        LinearLayout row = hbox();
        row.setPadding(dp(12), dp(2), dp(2), dp(2));
        row.addView(t(CREATOR, 15, Theme.TXT, 1), new LinearLayout.LayoutParams(0, WRAP, 1));
        row.addView(miniLink(IconView.TIKTOK, new View.OnClickListener() {
            public void onClick(View v) { pw.dismiss(); openLink(TIKTOK_URL); }
        }));
        box.addView(row);
        pw.showAsDropDown(anchor, anchor.getWidth() - w, dp(2));
        try {
            View rv = box.getRootView();
            rv.setPivotX(w);
            rv.setPivotY(0);
            rv.setAlpha(0f);
            rv.setScaleX(0.85f);
            rv.setScaleY(0.85f);
            rv.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(190).setInterpolator(new DecelerateInterpolator(1.8f)).start();
        } catch (Throwable e) {}
    }

    View miniLink(int ic, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(rip(Theme.SURF2, 18));
        f.addView(new IconView(this, ic, Theme.TXT), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
        f.setOnClickListener(l);
        press(f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(36), dp(36));
        p.leftMargin = dp(8);
        f.setLayoutParams(p);
        return f;
    }

    void openLink(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) { toast("No se pudo abrir el enlace"); }
    }

    View buildNav() {
        LinearLayout bar = hbox();
        bar.setPadding(dp(8), dp(8), dp(8), dp(8));
        bar.setBackground(cardBg(Theme.SURF2, 30));
        if (Build.VERSION.SDK_INT >= 21) bar.setElevation(dp(8));
        String[] names = {"Grabar", "Biblioteca", "Ajustes"};
        int[] ic = {IconView.REC, IconView.LIBRARY, IconView.SETTINGS};
        for (int i = 0; i < 3; i++) {
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            it.setPadding(0, dp(4), 0, dp(4));
            navPill[i] = new FrameLayout(this);
            navIcon[i] = new IconView(this, ic[i], Theme.TXT2);
            navPill[i].addView(navIcon[i], new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            it.addView(navPill[i], new LinearLayout.LayoutParams(dp(64), dp(32)));
            navLabel[i] = t(names[i], 12, Theme.TXT2, 1);
            it.addView(navLabel[i], lp(WRAP, WRAP, 3));
            it.setOnClickListener(go(i));
            press(it);
            bar.addView(it, new LinearLayout.LayoutParams(0, WRAP, 1));
        }
        return bar;
    }

    void updNav(boolean animate, int prev) {
        for (int i = 0; i < 3; i++) {
            boolean sel = i == page;
            navPill[i].setBackground(sel ? shape(Theme.SEC_C, 16) : null);
            navIcon[i].setColor(sel ? Theme.ON_SEC_C : Theme.TXT2);
            navLabel[i].setTextColor(sel ? Theme.TXT : Theme.TXT2);
            if (sel && animate && prev != page) {
                navPill[i].setScaleX(0.35f);
                navPill[i].animate().scaleX(1f).setStartDelay(0).setDuration(340).setInterpolator(new OvershootInterpolator(1.8f)).start();
                popRot(navIcon[i], -16f);
            }
        }
    }

    void showPage(int p, boolean animate) {
        int prev = page;
        if (p != 1) { selMode = false; sel.clear(); }
        page = p;
        anim = animate;
        tvSetHint = null; tvDel = null;
        tvTimer = null; tvSetEst = null; tvStore = null; tvSub = null; tvHint = null; tvProfTag = null; mineBox = null;
        pulsing = false; lastMode = -1; lastPause = -1; lastHero = -1; profSel = -2;
        host.removeAllViews();
        View v = p == 0 ? buildRecord() : (p == 1 ? buildLibrary() : buildSettings());
        host.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        if (animate) {
            boolean moved = p != prev;
            v.setAlpha(0f);
            if (moved) v.setTranslationX(p > prev ? dp(26) : -dp(26));
            v.animate().alpha(1f).translationX(0f).setStartDelay(0).setDuration(moved ? 280 : 200).setInterpolator(new DecelerateInterpolator(1.8f)).start();
        }
        updNav(animate, prev);
        if (p == 0) refresh();
    }

    // ---------- permisos ----------

    boolean hasAudio() { return Build.VERSION.SDK_INT < 23 || checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED; }
    boolean hasNotif() { return Build.VERSION.SDK_INT < 33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED; }
    boolean hasOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this); }
    boolean hasStorage() { return Media.canExport(this); }

    int sigPerms() { return (hasAudio() ? 1 : 0) | (hasNotif() ? 2 : 0) | (hasOverlay() ? 4 : 0) | (hasStorage() ? 8 : 0); }

    int missingPerms() {
        int n = 0;
        if (!hasAudio()) n++;
        if (!hasNotif()) n++;
        if (!hasOverlay()) n++;
        if (!hasStorage()) n++;
        return n;
    }

    /** Pedido ya hecho antes y el sistema ya no vuelve a preguntar: hay que ir a Ajustes del telefono. */
    boolean blocked(String perm) {
        return Build.VERSION.SDK_INT >= 23 && checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED
                && sp.getBoolean("asked_" + perm, false) && !shouldShowRequestPermissionRationale(perm);
    }

    /** Pide todos los permisos que falten: primero los normales, luego "Mostrar sobre otras apps". */
    void startPermFlow(boolean manual) {
        ArrayList<String> need = new ArrayList<String>();
        boolean stuck = false;
        if (Build.VERSION.SDK_INT >= 23) {
            ArrayList<String> all = new ArrayList<String>();
            if (!hasAudio()) all.add("android.permission.RECORD_AUDIO");
            if (Build.VERSION.SDK_INT >= 33 && !hasNotif()) all.add("android.permission.POST_NOTIFICATIONS");
            if (Build.VERSION.SDK_INT < 29 && !hasStorage()) all.add("android.permission.WRITE_EXTERNAL_STORAGE");
            for (int i = 0; i < all.size(); i++) {
                if (blocked(all.get(i))) stuck = true; else need.add(all.get(i));
            }
        }
        if (!need.isEmpty()) {
            SharedPreferences.Editor e = sp.edit();
            for (int i = 0; i < need.size(); i++) e.putBoolean("asked_" + need.get(i), true);
            e.apply();
            requestPermissions(need.toArray(new String[0]), 10);
            return;
        }
        if (stuck && manual) {
            openAppSettings();
            return;
        }
        askOverlay();
    }

    void askOverlay() {
        if (!hasOverlay()) {
            sp.edit().putBoolean("ovl_asked", true).apply();
            dlg("Mostrar sobre otras apps", "Con este permiso la cuenta atrás animada aparece sobre cualquier app. Es obligatorio para grabar: en la pantalla que se abre, activa RecLite y vuelve.",
                    null, "Permitir", false, new Runnable() { public void run() { openOverlaySettings(); } });
        }
    }

    void openOverlaySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) { toast("No se pudo abrir el permiso"); }
    }

    void openAppSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            toast("Entra en Permisos y actívalos");
        } catch (Exception e) { toast("No se pudo abrir los ajustes"); }
    }

    /** which: 0 micrófono, 1 notificaciones, 2 sobre otras apps, 3 almacenamiento */
    void grantPerm(int which) {
        if (which == 2) { openOverlaySettings(); return; }
        if (Build.VERSION.SDK_INT < 23) return;
        String perm = which == 0 ? "android.permission.RECORD_AUDIO"
                : (which == 1 ? "android.permission.POST_NOTIFICATIONS" : "android.permission.WRITE_EXTERNAL_STORAGE");
        if (blocked(perm)) { openAppSettings(); return; }
        sp.edit().putBoolean("asked_" + perm, true).apply();
        requestPermissions(new String[]{perm}, 11);
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        if (code == 2) { askProjection(); return; }
        if (code == 12) {
            fillTutPerms();
            if (tutRoot != null && Build.VERSION.SDK_INT >= 23 && !hasOverlay()) tutOverlay();
            return;
        }
        if (code == 10) askOverlay();
        if (code == 11 && tutRoot != null) {
            if (tutIdx == 0) fillTutPerms();
            return;
        }
        if (tutRoot == null && (page == 0 || page == 2)) showPage(page, false);
    }

    View permBanner(int miss) {
        LinearLayout b = hbox();
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        b.setBackground(cardBg(Theme.PRI_C, 24));
        b.addView(circle(IconView.INFO, 40, 22, Theme.PRI, Theme.ON_PRI));
        LinearLayout tx = column();
        tx.addView(t("Faltan permisos", 16, Theme.ON_PRI_C, 1));
        tx.addView(t(miss == 1 ? "Falta 1 para poder grabar" : "Faltan " + miss + " para poder grabar", 13, Theme.ON_PRI_C, 0), lp(MATCH, WRAP, 1));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, WRAP, 1);
        tp.leftMargin = dp(12);
        b.addView(tx, tp);
        TextView bt = t("Conceder", 14, Theme.ON_PRI, 1);
        bt.setGravity(Gravity.CENTER);
        bt.setPadding(dp(16), 0, dp(16), 0);
        bt.setBackground(rip(Theme.PRI, 20));
        bt.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { startPermFlow(true); } });
        press(bt);
        b.addView(bt, new LinearLayout.LayoutParams(WRAP, dp(40)));
        return b;
    }

    // ---------- pagina GRABAR ----------

    View buildRecord() {
        LinearLayout c = column();
        int miss = missingPerms();
        if (miss > 0) c.addView(permBanner(miss), lp(MATCH, WRAP, 4));

        // tarjeta principal: estado, tiempo y boton grande
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(16));
        heroBg = cardBg(Theme.SURF2, 28);
        hero.setBackground(heroBg);

        statusChip = hbox();
        statusChip.setPadding(dp(10), dp(5), dp(12), dp(5));
        recDot = new View(this);
        statusChip.addView(recDot, new LinearLayout.LayoutParams(dp(8), dp(8)));
        tvStatus = t("LISTO", 12, Theme.ON_SEC_C, 1);
        tvStatus.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams sp1 = new LinearLayout.LayoutParams(WRAP, WRAP);
        sp1.leftMargin = dp(7);
        statusChip.addView(tvStatus, sp1);
        hero.addView(statusChip, new LinearLayout.LayoutParams(WRAP, WRAP));

        tvTimer = t("00:00", 60, Theme.TXT, 2);
        tvTimer.setFontFeatureSettings("tnum");
        hero.addView(tvTimer, lp(WRAP, WRAP, 8));
        tvSub = t("", 13, Theme.TXT2, 0);
        tvSub.setGravity(Gravity.CENTER);
        hero.addView(tvSub, lp(MATCH, WRAP, 0));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        View spacer = new View(this);
        row.addView(spacer, new LinearLayout.LayoutParams(dp(56), dp(56)));
        recBtn = new RecButton(this);
        recBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { onRecClick(); } });
        press(recBtn);
        LinearLayout.LayoutParams rb = new LinearLayout.LayoutParams(dp(160), dp(160));
        row.addView(recBtn, rb);
        btnPause = circle(IconView.PAUSE, 56, 24, Theme.SURF3, Theme.TXT);
        btnPauseIcon = (IconView) btnPause.getChildAt(0);
        btnPause.setVisibility(View.INVISIBLE);
        btnPause.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startService(svc(RecorderService.A_PAUSE)); }
        });
        press(btnPause);
        row.addView(btnPause);
        hero.addView(row, lp(MATCH, WRAP, 4));
        tvHint = t("Toca el botón para empezar", 14, Theme.TXT2, 1);
        hero.addView(tvHint, lp(WRAP, WRAP, 0));
        c.addView(hero, lp(MATCH, WRAP, miss > 0 ? 12 : 4));

        // perfiles
        LinearLayout head = hbox();
        head.addView(t("Perfil de grabación", 16, Theme.TXT, 1), new LinearLayout.LayoutParams(0, WRAP, 1));
        tvProfTag = t("Personalizado", 12, Theme.ON_SEC_C, 1);
        tvProfTag.setPadding(dp(10), dp(3), dp(10), dp(3));
        tvProfTag.setBackground(shape(Theme.SEC_C, 10));
        tvProfTag.setVisibility(View.GONE);
        head.addView(tvProfTag);
        c.addView(head, lp(MATCH, WRAP, 24));
        c.addView(t("Toca uno: ajusta resolución, fluidez y bitrate por ti.", 13, Theme.TXT2, 0), lp(MATCH, WRAP, 2));
        LinearLayout list = column();
        for (int i = 0; i < Cfg.PRESET_NAMES.length; i++) list.addView(profileRow(i), lp(MATCH, WRAP, i == 0 ? 0 : 10));
        c.addView(list, lp(MATCH, WRAP, 12));

        // mis perfiles
        LinearLayout mh = hbox();
        mh.addView(t("Mis perfiles", 16, Theme.TXT, 1), new LinearLayout.LayoutParams(0, WRAP, 1));
        TextView saveBtn = t("Guardar actual", 13, Theme.PRI, 1);
        saveBtn.setGravity(Gravity.CENTER);
        saveBtn.setPadding(dp(14), 0, dp(14), 0);
        saveBtn.setBackground(rip(outline(Theme.OUTLINE, 18), 18, Theme.RIPPLE));
        saveBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { saveMineDialog(); } });
        press(saveBtn);
        mh.addView(saveBtn, new LinearLayout.LayoutParams(WRAP, dp(36)));
        c.addView(mh, lp(MATCH, WRAP, 22));
        c.addView(t("Guarda tu resolución, fps y bitrate de ahora para usarlos con un toque.", 13, Theme.TXT2, 0), lp(MATCH, WRAP, 2));
        mineBox = column();
        c.addView(mineBox, lp(MATCH, WRAP, 12));
        fillMine();
        selectProfile(Cfg.matchPreset(sp), false);

        // audio y galeria
        LinearLayout opt = vbox(16);
        opt.setBackground(cardBg(Theme.SURF2, 24));
        LinearLayout ah = hbox();
        ah.addView(icon(IconView.MIC, 20, Theme.PRI));
        LinearLayout.LayoutParams ahp = new LinearLayout.LayoutParams(WRAP, WRAP);
        ahp.leftMargin = dp(10);
        ah.addView(t("Audio", 16, Theme.TXT, 1), ahp);
        opt.addView(ah);
        FlowLayout fl = new FlowLayout(this, dp(8), dp(8));
        fillChips(fl, Cfg.AUD_I, false);
        opt.addView(fl, lp(MATCH, WRAP, 12));
        View div = new View(this);
        div.setBackgroundColor(Theme.OUTLINE);
        div.setAlpha(0.5f);
        opt.addView(div, lp(MATCH, 1, 14));
        LinearLayout gr = hbox();
        gr.addView(icon(IconView.IMAGE, 20, Theme.PRI));
        LinearLayout gt = column();
        gt.addView(t("Copiar a la galería", 16, Theme.TXT, 1));
        gt.addView(t("Además de guardarse en la app", 12, Theme.TXT2, 0));
        LinearLayout.LayoutParams gtp = new LinearLayout.LayoutParams(0, WRAP, 1);
        gtp.leftMargin = dp(10);
        gr.addView(gt, gtp);
        gr.addView(sw(g(Cfg.GAL_I) == 1, new BoolCb() {
            public void on(boolean v) { sp.edit().putInt(Cfg.KEYS[Cfg.GAL_I], v ? 1 : 0).apply(); }
        }));
        opt.addView(gr, lp(MATCH, WRAP, 14));
        c.addView(opt, lp(MATCH, WRAP, 18));

        // espacio
        LinearLayout inf = hbox();
        inf.setPadding(dp(6), 0, dp(6), 0);
        inf.addView(icon(IconView.STORAGE, 18, Theme.TXT2));
        tvStore = t(storeText(), 13, Theme.TXT2, 0);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, WRAP, 1);
        ip.leftMargin = dp(8);
        inf.addView(tvStore, ip);
        c.addView(inf, lp(MATCH, WRAP, 14));

        // ultima grabacion
        File[] fs = Media.list(this);
        if (fs.length > 0) {
            c.addView(t("Última grabación", 16, Theme.TXT, 1), lp(WRAP, WRAP, 24));
            c.addView(recCard(fs[0]), lp(MATCH, WRAP, 10));
        }
        stagger(c);
        return scroll(c);
    }

    String storeText() {
        long free = 0;
        try { free = new StatFs(Cfg.dir(this).getPath()).getAvailableBytes(); } catch (Exception e) {}
        return Media.bytes(free) + " libres · " + Cfg.BRM[Cfg.get(sp, Cfg.BRM_I)] + (Cfg.get(sp, Cfg.BRM_I) == 0 ? " (bitrate)" : "");
    }

    /** Tarjeta de perfil (la usan la pantalla principal y el tutorial): icono, nombre, descripción y datos en píldoras. */
    class ProfView {
        final int[] vals;
        LinearLayout row;
        GradientDrawable bg, icBg, ckBg;
        IconView icon, ck;
        TextView name, desc;
        GradientDrawable[] pb = new GradientDrawable[3];
        TextView[] pt = new TextView[3];
        boolean on;

        ProfView(int preset, String nm, String ds, int icType, View.OnClickListener l) {
            this(Cfg.PRESETS[preset], nm, ds, icType, l);
        }

        ProfView(int[] v, String nm, String ds, int icType, View.OnClickListener l) {
            vals = v;
            Context cx = MainActivity.this;
            row = hbox();
            row.setPadding(dp(14), dp(14), dp(14), dp(14));
            bg = cardBg(Theme.SURF2, 24);
            row.setBackground(rip(bg, 24, Theme.RIPPLE));

            FrameLayout ic = new FrameLayout(cx);
            icBg = shape(Theme.SURF3, 24);
            ic.setBackground(icBg);
            icon = new IconView(cx, icType, Theme.PRI);
            ic.addView(icon, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            row.addView(ic, new LinearLayout.LayoutParams(dp(48), dp(48)));

            LinearLayout mid = column();
            name = t(nm, 16, Theme.TXT, 1);
            desc = t(ds, 12, Theme.TXT2, 0);
            mid.addView(name);
            mid.addView(desc, lp(MATCH, WRAP, 1));
            FlowLayout fl = new FlowLayout(cx, dp(6), dp(6));
            String[] tx = {Cfg.RES[vals[0]], Cfg.FPS_V[vals[1]] + " fps", Cfg.mbpsText(vals)};
            for (int k = 0; k < 3; k++) {
                TextView pill = t(tx[k], 12, Theme.TXT2, 1);
                pill.setPadding(dp(10), dp(3), dp(10), dp(3));
                pb[k] = shape(Theme.SURF3, 10);
                pill.setBackground(pb[k]);
                pt[k] = pill;
                fl.addView(pill);
            }
            mid.addView(fl, lp(MATCH, WRAP, 9));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, WRAP, 1);
            mp.leftMargin = dp(14);
            row.addView(mid, mp);

            FrameLayout ckf = new FrameLayout(cx);
            ckBg = new GradientDrawable();
            ckBg.setShape(GradientDrawable.OVAL);
            ckf.setBackground(ckBg);
            ck = new IconView(cx, IconView.CHECK, Theme.ON_PRI);
            ckf.addView(ck, new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(26), dp(26));
            cp.leftMargin = dp(10);
            row.addView(ckf, cp);

            row.setOnClickListener(l);
            press(row);
            style(false, false);
        }

        void style(boolean now, boolean animate) {
            int to = now ? Theme.PRI_C : Theme.SURF2, from = now ? Theme.SURF2 : Theme.PRI_C;
            if (animate && now != on) animColor(bg, from, to); else bg.setColor(to);
            int pill = Theme.mix(Theme.PRI_C, Theme.ON_PRI_C, 0.16f);
            name.setTextColor(now ? Theme.ON_PRI_C : Theme.TXT);
            desc.setTextColor(now ? Theme.ON_PRI_C : Theme.TXT2);
            icBg.setColor(now ? Theme.PRI : Theme.SURF3);
            icon.setColor(now ? Theme.ON_PRI : Theme.PRI);
            for (int k = 0; k < 3; k++) {
                pb[k].setColor(now ? pill : Theme.SURF3);
                pt[k].setTextColor(now ? Theme.ON_PRI_C : Theme.TXT2);
            }
            ckBg.setColor(now ? Theme.PRI : 0);
            ckBg.setStroke(now ? 0 : dp(2), Theme.OUTLINE);
            ck.setAlpha(now ? 1f : 0f);
            if (now && animate && !on) { pop(ck); pop(icon); }
            on = now;
        }
    }

    View profileRow(final int i) {
        pv[i] = new ProfView(i, Cfg.PRESET_NAMES[i], Cfg.PRESET_DESC[i], Cfg.PRESET_ICON[i], new View.OnClickListener() {
            public void onClick(View v) {
                if (RecorderService.recording || RecorderService.starting) { toast("Detén la grabación para cambiar el perfil"); return; }
                Cfg.applyPreset(sp, i);
                mineSel = -1;
                selectProfile(i, true);
                updInfo();
            }
        });
        return pv[i].row;
    }

    /** Indice del perfil propio elegido, si sigue coincidiendo con los ajustes actuales (si no, -1). */
    int effMine() {
        if (mineSel >= 0 && mineSel < mineData.size() && Cfg.matchMine(sp, mineData.get(mineSel))) return mineSel;
        mineSel = -1;
        return -1;
    }

    void selectProfile(int sel, boolean animate) {
        int ms = effMine();
        for (int i = 0; i < pv.length; i++) if (pv[i] != null) pv[i].style(ms < 0 && i == sel, animate && profSel != -2);
        profSel = sel;
        syncMine(animate);
    }

    /** Pinta de morado el perfil propio elegido. Si ninguno esta elegido, marca el que coincida solo cuando no hay perfil base. */
    void syncMine(boolean animate) {
        int ms = effMine();
        boolean any = false;
        for (int i = 0; i < mv.size() && i < mineData.size(); i++) {
            boolean on = ms >= 0 ? i == ms : (profSel < 0 && Cfg.matchMine(sp, mineData.get(i)));
            any |= on;
            mv.get(i).style(on, animate && profSel != -2);
        }
        if (tvProfTag != null) tvProfTag.setVisibility(profSel < 0 && !any ? View.VISIBLE : View.GONE);
    }

    void fillMine() {
        if (mineBox == null) return;
        mineBox.removeAllViews();
        mv.clear();
        mineData = Cfg.mine(sp);
        if (mineData.isEmpty()) {
            mineBox.addView(t("Aún no tienes perfiles propios. Ajusta resolución, fps y bitrate en Ajustes y toca «Guardar actual».", 13, Theme.TXT2, 0));
            return;
        }
        for (int i = 0; i < mineData.size(); i++) {
            final int k = i;
            final Cfg.Mine m = mineData.get(i);
            ProfView pw = new ProfView(m.v, m.name, "Calidad " + Cfg.BUF[m.v[2]].toLowerCase(), IconView.STACK, new View.OnClickListener() {
                public void onClick(View v) {
                    if (RecorderService.recording || RecorderService.starting) { toast("Detén la grabación para cambiar el perfil"); return; }
                    Cfg.applyMine(sp, m);
                    mineSel = k;
                    selectProfile(Cfg.matchPreset(sp), true);
                    updInfo();
                }
            });
            FrameLayout del = circle(IconView.TRASH, 36, 18, 0, Theme.TXT2);
            LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(dp(36), dp(36));
            dp2.leftMargin = dp(4);
            del.setLayoutParams(dp2);
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    dlg("¿Borrar perfil?", m.name, null, "Borrar", true, new Runnable() {
                        public void run() {
                            if (mineSel == k) mineSel = -1; else if (mineSel > k) mineSel--;
                            Cfg.deleteMine(sp, k);
                            fillMine();
                            selectProfile(Cfg.matchPreset(sp), false);
                        }
                    });
                }
            });
            press(del);
            pw.row.addView(del);
            mv.add(pw);
            mineBox.addView(pw.row, lp(MATCH, WRAP, i == 0 ? 0 : 10));
        }
        syncMine(false);
    }

    void saveMineDialog() {
        if (Cfg.mine(sp).size() >= Cfg.MINE_MAX) { toast("Máximo " + Cfg.MINE_MAX + " perfiles: borra uno para guardar otro"); return; }
        final EditText et = new EditText(this);
        et.setText("Mi perfil " + (Cfg.mine(sp).size() + 1));
        et.setSingleLine(true);
        et.setTypeface(Fonts.reg);
        et.setTextColor(Theme.TXT);
        et.setTextSize(16);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setPadding(dp(16), dp(12), dp(16), dp(12));
        et.setBackground(shape(Theme.SURF, 14));
        et.setSelectAllOnFocus(true);
        String nums = Cfg.RES[Cfg.get(sp, Cfg.RES_I)] + " · " + Cfg.FPS_V[Cfg.get(sp, Cfg.FPS_I)] + " fps · "
                + Cfg.mbpsText(Cfg.currentVals(sp));
        dlg("Guardar mi perfil", nums, et, "Guardar", false, new Runnable() {
            public void run() {
                int r = Cfg.addMine(sp, et.getText().toString());
                if (r == 0) { toast("Escribe un nombre"); return; }
                if (r < 0) { toast("Máximo " + Cfg.MINE_MAX + " perfiles: borra uno para guardar otro"); return; }
                toast("Perfil guardado");
                String nm = et.getText().toString().trim();
                mineSel = -1;
                ArrayList<Cfg.Mine> nl = Cfg.mine(sp);
                for (int i = 0; i < nl.size(); i++) if (nl.get(i).name.equalsIgnoreCase(nm)) mineSel = i;
                fillMine();
                selectProfile(Cfg.matchPreset(sp), false);
            }
        });
    }

    /** Refresca los textos que dependen de los ajustes (sin reconstruir la pagina). */
    void updInfo() {
        if (page != 0) return;
        if (tvSub != null && !RecorderService.recording && !RecorderService.starting) tvSub.setText(Cfg.summary(this, sp));
        if (tvStore != null) tvStore.setText(storeText());
        if (profSel != -2) {
            int m = Cfg.matchPreset(sp);
            selectProfile(m, true);
        }
    }

    View chip(String label, boolean sel, View.OnClickListener l) {
        LinearLayout ch = hbox();
        ch.setPadding(dp(sel ? 10 : 16), 0, dp(16), 0);
        ch.setBackground(sel ? rip(Theme.SEC_C, 20) : rip(outline(Theme.OUTLINE, 20), 20, Theme.RIPPLE));
        if (sel) {
            IconView ck = new IconView(this, IconView.CHECK, Theme.ON_SEC_C);
            ch.addView(ck, new LinearLayout.LayoutParams(dp(18), dp(18)));
        }
        TextView tx = t(label, 14, sel ? Theme.ON_SEC_C : Theme.TXT2, 1);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(WRAP, WRAP);
        if (sel) tp.leftMargin = dp(6);
        ch.addView(tx, tp);
        ch.setMinimumHeight(dp(40));
        ch.setOnClickListener(l);
        press(ch);
        ch.setLayoutParams(new LinearLayout.LayoutParams(WRAP, dp(40)));
        return ch;
    }

    // ---------- estado en vivo ----------

    void refresh() {
        boolean rec = RecorderService.recording, st = RecorderService.starting;
        if (wasRec && !rec) {
            wasRec = false;
            if (page == 0 || page == 1) { showPage(page, false); return; }
        }
        wasRec = rec;
        if (page != 0 || tvTimer == null) return;
        boolean paused = RecorderService.paused;
        boolean counting = st && !rec && RecorderService.left > 0;
        boolean busy = rec || st;
        boolean live = rec && !paused;
        String ts = counting ? String.valueOf(RecorderService.left) : Media.time(RecorderService.secs);
        if (live && !ts.equals(tvTimer.getText().toString())) {
            tvTimer.setScaleX(1.07f);
            tvTimer.setScaleY(1.07f);
            tvTimer.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
        }
        tvTimer.setText(ts);
        tvTimer.setTextColor(live ? Theme.REC_SOFT : Theme.TXT);
        tvStatus.setText(rec ? (paused ? "EN PAUSA" : "GRABANDO") : (st ? (counting ? "CUENTA ATRÁS" : "PREPARANDO") : "LISTO"));
        statusChip.setBackground(shape(live ? Theme.REC_C : Theme.SEC_C, 14));
        tvStatus.setTextColor(live ? Theme.ON_REC_C : Theme.ON_SEC_C);
        recDot.setBackground(shape(live ? Theme.REC : Theme.PRI, 4));
        if (live && !pulsing) {
            AlphaAnimation a = new AlphaAnimation(1f, 0.25f);
            a.setDuration(700);
            a.setRepeatMode(Animation.REVERSE);
            a.setRepeatCount(Animation.INFINITE);
            recDot.startAnimation(a);
            pulsing = true;
        } else if (!live && pulsing) {
            recDot.clearAnimation();
            pulsing = false;
        }
        tvSub.setText(rec ? RecorderService.info + (RecorderService.live.length() > 0 ? "\n" + RecorderService.live : "") : Cfg.summary(this, sp));
        tvHint.setText(!busy ? "Toca el botón para empezar" : (counting ? "Toca para cancelar" : (paused ? "En pausa · toca para detener" : "Toca para detener")));

        // boton grande
        int mode = busy ? (paused ? 2 : 1) : 0;
        if (mode != lastMode) {
            recBtn.setMode(mode, lastMode != -1);
            if (lastMode != -1) pop(recBtn);
            lastMode = mode;
        }
        // el fondo de la tarjeta se tiñe de rojo mientras graba
        int hl = live ? 1 : 0;
        if (hl != lastHero) {
            int target = live ? Theme.mix(Theme.SURF2, Theme.REC_C, 0.45f) : Theme.SURF2;
            int from = live ? Theme.SURF2 : Theme.mix(Theme.SURF2, Theme.REC_C, 0.45f);
            if (lastHero == -1) heroBg.setColor(target); else animColor(heroBg, from, target);
            lastHero = hl;
        }
        // boton de pausa
        int pv = rec ? 1 : 0;
        if (pv != lastPause) {
            boolean first = lastPause == -1;
            lastPause = pv;
            if (pv == 1) {
                btnPause.setVisibility(View.VISIBLE);
                if (!first) {
                    btnPause.setAlpha(0f);
                    btnPause.setScaleX(0.5f);
                    btnPause.setScaleY(0.5f);
                    btnPause.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(320).setInterpolator(new OvershootInterpolator(2.5f)).start();
                }
            } else if (first) {
                btnPause.setVisibility(View.INVISIBLE);
            } else {
                btnPause.animate().alpha(0f).scaleX(0.5f).scaleY(0.5f).setStartDelay(0).setDuration(180).setInterpolator(new AccelerateInterpolator())
                        .withEndAction(new Runnable() { public void run() { if (lastPause == 0) btnPause.setVisibility(View.INVISIBLE); } }).start();
            }
        }
        btnPauseIcon.setType(paused ? IconView.PLAY : IconView.PAUSE);
    }

    // ---------- grabar ----------

    Intent svc(String action) {
        Intent i = new Intent(this, RecorderService.class);
        i.setAction(action);
        return i;
    }

    void onRecClick() {
        if (RecorderService.recording || RecorderService.starting) {
            startService(svc(RecorderService.A_STOP));
            return;
        }
        // sin TODOS los permisos no se puede grabar
        if (missingPerms() > 0) { permGate(); return; }
        askProjection();
    }

    /** Aviso cuando faltan permisos: no deja grabar hasta concederlos todos. */
    void permGate() {
        int n = missingPerms();
        dlg("Faltan permisos", "Para grabar necesitas conceder todos los permisos (" + n + (n == 1 ? " pendiente" : " pendientes")
                + "). Sin ellos RecLite no puede grabar.", null, "Conceder", false, new Runnable() {
            public void run() { startPermFlow(true); }
        });
    }

    void askProjection() {
        MediaProjectionManager pm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(pm.createScreenCaptureIntent(), 1);
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (req == 1 && res == RESULT_OK && d != null) {
            if (missingPerms() > 0) { permGate(); return; }
            Intent i = new Intent(this, RecorderService.class);
            i.putExtra("code", res);
            i.putExtra("data", d);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            moveTaskToBack(true);
        }
    }

    // ---------- pagina BIBLIOTECA ----------

    View buildLibrary() {
        LinearLayout c = column();
        final File[] fs = Media.list(this);
        long total = 0;
        for (int i = 0; i < fs.length; i++) total += fs[i].length();
        long free = 0;
        try { free = new StatFs(Cfg.dir(this).getPath()).getAvailableBytes(); } catch (Exception e) {}

        LinearLayout hero = vbox(20);
        hero.setBackground(cardBg(Theme.SURF2, 28));
        LinearLayout tag = hbox();
        tag.setPadding(dp(10), dp(5), dp(12), dp(5));
        tag.setBackground(shape(Theme.SEC_C, 14));
        tag.addView(icon(IconView.LIBRARY, 14, Theme.ON_SEC_C));
        TextView tg = t("BIBLIOTECA", 12, Theme.ON_SEC_C, 1);
        tg.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams tgp = new LinearLayout.LayoutParams(WRAP, WRAP);
        tgp.leftMargin = dp(7);
        tag.addView(tg, tgp);
        hero.addView(tag, new LinearLayout.LayoutParams(WRAP, WRAP));
        hero.addView(t(fs.length + (fs.length == 1 ? " video" : " videos"), 34, Theme.TXT, 2), lp(WRAP, WRAP, 12));
        hero.addView(t(Media.bytes(total) + " usados · " + Media.bytes(free) + " libres", 14, Theme.TXT2, 0), lp(MATCH, WRAP, 0));
        if (fs.length > 0) {
            LinearLayout b = hbox();
            b.setGravity(Gravity.CENTER);
            b.setBackground(rip(Theme.PRI, 26));
            b.addView(icon(IconView.IMAGE, 20, Theme.ON_PRI));
            TextView bt = t("Copiar todo a la galería", 15, Theme.ON_PRI, 1);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(WRAP, WRAP);
            bp.leftMargin = dp(8);
            b.addView(bt, bp);
            b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { exportAll(fs); } });
            press(b);
            hero.addView(b, lp(MATCH, dp(52), 18));
            hero.addView(selRow(fs), lp(MATCH, dp(44), 10));
        }
        c.addView(hero, lp(MATCH, WRAP, 4));

        if (fs.length == 0) {
            LinearLayout e = new LinearLayout(this);
            e.setOrientation(LinearLayout.VERTICAL);
            e.setGravity(Gravity.CENTER_HORIZONTAL);
            e.setPadding(0, dp(40), 0, 0);
            e.addView(circle(IconView.VIDEO, 84, 38, Theme.SURF2, Theme.PRI));
            e.addView(t("Aún no hay grabaciones", 18, Theme.TXT, 1), lp(WRAP, WRAP, 16));
            e.addView(t("Ve a Grabar y toca el botón para empezar", 14, Theme.TXT2, 0), lp(WRAP, WRAP, 4));
            c.addView(e, lp(MATCH, WRAP, 0));
        } else {
            for (int i = 0; i < fs.length && i < 80; i++) c.addView(recCard(fs[i]), lp(MATCH, WRAP, 12));
        }
        stagger(c);
        return scroll(c);
    }

    void exportAll(final File[] fs) {
        if (!ensureStorage()) return;
        toast("Copiando " + fs.length + " videos…");
        new Thread(new Runnable() {
            public void run() {
                int ok = 0;
                for (int i = 0; i < fs.length; i++) {
                    try { Media.exportSync(MainActivity.this, fs[i]); ok++; } catch (Exception e) {}
                }
                final int n = ok;
                runOnUiThread(new Runnable() { public void run() { toast("Copiados " + n + " de " + fs.length + " a Movies/GrabaPantalla"); } });
            }
        }).start();
    }

    boolean ensureStorage() {
        if (Media.canExport(this)) return true;
        sp.edit().putBoolean("asked_android.permission.WRITE_EXTERNAL_STORAGE", true).apply();
        requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 3);
        toast("Concede el permiso y vuelve a intentarlo");
        return false;
    }

    View recCard(final File f) {
        final LinearLayout card = vbox(12);
        final boolean pick = selMode && page == 1;
        card.setBackground(cardBg(pick && sel.contains(f.getAbsolutePath()) ? Theme.PRI_C : Theme.SURF2, 24));
        LinearLayout row = hbox();

        FrameLayout th = new FrameLayout(this);
        th.setBackgroundColor(Theme.SURF3);
        final ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        th.addView(iv, new FrameLayout.LayoutParams(MATCH, MATCH));
        th.addView(circle(IconView.PLAY, 34, 18, 0x99000000, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
        if (Build.VERSION.SDK_INT >= 21) {
            th.setOutlineProvider(new ViewOutlineProvider() {
                public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(16)); }
            });
            th.setClipToOutline(true);
        }
        if (!pick) {
            th.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { play(f); } });
            press(th);
        }
        row.addView(th, new LinearLayout.LayoutParams(dp(88), dp(88)));

        LinearLayout info = column();
        TextView name = t(f.getName(), 15, Theme.TXT, 1);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        info.addView(name);
        final TextView m1 = t("…", 13, Theme.TXT2, 0);
        info.addView(m1, lp(MATCH, WRAP, 4));
        TextView m2 = t(Media.bytes(f.length()) + " · " + Media.when(f.lastModified()), 13, Theme.TXT2, 0);
        info.addView(m2, lp(MATCH, WRAP, 1));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, WRAP, 1);
        ip.leftMargin = dp(14);
        row.addView(info, ip);
        card.addView(row);

        Media.load(f, new Media.Cb() {
            public void done(Media.Info i) {
                if (i.thumb != null) iv.setImageBitmap(i.thumb);
                String sc = Media.spec(i);
                m1.setText(Media.time(i.dur / 1000) + (sc.length() > 0 ? " · " + sc : ""));
            }
        });

        if (pick) {
            View.OnClickListener tg = new View.OnClickListener() {
                public void onClick(View v) {
                    String k = f.getAbsolutePath();
                    boolean now;
                    if (sel.contains(k)) { sel.remove(k); now = false; } else { sel.add(k); now = true; }
                    card.setBackground(cardBg(now ? Theme.PRI_C : Theme.SURF2, 24));
                    updSelBar();
                }
            };
            card.setOnClickListener(tg);
            th.setOnClickListener(tg);
            return card;
        }
        LinearLayout acts = hbox();
        acts.addView(actBtn(IconView.PLAY, Theme.PRI, Theme.ON_PRI, new View.OnClickListener() { public void onClick(View v) { play(f); } }), actLp(false));
        acts.addView(actBtn(IconView.IMAGE, Theme.SURF3, Theme.TXT, new View.OnClickListener() { public void onClick(View v) { export(f); } }), actLp(true));
        acts.addView(actBtn(IconView.SHARE, Theme.SURF3, Theme.TXT, new View.OnClickListener() { public void onClick(View v) { share(f); } }), actLp(true));
        acts.addView(actBtn(IconView.CUT, Theme.SURF3, Theme.TXT, new View.OnClickListener() { public void onClick(View v) { trim(f); } }), actLp(true));
        acts.addView(actBtn(IconView.EDIT, Theme.SURF3, Theme.TXT, new View.OnClickListener() { public void onClick(View v) { rename(f); } }), actLp(true));
        acts.addView(actBtn(IconView.TRASH, Theme.SURF3, Theme.REC_SOFT, new View.OnClickListener() { public void onClick(View v) { confirmDelete(f); } }), actLp(true));
        card.addView(acts, lp(MATCH, WRAP, 12));
        return card;
    }

    LinearLayout.LayoutParams actLp(boolean margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1);
        if (margin) p.leftMargin = dp(8);
        return p;
    }

    View actBtn(int ic, int fill, int color, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(rip(fill, 22));
        f.addView(new IconView(this, ic, color), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        f.setOnClickListener(l);
        press(f);
        return f;
    }

    /** Reproductor integrado a pantalla completa (si falla, abre el reproductor del sistema). */
    void play(final File f) {
        try {
            new VideoPlayer(this, f, new Runnable() { public void run() { playExternal(f); } }).show();
        } catch (Throwable e) {
            playExternal(f);
        }
    }

    // ---------- seleccion multiple ----------

    void updSelBar() {
        if (tvDel != null) tvDel.setText("Borrar (" + sel.size() + ")");
    }

    View selRow(final File[] fs) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.CENTER);
        if (!selMode) {
            TextView a = t("Seleccionar varios", 14, Theme.TXT2, 1);
            a.setGravity(Gravity.CENTER);
            a.setBackground(rip(outline(Theme.OUTLINE, 22), 22, Theme.RIPPLE));
            a.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { selMode = true; sel.clear(); showPage(1, false); }
            });
            press(a);
            r.addView(a, new LinearLayout.LayoutParams(0, MATCH, 1));
            return r;
        }
        TextView all = t("Todo", 14, Theme.TXT2, 1);
        all.setGravity(Gravity.CENTER);
        all.setBackground(rip(outline(Theme.OUTLINE, 22), 22, Theme.RIPPLE));
        all.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sel.clear();
                for (int i = 0; i < fs.length; i++) sel.add(fs[i].getAbsolutePath());
                showPage(1, false);
            }
        });
        press(all);
        r.addView(all, new LinearLayout.LayoutParams(0, MATCH, 1));
        tvDel = t("Borrar (" + sel.size() + ")", 14, Theme.ON_REC_C, 1);
        tvDel.setGravity(Gravity.CENTER);
        tvDel.setBackground(rip(Theme.REC_C, 22));
        tvDel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { confirmDeleteMany(); }
        });
        press(tvDel);
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(0, MATCH, 1.4f);
        dp1.leftMargin = dp(8);
        r.addView(tvDel, dp1);
        TextView no = t("Cancelar", 14, Theme.TXT2, 1);
        no.setGravity(Gravity.CENTER);
        no.setBackground(rip(outline(Theme.OUTLINE, 22), 22, Theme.RIPPLE));
        no.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { selMode = false; sel.clear(); showPage(1, false); }
        });
        press(no);
        LinearLayout.LayoutParams np1 = new LinearLayout.LayoutParams(0, MATCH, 1);
        np1.leftMargin = dp(8);
        r.addView(no, np1);
        return r;
    }

    void confirmDeleteMany() {
        final int n = sel.size();
        if (n == 0) { toast("Toca los videos que quieras borrar"); return; }
        dlg("¿Borrar " + n + (n == 1 ? " grabación?" : " grabaciones?"), "No se pueden recuperar.", null, "Borrar", true, new Runnable() {
            public void run() {
                for (String p : sel) new File(p).delete();
                sel.clear();
                selMode = false;
                showPage(1, false);
            }
        });
    }

    // ---------- recortar (sin recodificar) ----------

    void trim(final File f) {
        Media.load(f, new Media.Cb() {
            public void done(Media.Info i) {
                final long dur = i.dur;
                if (dur < 2000) { toast("El video es muy corto para recortar"); return; }
                LinearLayout box = column();
                final TextView lbl = t("", 14, Theme.TXT, 1);
                final SeekBar a = new SeekBar(MainActivity.this), b = new SeekBar(MainActivity.this);
                a.setMax(1000); b.setMax(1000);
                a.setProgress(0); b.setProgress(1000);
                tint(a); tint(b);
                final Runnable upd = new Runnable() {
                    public void run() {
                        long s = dur * a.getProgress() / 1000, e = dur * b.getProgress() / 1000;
                        lbl.setText("Desde " + Media.time(s / 1000) + "  hasta " + Media.time(e / 1000) + "  (" + Media.time(Math.max(0, e - s) / 1000) + ")");
                    }
                };
                SeekBar.OnSeekBarChangeListener ls = new SeekBar.OnSeekBarChangeListener() {
                    public void onProgressChanged(SeekBar sb, int v, boolean user) {
                        if (user) {
                            if (sb == a && v > b.getProgress() - 20) a.setProgress(Math.max(0, b.getProgress() - 20));
                            if (sb == b && v < a.getProgress() + 20) b.setProgress(Math.min(1000, a.getProgress() + 20));
                        }
                        upd.run();
                    }
                    public void onStartTrackingTouch(SeekBar sb) {}
                    public void onStopTrackingTouch(SeekBar sb) {}
                };
                a.setOnSeekBarChangeListener(ls);
                b.setOnSeekBarChangeListener(ls);
                box.addView(lbl);
                box.addView(t("Inicio", 12, Theme.TXT2, 0), lp(MATCH, WRAP, 12));
                box.addView(a, lp(MATCH, WRAP, 0));
                box.addView(t("Final", 12, Theme.TXT2, 0), lp(MATCH, WRAP, 8));
                box.addView(b, lp(MATCH, WRAP, 0));
                upd.run();
                dlg("Recortar", "Sin recodificar: no pierde calidad y es rápido. El inicio puede adelantarse 1-2 s al cuadro clave anterior. Se guarda como copia.",
                        box, "Guardar recorte", false, new Runnable() {
                            public void run() { trimGo(f, dur * a.getProgress() / 1000 * 1000, dur * b.getProgress() / 1000 * 1000); }
                        });
            }
        });
    }

    void tint(SeekBar sb) {
        try {
            sb.getProgressDrawable().setColorFilter(Theme.PRI, PorterDuff.Mode.SRC_IN);
            sb.getThumb().setColorFilter(Theme.PRI, PorterDuff.Mode.SRC_IN);
        } catch (Throwable e) {}
    }

    void trimGo(final File f, final long startUs, final long endUs) {
        toast("Recortando…");
        new Thread(new Runnable() {
            public void run() {
                String n = f.getName();
                String base = n.substring(0, n.length() - 4);
                File o = new File(f.getParentFile(), base + "_recorte.mp4");
                int k = 2;
                while (o.exists()) o = new File(f.getParentFile(), base + "_recorte" + (k++) + ".mp4");
                final File outF = o;
                final boolean ok = Trim.cut(f, outF, startUs, endUs);
                if (!ok) outF.delete();
                runOnUiThread(new Runnable() {
                    public void run() {
                        toast(ok ? "Recorte guardado: " + outF.getName() : "No se pudo recortar este video");
                        if (page == 0 || page == 1) showPage(page, false);
                    }
                });
            }
        }).start();
    }

    void playExternal(File f) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(VideoProvider.uri(f), "video/mp4");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) { toast("No hay reproductor de video"); }
    }

    void share(File f) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("video/mp4");
            attachUri(i, f);
            startActivity(Intent.createChooser(i, "Enviar grabación"));
        } catch (Exception e) { toast("No se pudo compartir"); }
    }

    void attachUri(Intent i, File f) {
        android.net.Uri u = VideoProvider.uri(f);
        i.putExtra(Intent.EXTRA_STREAM, u);
        i.setClipData(ClipData.newRawUri("video", u));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    }

    void export(final File f) {
        if (!ensureStorage()) return;
        toast("Copiando a la galería…");
        Media.export(this, f, new Media.Done() {
            public void done(boolean ok) { toast(ok ? "Listo: Movies/GrabaPantalla" : "Error al copiar a la galería"); }
        });
    }

    void confirmDelete(final File f) {
        dlg("¿Borrar grabación?", f.getName(), null, "Borrar", true, new Runnable() {
            public void run() { f.delete(); showPage(page, false); }
        });
    }

    void rename(final File f) {
        final EditText et = new EditText(this);
        String n = f.getName();
        et.setText(n.substring(0, n.length() - 4));
        et.setSingleLine(true);
        et.setTypeface(Fonts.reg);
        et.setTextColor(Theme.TXT);
        et.setTextSize(16);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setPadding(dp(16), dp(12), dp(16), dp(12));
        et.setBackground(shape(Theme.SURF, 14));
        et.setSelectAllOnFocus(true);
        dlg("Renombrar", null, et, "Guardar", false, new Runnable() {
            public void run() {
                String s = et.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
                if (s.length() == 0) return;
                File nf = new File(f.getParentFile(), s + ".mp4");
                if (nf.exists()) { toast("Ya existe ese nombre"); return; }
                if (!f.renameTo(nf)) toast("No se pudo renombrar");
                showPage(page, false);
            }
        });
    }

    /** Dialogo propio con estilo Material 3 y animacion de entrada */
    void dlg(String title, String msg, View extra, String ok, boolean danger, final Runnable onOk) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LinearLayout box = vbox(24);
        box.setBackground(shape(Theme.SURF3, 28));
        box.addView(t(title, 22, Theme.TXT, 0));
        if (msg != null) box.addView(t(msg, 14, Theme.TXT2, 0), lp(MATCH, WRAP, 12));
        if (extra != null) box.addView(extra, lp(MATCH, WRAP, 16));
        LinearLayout bs = hbox();
        bs.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        TextView no = t(ok == null ? "Cerrar" : "Cancelar", 14, Theme.PRI, 1);
        no.setPadding(dp(16), dp(10), dp(16), dp(10));
        no.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
        bs.addView(no);
        if (ok != null) {
            TextView yes = t(ok, 14, danger ? Theme.ON_REC_C : Theme.ON_PRI, 1);
            yes.setPadding(dp(20), dp(10), dp(20), dp(10));
            yes.setBackground(rip(danger ? Theme.REC_C : Theme.PRI, 20));
            yes.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { d.dismiss(); onOk.run(); }
            });
            LinearLayout.LayoutParams yp = new LinearLayout.LayoutParams(WRAP, WRAP);
            yp.leftMargin = dp(8);
            bs.addView(yes, yp);
        }
        box.addView(bs, lp(MATCH, WRAP, 20));
        d.setContentView(box);
        Window w = d.getWindow();
        w.setBackgroundDrawable(new ColorDrawable(0));
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
        w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.9f), WRAP);
        box.setAlpha(0f);
        box.setScaleX(0.9f);
        box.setScaleY(0.9f);
        box.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(240).setInterpolator(new DecelerateInterpolator(1.6f)).start();
    }

    // ---------- pagina AJUSTES ----------

    View buildSettings() {
        LinearLayout c = column();

        LinearLayout sum = vbox(20);
        sum.setBackground(cardBg(Theme.PRI_C, 28));
        sum.addView(t("Tu configuración", 13, Theme.ON_PRI_C, 1));
        tvSetEst = t("", 20, Theme.ON_PRI_C, 0);
        sum.addView(tvSetEst, lp(MATCH, WRAP, 6));
        c.addView(sum, lp(MATCH, WRAP, 4));
        tvSetHint = t("", 13, Theme.ON_SEC_C, 0);
        tvSetHint.setPadding(dp(16), dp(12), dp(16), dp(12));
        tvSetHint.setBackground(shape(Theme.SEC_C, 20));
        c.addView(tvSetHint, lp(MATCH, WRAP, 8));
        updSummary();
        c.addView(deviceCard(), lp(MATCH, WRAP, 8));

        addGroup(c, "Video", new int[]{Cfg.RES_I, Cfg.ORI_I, Cfg.FPS_I, Cfg.BRM_I, Cfg.BUF_I, Cfg.COD_I});
        addGroup(c, "Audio", new int[]{Cfg.AUD_I});
        addGroup(c, "Grabación", new int[]{Cfg.CNT_I, Cfg.LIM_I, Cfg.SIZ_I, Cfg.GAL_I, Cfg.PRO_I});
        addGroup(c, "Apariencia", new int[]{Cfg.THM_I, Cfg.MOD_I, Cfg.AMO_I});
        permSig = sigPerms();
        addPermCard(c);

        // ayuda
        c.addView(t("Ayuda", 14, Theme.PRI, 1), lp(WRAP, WRAP, 22));
        LinearLayout hp = hbox();
        hp.setPadding(dp(16), dp(14), dp(16), dp(14));
        hp.setBackground(rip(cardBg(Theme.SURF2, 24), 24, Theme.RIPPLE));
        hp.addView(circle(IconView.HELP, 40, 22, Theme.SURF3, Theme.PRI));
        LinearLayout ht = column();
        ht.addView(t("Ver el tutorial otra vez", 16, Theme.TXT, 1));
        ht.addView(t("Un repaso rápido de cómo se usa la app", 12, Theme.TXT2, 0));
        LinearLayout.LayoutParams htp = new LinearLayout.LayoutParams(0, WRAP, 1);
        htp.leftMargin = dp(12);
        hp.addView(ht, htp);
        hp.addView(icon(IconView.CHEVRON, 20, Theme.TXT2));
        hp.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showTutorial(null); } });
        press(hp);
        c.addView(hp, lp(MATCH, WRAP, 8));

        LinearLayout rs = hbox();
        rs.setGravity(Gravity.CENTER);
        rs.setBackground(rip(outline(Theme.OUTLINE, 26), 26, Theme.RIPPLE));
        rs.addView(icon(IconView.RESET, 20, Theme.TXT2));
        TextView rt = t("Restablecer ajustes", 15, Theme.TXT2, 1);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(WRAP, WRAP);
        rp.leftMargin = dp(8);
        rs.addView(rt, rp);
        rs.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dlg("¿Restablecer ajustes?", "Se restauran los valores recomendados. Tus videos y tus perfiles guardados no se tocan.", null, "Restablecer", false, new Runnable() {
                    public void run() {
                        String keep = sp.getString(Cfg.MINE_KEY, "");
                        sp.edit().clear().putString(Cfg.MINE_KEY, keep).apply();
                        fadeRecreate();
                    }
                });
            }
        });
        press(rs);
        c.addView(rs, lp(MATCH, dp(52), 26));
        c.addView(t("RecLite 2.8", 12, Theme.TXT2, 0), lp(WRAP, WRAP, 14));
        stagger(c);
        return scroll(c);
    }

    void addGroup(LinearLayout c, String name, int[] ks) {
        c.addView(t(name, 14, Theme.PRI, 1), lp(WRAP, WRAP, 22));
        for (int i = 0; i < ks.length; i++) {
            final int k = ks[i];
            if (k == Cfg.THM_I) { c.addView(themeCard(), lp(MATCH, WRAP, 8)); continue; }
            LinearLayout card = vbox(18);
            card.setBackground(cardBg(Theme.SURF2, 24));
            if (k == Cfg.GAL_I || k == Cfg.AMO_I || k == Cfg.PRO_I) {
                LinearLayout r = hbox();
                LinearLayout tx = column();
                tx.addView(t(Cfg.TITLES[k], 17, Theme.TXT, 1));
                tx.addView(t(Cfg.DESCS[k], 13, Theme.TXT2, 0), lp(MATCH, WRAP, 3));
                LinearLayout.LayoutParams txp = new LinearLayout.LayoutParams(0, WRAP, 1);
                txp.rightMargin = dp(14);
                r.addView(tx, txp);
                r.addView(sw(g(k) == 1, new BoolCb() {
                    public void on(boolean v) {
                        sp.edit().putInt(Cfg.KEYS[k], v ? 1 : 0).apply();
                        if (k == Cfg.AMO_I) fadeRecreate();
                    }
                }));
                card.addView(r);
            } else {
                card.addView(t(Cfg.TITLES[k], 17, Theme.TXT, 1));
                card.addView(t(Cfg.DESCS[k], 13, Theme.TXT2, 0), lp(MATCH, WRAP, 3));
                FlowLayout fl = new FlowLayout(this, dp(8), dp(8));
                fillChips(fl, k, false);
                card.addView(fl, lp(MATCH, WRAP, 14));
            }
            c.addView(card, lp(MATCH, WRAP, 8));
        }
    }

    void fillChips(final FlowLayout fl, final int k, boolean animate) {
        fl.removeAllViews();
        for (int o = 0; o < Cfg.OPTS[k].length; o++) {
            final int oo = o;
            if (k == Cfg.AUD_I && o >= 2 && Build.VERSION.SDK_INT < 29) continue;
            View ch = chip(Cfg.OPTS[k][o], g(k) == o, new View.OnClickListener() {
                public void onClick(View v) {
                    if (RecorderService.recording) {
                        toast("Detén la grabación para cambiar esto");
                        return;
                    }
                    sp.edit().putInt(Cfg.KEYS[k], oo).apply();
                    fillChips(fl, k, true);
                    updSummary();
                    updInfo();
                    if (k == Cfg.MOD_I) fadeRecreate();
                }
            });
            fl.addView(ch);
            if (animate && g(k) == o) pop(ch);
        }
    }

    View themeCard() {
        LinearLayout card = vbox(18);
        card.setBackground(cardBg(Theme.SURF2, 24));
        card.addView(t(Cfg.TITLES[Cfg.THM_I], 17, Theme.TXT, 1));
        card.addView(t(Cfg.DESCS[Cfg.THM_I], 13, Theme.TXT2, 0), lp(MATCH, WRAP, 3));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int cur = g(Cfg.THM_I);
        for (int i = 0; i < Theme.NAMES.length; i++) {
            final int ti = i;
            boolean sel = i == cur;
            int[] pal = Theme.palette(this, i, Theme.LIGHT);
            LinearLayout it = column();
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            it.setPadding(dp(4), dp(4), dp(4), dp(4));
            FrameLayout swc = new FrameLayout(this);
            GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{pal[4], pal[8]});
            gd.setShape(GradientDrawable.OVAL);
            gd.setStroke(dp(sel ? 3 : 1), sel ? Theme.TXT : Theme.OUTLINE);
            swc.setBackground(gd);
            if (sel) swc.addView(new IconView(this, IconView.CHECK, pal[5]), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            it.addView(swc, new LinearLayout.LayoutParams(dp(52), dp(52)));
            it.addView(t(i == 0 ? "Automático" : Theme.NAMES[i], 12, sel ? Theme.TXT : Theme.TXT2, 1), lp(WRAP, WRAP, 6));
            it.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    sp.edit().putInt(Cfg.KEYS[Cfg.THM_I], ti).apply();
                    fadeRecreate();
                }
            });
            press(it);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(WRAP, WRAP);
            ip.rightMargin = dp(10);
            row.addView(it, ip);
        }
        hs.addView(row);
        card.addView(hs, lp(MATCH, WRAP, 14));
        return card;
    }

    void addPermCard(LinearLayout c) {
        c.addView(t("Permisos", 14, Theme.PRI, 1), lp(WRAP, WRAP, 22));
        LinearLayout card = vbox(8);
        card.setBackground(cardBg(Theme.SURF2, 24));
        permRow(card, IconView.MIC, "Micrófono", "Obligatorio para grabar", hasAudio(), 0);
        if (Build.VERSION.SDK_INT >= 33) permRow(card, IconView.BELL, "Notificaciones", "Obligatorio para grabar (pausa y stop desde la barra)", hasNotif(), 1);
        if (Build.VERSION.SDK_INT >= 23) permRow(card, IconView.OVERLAY, "Mostrar sobre otras apps", "Obligatorio para grabar (cuenta atrás animada)", hasOverlay(), 2);
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT < 29) permRow(card, IconView.STORAGE, "Almacenamiento", "Obligatorio para grabar (copia a la galería)", hasStorage(), 3);
        c.addView(card, lp(MATCH, WRAP, 8));
    }

    void permRow(LinearLayout card, int ic, String name, String desc, boolean ok, final int which) {
        LinearLayout r = hbox();
        r.setPadding(dp(8), dp(8), dp(8), dp(8));
        r.addView(circle(ic, 40, 20, ok ? Theme.PRI_C : Theme.SURF3, ok ? Theme.ON_PRI_C : Theme.PRI));
        LinearLayout tx = column();
        tx.addView(t(name, 15, Theme.TXT, 1));
        tx.addView(t(desc, 12, Theme.TXT2, 0));
        LinearLayout.LayoutParams txp = new LinearLayout.LayoutParams(0, WRAP, 1);
        txp.leftMargin = dp(12);
        r.addView(tx, txp);
        if (ok) {
            r.addView(icon(IconView.CHECK, 22, Theme.PRI));
        } else {
            TextView bt = t("Conceder", 13, Theme.ON_PRI, 1);
            bt.setGravity(Gravity.CENTER);
            bt.setPadding(dp(14), 0, dp(14), 0);
            bt.setBackground(rip(Theme.PRI, 18));
            bt.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { grantPerm(which); } });
            press(bt);
            r.addView(bt, new LinearLayout.LayoutParams(WRAP, dp(36)));
        }
        card.addView(r);
    }

    /** Tarjeta "Tu equipo": que puede grabar de verdad este telefono + boton de perfil recomendado. */
    View deviceCard() {
        LinearLayout card = vbox(18);
        card.setBackground(cardBg(Theme.SURF2, 24));
        card.addView(t("Tu equipo", 17, Theme.TXT, 1));
        card.addView(t("Lo que tu teléfono puede grabar de verdad", 13, Theme.TXT2, 0), lp(MATCH, WRAP, 3));
        card.addView(t(Cfg.deviceReport(this), 13, Theme.TXT, 0), lp(MATCH, WRAP, 10));
        final int rec = Cfg.recommended(this);
        TextView b = t("Aplicar perfil recomendado: " + Cfg.PRESET_NAMES[rec] + "\n" + Cfg.presetNums(rec), 14, Theme.ON_PRI, 1);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rip(Theme.PRI, 22));
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (RecorderService.recording || RecorderService.starting) { toast("Detén la grabación para cambiar esto"); return; }
                Cfg.applyPreset(sp, rec);
                mineSel = -1;
                toast("Perfil aplicado: " + Cfg.PRESET_NAMES[rec] + " (" + Cfg.presetNums(rec) + ")");
                showPage(page, false);
            }
        });
        press(b);
        card.addView(b, lp(MATCH, dp(60), 14));
        return card;
    }

    void updSummary() {
        if (tvSetHint != null) {
            String hs = Cfg.hint(this, sp);
            tvSetHint.setText(hs == null ? "" : hs);
            tvSetHint.setVisibility(hs == null ? View.GONE : View.VISIBLE);
        }
        if (tvSetEst == null) return;
        tvSetEst.setText(Cfg.summary(this, sp) + " · " + (Cfg.BRM_V[Cfg.get(sp, Cfg.BRM_I)] > 0 ? Cfg.BRM[Cfg.get(sp, Cfg.BRM_I)] : "bitrate automático"));
    }

    // ---------- tutorial de bienvenida: permisos -> perfil -> audio -> tema -> listo ----------

    void showTutorial(Runnable after) { showTutorial(after, 0, true); }

    void showTutorial(Runnable after, int start, boolean fade) {
        if (tutRoot != null) return;
        tutAfter = after;
        tutRoot = new FrameLayout(this);
        tutRoot.setBackground(Bg.solid(this));
        tutRoot.setClickable(true);
        if (Build.VERSION.SDK_INT >= 21) tutRoot.setElevation(dp(40));   // por encima de la barra inferior (que tiene elevación)
        if (navView != null) navView.setVisibility(View.INVISIBLE);
        tutRoot.addView(new Ambient(this, Theme.PRI, Cfg.lowEnd(this) ? 5 : 9), new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout col = column();
        FrameLayout top = new FrameLayout(this);
        tutBack = t("Atrás", 15, Theme.TXT2, 1);
        tutBack.setPadding(dp(20), dp(14), dp(20), dp(14));
        tutBack.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { goTut(tutIdx - 1); } });
        top.addView(tutBack, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START | Gravity.CENTER_VERTICAL));
        TextView skip = t("Saltar", 15, Theme.TXT2, 1);
        skip.setPadding(dp(20), dp(14), dp(20), dp(14));
        skip.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { endTutorial(); } });
        top.addView(skip, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END | Gravity.CENTER_VERTICAL));
        col.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

        tutBody = new FrameLayout(this);
        col.addView(tutBody, new LinearLayout.LayoutParams(MATCH, 0, 1));

        LinearLayout bottom = column();
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);
        bottom.setPadding(0, dp(8), 0, dp(14));
        LinearLayout dots = hbox();
        dots.setGravity(Gravity.CENTER);
        tutDots = new View[TUT_N];
        for (int i = 0; i < TUT_N; i++) {
            View dv = new View(this);
            dv.setBackground(shape(Theme.OUTLINE, 4));
            LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(dp(8), dp(8));
            dp1.leftMargin = dp(4);
            dp1.rightMargin = dp(4);
            dots.addView(dv, dp1);
            tutDots[i] = dv;
        }
        bottom.addView(dots);
        tutBtn = t("Siguiente", 16, Theme.ON_PRI, 1);
        tutBtn.setGravity(Gravity.CENTER);
        tutBtn.setBackground(rip(Theme.PRI, 28));
        tutBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (tutIdx == 0 && missingPerms() > 0) tutPermAll(); else goTut(tutIdx + 1);
            }
        });
        press(tutBtn);
        bottom.addView(tutBtn, lp(dp(260), dp(56), 16));
        tutLater = t("Ahora no", 14, Theme.TXT2, 1);
        tutLater.setPadding(dp(20), dp(10), dp(20), dp(10));
        tutLater.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { goTut(tutIdx + 1); } });
        bottom.addView(tutLater, lp(WRAP, WRAP, 2));
        col.addView(bottom, new LinearLayout.LayoutParams(MATCH, WRAP));
        tutRoot.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        rootF.addView(tutRoot, new FrameLayout.LayoutParams(MATCH, MATCH));
        if (fade) {
            tutRoot.setAlpha(0f);
            tutRoot.animate().alpha(1f).setStartDelay(0).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
        }
        tutIdx = -1;
        goTut(Math.max(0, Math.min(start, TUT_N - 1)));
    }

    void stopBob() {
        if (tutBob != null) { tutBob.cancel(); tutBob = null; }
    }

    void updTutBtn() {
        if (tutBtn == null) return;
        boolean needPerms = tutIdx == 0 && missingPerms() > 0;
        tutBtn.setText(needPerms ? "Permitir todo" : (tutIdx == TUT_N - 1 ? "¡Empezar!" : "Siguiente"));
        if (tutLater != null) tutLater.setVisibility(needPerms ? View.VISIBLE : View.INVISIBLE);
        if (tutBack != null) tutBack.setVisibility(tutIdx > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    void goTut(int to) {
        if (tutRoot == null || to < 0) return;
        if (to >= TUT_N) { endTutorial(); return; }
        if (to == tutIdx) return;
        boolean fwd = to >= tutIdx;
        View old = null;
        int n = tutBody.getChildCount();
        if (n > 0) old = tutBody.getChildAt(n - 1);
        while (tutBody.getChildCount() > 1) tutBody.removeViewAt(0);
        stopBob();
        tutPermList = null;
        tutProfList = null;
        tutAudList = null;
        tutIdx = to;
        View nv = tutSlide(to);
        for (int i = 0; i < tutDots.length; i++) {
            boolean on = i == to;
            ((GradientDrawable) tutDots[i].getBackground()).setColor(on ? Theme.PRI : Theme.OUTLINE);
            animW(tutDots[i], dp(on ? 24 : 8));
        }
        updTutBtn();
        final View o = old;
        if (o != null) {
            o.animate().alpha(0f).translationX(fwd ? -dp(50) : dp(50)).setStartDelay(0).setDuration(160).setInterpolator(new AccelerateInterpolator())
                    .withEndAction(new Runnable() { public void run() { tutBody.removeView(o); } }).start();
        }
        tutBody.addView(nv, new FrameLayout.LayoutParams(MATCH, MATCH));
        nv.setAlpha(0f);
        nv.setTranslationX(fwd ? dp(60) : -dp(60));
        nv.animate().alpha(1f).translationX(0f).setStartDelay(o != null ? 120 : 0).setDuration(340).setInterpolator(new DecelerateInterpolator(1.6f)).start();
    }

    /** Ilustración de cada paso: ondas suaves detrás + icono que rebota al entrar y luego flota. */
    FrameLayout tutIll(int box, int heroDp, int icType, boolean recBtn) {
        FrameLayout ill = new FrameLayout(this);
        View hero;
        if (recBtn) {
            hero = new RecButton(this);
            ill.addView(hero, new FrameLayout.LayoutParams(dp(heroDp), dp(heroDp), Gravity.CENTER));
        } else {
            ill.addView(new Rings(this, Theme.PRI, 0.45f, 2), new FrameLayout.LayoutParams(dp(box), dp(box), Gravity.CENTER));
            if (icType == IconView.LOGO) {
                hero = new IconView(this, IconView.LOGO, 0);
                ill.addView(hero, new FrameLayout.LayoutParams(dp(heroDp), dp(heroDp), Gravity.CENTER));
            } else {
                FrameLayout disc = new FrameLayout(this);
                disc.setBackground(shape(Theme.PRI_C, heroDp / 2));
                disc.addView(new IconView(this, icType, Theme.ON_PRI_C), new FrameLayout.LayoutParams(dp(heroDp / 2), dp(heroDp / 2), Gravity.CENTER));
                hero = disc;
                ill.addView(disc, new FrameLayout.LayoutParams(dp(heroDp), dp(heroDp), Gravity.CENTER));
            }
        }
        hero.setScaleX(0.55f);
        hero.setScaleY(0.55f);
        hero.setRotation(-14f);
        hero.animate().scaleX(1f).scaleY(1f).rotation(0f).setStartDelay(200).setDuration(520).setInterpolator(new OvershootInterpolator(2.2f)).start();
        tutBob = ObjectAnimator.ofFloat(hero, "translationY", 0f, -dp(7));
        tutBob.setDuration(1600);
        tutBob.setRepeatCount(ValueAnimator.INFINITE);
        tutBob.setRepeatMode(ValueAnimator.REVERSE);
        tutBob.setStartDelay(800);
        tutBob.start();
        ill.setLayoutParams(new LinearLayout.LayoutParams(dp(box), dp(box)));
        return ill;
    }

    void tutText(LinearLayout l, String title, String desc) {
        TextView tt = t(title, 26, Theme.TXT, 1);
        tt.setGravity(Gravity.CENTER);
        l.addView(tt, lp(MATCH, WRAP, 6));
        TextView d = t(desc, 15, Theme.TXT2, 0);
        d.setGravity(Gravity.CENTER);
        d.setLineSpacing(0, 1.2f);
        l.addView(d, lp(MATCH, WRAP, 10));
    }

    /** Los bloques del paso (menos la ilustración) suben y aparecen uno tras otro. */
    void tutIn(LinearLayout l) {
        for (int i = 1; i < l.getChildCount() && i < 7; i++) {
            View v = l.getChildAt(i);
            v.setAlpha(0f);
            v.setTranslationY(dp(18));
            v.animate().alpha(1f).translationY(0f).setStartDelay(160 + i * 60L).setDuration(380).setInterpolator(new DecelerateInterpolator(2f)).start();
        }
    }

    View tutSlide(int i) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout l = column();
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(24), dp(4), dp(24), dp(12));
        if (i == 0) {
            l.addView(tutIll(150, 76, IconView.LOGO, false));
            tutText(l, "Primero, los permisos", "Son obligatorios: sin todos los permisos no se puede grabar. Acéptalos de una vez.");
            tutPermList = vbox(8);
            tutPermList.setBackground(cardBg(Theme.SURF2, 24));
            l.addView(tutPermList, lp(MATCH, WRAP, 16));
            fillTutPerms();
        } else if (i == 1) {
            l.addView(tutIll(120, 60, IconView.BOLT, false));
            tutText(l, "Elige un perfil", "Son 5 perfiles, los mismos de la pantalla principal: cada uno ajusta resolución, fluidez y bitrate (Mbps). Podrás cambiarlo cuando quieras.");
            tutProfList = column();
            l.addView(tutProfList, lp(MATCH, WRAP, 16));
            fillTutProf();
        } else if (i == 2) {
            l.addView(tutIll(120, 60, IconView.MIC, false));
            tutText(l, "Elige el audio", "Decide qué se escucha en tus videos. Lo puedes cambiar cuando quieras en la pantalla principal o en Ajustes.");
            tutAudList = column();
            l.addView(tutAudList, lp(MATCH, WRAP, 16));
            fillTutAud();
            l.addView(t("Con sonido del teléfono, algunas apps (llamadas, ciertas apps de video) bloquean la captura y esa parte queda en silencio.", 12, Theme.TXT2, 0), lp(MATCH, WRAP, 12));
        } else if (i == 3) {
            l.addView(tutIll(120, 60, IconView.PALETTE, false));
            tutText(l, "Tu estilo", "Elige el modo y el color. La app cambia al instante; luego puedes ajustarlo en Ajustes.");
            l.addView(t("Modo", 14, Theme.PRI, 1), lp(MATCH, WRAP, 16));
            LinearLayout mr = new LinearLayout(this);
            mr.setOrientation(LinearLayout.HORIZONTAL);
            int cm = curMode();
            for (int k = 0; k < 3; k++) {
                LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, WRAP, 1);
                if (k > 0) mp.leftMargin = dp(8);
                mr.addView(modeCard(k, k == cm), mp);
            }
            l.addView(mr, lp(MATCH, WRAP, 8));
            l.addView(t("Color", 14, Theme.PRI, 1), lp(MATCH, WRAP, 16));
            l.addView(colorRow(), lp(MATCH, WRAP, 8));
        } else {
            l.addView(tutIll(200, 190, 0, true));
            tutText(l, "¡Todo listo!", "Toca el botón grande para grabar: verás una cuenta atrás y la grabación sigue aunque cambies de app. Para parar, toca de nuevo o usa la notificación. Todo se puede cambiar en Ajustes.");
            l.addView(t("Hecho por " + CREATOR, 12, Theme.TXT2, 0), lp(WRAP, WRAP, 18));
        }
        tutIn(l);
        sv.addView(l, new ViewGroup.LayoutParams(MATCH, WRAP));
        return sv;
    }

    // ----- paso 1: permisos -----

    void fillTutPerms() {
        if (tutPermList == null) return;
        tutPermList.removeAllViews();
        tutPermRow(IconView.MIC, "Micrófono", "Para grabar tu voz", hasAudio(), 0);
        if (Build.VERSION.SDK_INT >= 33) tutPermRow(IconView.BELL, "Notificaciones", "Para pausar o detener desde la barra", hasNotif(), 1);
        if (Build.VERSION.SDK_INT >= 23) tutPermRow(IconView.OVERLAY, "Mostrar sobre otras apps", "Para la cuenta atrás encima de cualquier app", hasOverlay(), 2);
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT < 29) tutPermRow(IconView.STORAGE, "Almacenamiento", "Para copiar a la galería", hasStorage(), 3);
        updTutBtn();
    }

    void tutPermRow(int ic, String name, String desc, boolean ok, final int which) {
        LinearLayout r = hbox();
        r.setPadding(dp(8), dp(8), dp(8), dp(8));
        r.addView(circle(ic, 40, 20, ok ? Theme.PRI_C : Theme.SURF3, ok ? Theme.ON_PRI_C : Theme.PRI));
        LinearLayout tx = column();
        tx.addView(t(name, 15, Theme.TXT, 1));
        tx.addView(t(desc, 12, Theme.TXT2, 0));
        LinearLayout.LayoutParams txp = new LinearLayout.LayoutParams(0, WRAP, 1);
        txp.leftMargin = dp(12);
        r.addView(tx, txp);
        if (ok) {
            r.addView(icon(IconView.CHECK, 22, Theme.PRI));
        } else {
            TextView bt = t("Permitir", 13, Theme.ON_PRI, 1);
            bt.setGravity(Gravity.CENTER);
            bt.setPadding(dp(14), 0, dp(14), 0);
            bt.setBackground(rip(Theme.PRI, 18));
            bt.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { grantPerm(which); } });
            press(bt);
            r.addView(bt, new LinearLayout.LayoutParams(WRAP, dp(36)));
        }
        tutPermList.addView(r);
    }

    /** "Permitir todo": primero los permisos normales de golpe y luego "Mostrar sobre otras apps". */
    void tutPermAll() {
        if (Build.VERSION.SDK_INT >= 23) {
            ArrayList<String> need = new ArrayList<String>();
            boolean stuck = false;
            ArrayList<String> all = new ArrayList<String>();
            if (!hasAudio()) all.add("android.permission.RECORD_AUDIO");
            if (Build.VERSION.SDK_INT >= 33 && !hasNotif()) all.add("android.permission.POST_NOTIFICATIONS");
            if (Build.VERSION.SDK_INT < 29 && !hasStorage()) all.add("android.permission.WRITE_EXTERNAL_STORAGE");
            for (int i = 0; i < all.size(); i++) {
                if (blocked(all.get(i))) stuck = true; else need.add(all.get(i));
            }
            if (!need.isEmpty()) {
                SharedPreferences.Editor e = sp.edit();
                for (int i = 0; i < need.size(); i++) e.putBoolean("asked_" + need.get(i), true);
                e.apply();
                requestPermissions(need.toArray(new String[0]), 12);
                return;
            }
            if (stuck) { openAppSettings(); return; }
            if (!hasOverlay()) { tutOverlay(); return; }
        }
        fillTutPerms();
    }

    void tutOverlay() {
        sp.edit().putBoolean("ovl_asked", true).apply();
        toast("Activa RecLite y vuelve");
        openOverlaySettings();
    }

    // ----- paso 2: perfil -----

    void fillTutProf() {
        if (tutProfList == null) return;
        tutProfList.removeAllViews();
        int cur = Cfg.matchPreset(sp);
        for (int i = 0; i < Cfg.PRESET_NAMES.length; i++) {
            final int p = i;
            tpv[i] = new ProfView(p, Cfg.PRESET_NAMES[i], Cfg.PRESET_DESC[i], Cfg.PRESET_ICON[i], new View.OnClickListener() {
                public void onClick(View v) {
                    Cfg.applyPreset(sp, p);
                    mineSel = -1;
                    for (int j = 0; j < tpv.length; j++) if (tpv[j] != null) tpv[j].style(j == p, true);
                }
            });
            tpv[i].style(cur == p, false);
            tutProfList.addView(tpv[i].row, lp(MATCH, WRAP, i == 0 ? 0 : 10));
        }
    }

    // ----- paso 3: audio -----

    /** Fila seleccionable de una opción de audio (mismo estilo que las tarjetas de perfil). */
    class AudView {
        LinearLayout row;
        GradientDrawable bg, icBg, ckBg;
        IconView icon, ck;
        TextView name, desc;
        boolean on;

        AudView(String nm, String ds, int icType, View.OnClickListener l) {
            Context cx = MainActivity.this;
            row = hbox();
            row.setPadding(dp(14), dp(14), dp(14), dp(14));
            bg = cardBg(Theme.SURF2, 24);
            row.setBackground(rip(bg, 24, Theme.RIPPLE));

            FrameLayout ic = new FrameLayout(cx);
            icBg = shape(Theme.SURF3, 24);
            ic.setBackground(icBg);
            icon = new IconView(cx, icType, Theme.PRI);
            ic.addView(icon, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            row.addView(ic, new LinearLayout.LayoutParams(dp(48), dp(48)));

            LinearLayout mid = column();
            name = t(nm, 16, Theme.TXT, 1);
            desc = t(ds, 12, Theme.TXT2, 0);
            mid.addView(name);
            mid.addView(desc, lp(MATCH, WRAP, 2));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, WRAP, 1);
            mp.leftMargin = dp(14);
            row.addView(mid, mp);

            FrameLayout ckf = new FrameLayout(cx);
            ckBg = new GradientDrawable();
            ckBg.setShape(GradientDrawable.OVAL);
            ckf.setBackground(ckBg);
            ck = new IconView(cx, IconView.CHECK, Theme.ON_PRI);
            ckf.addView(ck, new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(26), dp(26));
            cp.leftMargin = dp(10);
            row.addView(ckf, cp);

            row.setOnClickListener(l);
            press(row);
            style(false, false);
        }

        void style(boolean now, boolean animate) {
            int to = now ? Theme.PRI_C : Theme.SURF2, from = now ? Theme.SURF2 : Theme.PRI_C;
            if (animate && now != on) animColor(bg, from, to); else bg.setColor(to);
            name.setTextColor(now ? Theme.ON_PRI_C : Theme.TXT);
            desc.setTextColor(now ? Theme.ON_PRI_C : Theme.TXT2);
            icBg.setColor(now ? Theme.PRI : Theme.SURF3);
            icon.setColor(now ? Theme.ON_PRI : Theme.PRI);
            ckBg.setColor(now ? Theme.PRI : 0);
            ckBg.setStroke(now ? 0 : dp(2), Theme.OUTLINE);
            ck.setAlpha(now ? 1f : 0f);
            if (now && animate && !on) { pop(ck); pop(icon); }
            on = now;
        }
    }

    void fillTutAud() {
        if (tutAudList == null) return;
        tutAudList.removeAllViews();
        int cur = g(Cfg.AUD_I);
        for (int i = 0; i < tav.length; i++) tav[i] = null;
        for (int i = 0; i < Cfg.AUD.length && i < tav.length; i++) {
            if (i >= 2 && Build.VERSION.SDK_INT < 29) continue;   // el sonido interno pide Android 10
            final int a = i;
            tav[i] = new AudView(Cfg.AUD_TITLE[i], Cfg.AUD_DESC[i], Cfg.AUD_ICON[i], new View.OnClickListener() {
                public void onClick(View v) {
                    sp.edit().putInt(Cfg.KEYS[Cfg.AUD_I], a).apply();
                    for (int j = 0; j < tav.length; j++) if (tav[j] != null) tav[j].style(j == a, true);
                    if (a > 0 && !hasAudio()) grantPerm(0);   // el micrófono y el sonido interno piden este permiso
                }
            });
            tav[i].style(cur == i, false);
            tutAudList.addView(tav[i].row, lp(MATCH, WRAP, tutAudList.getChildCount() == 0 ? 0 : 10));
        }
    }

    // ----- paso 4: tema (claro / oscuro / AMOLED + color) -----

    /** 0 claro, 1 oscuro, 2 AMOLED */
    int curMode() { return Theme.AMO ? 2 : (Theme.LIGHT ? 0 : 1); }

    View modeCard(final int k, boolean sel) {
        LinearLayout it = column();
        it.setGravity(Gravity.CENTER_HORIZONTAL);
        it.setPadding(dp(6), dp(10), dp(6), dp(10));
        it.setBackground(rip(cardBg(sel ? Theme.PRI_C : Theme.SURF2, 20), 20, Theme.RIPPLE));
        int[] bg = {0xFFF6F6F8, 0xFF1D1B20, 0xFF000000};
        int[] fg = {0xFF1B1B1F, 0xFFE6E0E9, 0xFFFFFFFF};
        String[] nm = {"Claro", "Oscuro", "AMOLED"};
        FrameLayout sw = new FrameLayout(this);
        GradientDrawable gd = shape(bg[k], 14);
        gd.setStroke(dp(sel ? 2 : 1), sel ? Theme.PRI : 0x66808080);
        sw.setBackground(gd);
        View b1 = new View(this);
        b1.setBackground(shape(fg[k], 3));
        b1.setAlpha(0.75f);
        FrameLayout.LayoutParams l1 = new FrameLayout.LayoutParams(dp(30), dp(6), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        l1.topMargin = dp(12);
        sw.addView(b1, l1);
        View b2 = new View(this);
        b2.setBackground(shape(fg[k], 3));
        b2.setAlpha(0.4f);
        FrameLayout.LayoutParams l2 = new FrameLayout.LayoutParams(dp(20), dp(6), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        l2.topMargin = dp(23);
        sw.addView(b2, l2);
        if (sel) {
            FrameLayout.LayoutParams l3 = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            l3.bottomMargin = dp(6);
            sw.addView(new IconView(this, IconView.CHECK, fg[k]), l3);
        }
        it.addView(sw, new LinearLayout.LayoutParams(dp(64), dp(64)));
        it.addView(t(nm[k], 13, sel ? Theme.ON_PRI_C : Theme.TXT, 1), lp(WRAP, WRAP, 8));
        it.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { applyMode(k); } });
        press(it);
        return it;
    }

    void applyMode(int k) {
        if (k == curMode()) return;
        SharedPreferences.Editor e = sp.edit();
        e.putInt(Cfg.KEYS[Cfg.MOD_I], k == 0 ? 1 : 2);
        e.putInt(Cfg.KEYS[Cfg.AMO_I], k == 2 ? 1 : 0);
        e.apply();
        tutRecreate();
    }

    View colorRow() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int cur = g(Cfg.THM_I);
        for (int i = 0; i < Theme.NAMES.length; i++) {
            final int ti = i;
            boolean sel = i == cur;
            int[] pal = Theme.palette(this, i, Theme.LIGHT);
            LinearLayout it = column();
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            it.setPadding(dp(4), dp(4), dp(4), dp(4));
            FrameLayout swc = new FrameLayout(this);
            GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{pal[4], pal[8]});
            gd.setShape(GradientDrawable.OVAL);
            gd.setStroke(dp(sel ? 3 : 1), sel ? Theme.TXT : Theme.OUTLINE);
            swc.setBackground(gd);
            if (sel) swc.addView(new IconView(this, IconView.CHECK, pal[5]), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            it.addView(swc, new LinearLayout.LayoutParams(dp(52), dp(52)));
            it.addView(t(i == 0 ? "Automático" : Theme.NAMES[i], 12, sel ? Theme.TXT : Theme.TXT2, 1), lp(WRAP, WRAP, 6));
            it.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (g(Cfg.THM_I) == ti) return;
                    sp.edit().putInt(Cfg.KEYS[Cfg.THM_I], ti).apply();
                    tutRecreate();
                }
            });
            press(it);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(WRAP, WRAP);
            ip.rightMargin = dp(10);
            row.addView(it, ip);
        }
        hs.addView(row);
        return hs;
    }

    /** Recrea la pantalla con los colores nuevos y vuelve al mismo paso del tutorial. */
    void tutRecreate() {
        tutResume = tutIdx;
        fadeRecreate();
    }

    void endTutorial() {
        if (tutRoot == null) return;
        sp.edit().putBoolean("tut_done", true).apply();
        stopBob();
        final FrameLayout tr = tutRoot;
        final Runnable after = tutAfter;
        tutRoot = null;
        tutAfter = null;
        tutPermList = null;
        tutProfList = null;
        tutAudList = null;
        if (navView != null) navView.setVisibility(View.VISIBLE);
        tr.animate().alpha(0f).setStartDelay(0).setDuration(260).setInterpolator(new AccelerateInterpolator())
                .withEndAction(new Runnable() {
                    public void run() {
                        rootF.removeView(tr);
                        if (after != null) after.run();
                    }
                }).start();
    }
}
