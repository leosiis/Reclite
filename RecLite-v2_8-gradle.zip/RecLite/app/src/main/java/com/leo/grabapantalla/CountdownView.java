package com.leo.grabapantalla;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.Choreographer;
import android.view.View;

/**
 * Cuenta atrás sencilla: un círculo oscuro, un anillo fino que se vacía y el número.
 *  - un solo reloj (Choreographer) para toda la cuenta, sin desfases entre número y anillo;
 *  - no depende de la "escala de animaciones" del sistema (si está en 0, igual espera);
 *  - solo un fundido suave al entrar/salir y un leve "pop" en cada número.
 */
public class CountdownView extends View {
    public interface Listener {
        /** Cambió el número visible (se llama en el hilo principal). */
        void onNumber(int n);

        /** La animación terminó por completo: ya se puede quitar la vista y grabar. */
        void onFinish();
    }

    static final int ACCENT = 0xFFD0BCFF, PANEL = 0xE6141218;
    static final float INTRO_S = 0.18f;   // duración del fundido de entrada
    static final float OUT_S = 0.20f;     // duración del fundido de salida

    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    RectF rf = new RectF();
    float d;
    int total, num = -1;
    float el, out;
    boolean running, outing;
    long lastDraw;
    long t0, t1;
    Listener ls;

    public CountdownView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        Fonts.init(c);
        p.setTypeface(Fonts.semi);
        p.setTextAlign(Paint.Align.CENTER);
        p.setStrokeCap(Paint.Cap.ROUND);
    }

    Choreographer.FrameCallback fc = new Choreographer.FrameCallback() {
        public void doFrame(long ns) {
            if (!running) return;
            if (!outing) {
                float t = Math.max(0f, (ns - t0) / 1e9f);
                el = Math.min(t, (float) total);
                int idx = Math.min(total - 1, (int) el);
                int n = total - idx;
                if (n != num) {
                    num = n;
                    if (ls != null) ls.onNumber(n);
                }
                if (t >= total) { outing = true; t1 = ns; out = 0f; }
            } else {
                out = Math.min(1f, (ns - t1) / 1e9f / OUT_S);
                if (out >= 1f) {
                    running = false;
                    invalidate();
                    if (ls != null) ls.onFinish();
                    return;
                }
            }
            if (ns - lastDraw >= 30000000L) { lastDraw = ns; invalidate(); }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    /** Arranca la cuenta de "seconds" segundos. */
    public void start(int seconds, Listener l) {
        stopAnim();
        total = Math.max(1, seconds);
        ls = l;
        el = 0f;
        out = 0f;
        num = -1;
        outing = false;
        running = true;
        lastDraw = 0L;
        t0 = System.nanoTime();
        Choreographer.getInstance().postFrameCallback(fc);
    }

    public void stopAnim() {
        running = false;
        try { Choreographer.getInstance().removeFrameCallback(fc); } catch (Throwable e) {}
    }

    @Override protected void onDetachedFromWindow() {
        stopAnim();
        super.onDetachedFromWindow();
    }

    // ---------- dibujo ----------

    static float clamp(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }

    static float easeOutCubic(float x) {
        float k = 1f - clamp(x);
        return 1f - k * k * k;
    }

    static int al(int color, float a) {
        int A = Math.round(((color >>> 24) & 0xFF) * clamp(a));
        return (A << 24) | (color & 0x00FFFFFF);
    }

    @Override protected void onDraw(Canvas c) {
        if (num < 0) return;
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float R = 66 * d;

        // segundo actual y avance dentro de él (0..1)
        int idx = total - num;
        float u = outing ? 1f : clamp(el - idx);

        // fundido de entrada y de salida del conjunto
        float ga = clamp(el / INTRO_S) * (outing ? 1f - out : 1f);

        // panel
        p.setStyle(Paint.Style.FILL);
        p.setColor(al(PANEL, ga));
        c.drawCircle(cx, cy, R, p);

        // anillo: pista + arco que se vacía
        float rr = R - 9 * d;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4 * d);
        p.setColor(al(0x26FFFFFF, ga));
        c.drawCircle(cx, cy, rr, p);
        float remain = outing ? 0f : 1f - u;
        if (remain > 0.003f) {
            rf.set(cx - rr, cy - rr, cx + rr, cy + rr);
            p.setColor(al(ACCENT, ga));
            c.drawArc(rf, -90f, 360f * remain, false, p);
        }

        // número: fundido corto con un pequeño "pop"
        if (!outing) {
            float inK = easeOutCubic(clamp(u / 0.25f));
            float scale = 0.88f + 0.12f * inK;
            p.setStyle(Paint.Style.FILL);
            p.setColor(al(0xFFFFFFFF, inK * ga));
            p.setTextSize(64 * d);
            float base = -(p.getFontMetrics().ascent + p.getFontMetrics().descent) / 2f;
            c.save();
            c.translate(cx, cy);
            c.scale(scale, scale);
            c.drawText(String.valueOf(num), 0f, base, p);
            c.restore();
        }
    }
}
