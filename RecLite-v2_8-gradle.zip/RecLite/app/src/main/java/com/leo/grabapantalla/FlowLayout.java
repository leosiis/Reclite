package com.leo.grabapantalla;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/** Contenedor que acomoda hijos en filas y salta de linea (para los chips). */
public class FlowLayout extends ViewGroup {
    int hs, vs;

    public FlowLayout(Context c, int hSpacePx, int vSpacePx) {
        super(c);
        hs = hSpacePx;
        vs = vSpacePx;
    }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        int maxW = MeasureSpec.getSize(wSpec) - getPaddingLeft() - getPaddingRight();
        int x = 0, y = 0, rowH = 0, usedW = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            if (v.getVisibility() == GONE) continue;
            v.measure(MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST), MeasureSpec.UNSPECIFIED);
            int cw = v.getMeasuredWidth(), ch = v.getMeasuredHeight();
            if (x > 0 && x + cw > maxW) { x = 0; y += rowH + vs; rowH = 0; }
            x += cw + hs;
            usedW = Math.max(usedW, x - hs);
            rowH = Math.max(rowH, ch);
        }
        int h = y + rowH + getPaddingTop() + getPaddingBottom();
        setMeasuredDimension(resolveSize(usedW + getPaddingLeft() + getPaddingRight(), wSpec), resolveSize(h, hSpec));
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int maxW = r - l - getPaddingLeft() - getPaddingRight();
        int x = 0, y = 0, rowH = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            if (v.getVisibility() == GONE) continue;
            int cw = v.getMeasuredWidth(), ch = v.getMeasuredHeight();
            if (x > 0 && x + cw > maxW) { x = 0; y += rowH + vs; rowH = 0; }
            int left = getPaddingLeft() + x, top = getPaddingTop() + y;
            v.layout(left, top, left + cw, top + ch);
            x += cw + hs;
            rowH = Math.max(rowH, ch);
        }
    }
}
