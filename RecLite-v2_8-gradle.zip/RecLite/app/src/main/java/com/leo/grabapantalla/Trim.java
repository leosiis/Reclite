package com.leo.grabapantalla;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import java.io.File;
import java.nio.ByteBuffer;

/** Recorta un MP4 sin recodificar (copia los cuadros tal cual: rapido y sin perder calidad). */
public class Trim {

    /**
     * Copia de startUs a endUs. El inicio real cae en el cuadro clave anterior (puede empezar hasta ~1-2 s antes).
     * @return true si el archivo de salida quedo bien
     */
    public static boolean cut(File src, File dst, long startUs, long endUs) {
        MediaExtractor ex = new MediaExtractor();
        MediaMuxer mux = null;
        boolean started = false;
        try {
            ex.setDataSource(src.getPath());
            int n = ex.getTrackCount();
            int[] map = new int[n];
            int added = 0;
            mux = new MediaMuxer(dst.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            for (int i = 0; i < n; i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && (m.startsWith("video/") || m.startsWith("audio/"))) {
                    ex.selectTrack(i);
                    map[i] = mux.addTrack(f);
                    added++;
                } else {
                    map[i] = -1;
                }
            }
            if (added == 0) return false;
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            long base = ex.getSampleTime();
            if (base < 0) return false;
            mux.start();
            started = true;
            ByteBuffer buf = ByteBuffer.allocate(4 * 1024 * 1024);
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            int wrote = 0;
            while (true) {
                buf.clear();
                int size = ex.readSampleData(buf, 0);
                if (size < 0) break;
                long t = ex.getSampleTime();
                if (t > endUs) break;
                int tr = ex.getSampleTrackIndex();
                if (tr >= 0 && map[tr] >= 0 && t - base >= 0) {
                    bi.set(0, size, t - base,
                            (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0);
                    mux.writeSampleData(map[tr], buf, bi);
                    wrote++;
                }
                ex.advance();
            }
            mux.stop();
            started = false;
            return wrote > 0;
        } catch (Throwable e) {
            return false;
        } finally {
            try { if (mux != null) { if (started) mux.stop(); mux.release(); } } catch (Throwable t) {}
            try { ex.release(); } catch (Throwable t) {}
        }
    }
}
