package com.leo.grabapantalla;

import android.content.Intent;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Boton en los ajustes rapidos: empieza a grabar (abre la app para el permiso) o detiene. */
public class RecTile extends TileService {

    void sync() {
        Tile t = getQsTile();
        if (t == null) return;
        boolean busy = RecorderService.recording || RecorderService.starting;
        t.setState(busy ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel(busy ? "Detener grabación" : "Grabar pantalla");
        t.updateTile();
    }

    @Override public void onStartListening() { sync(); }

    @Override public void onClick() {
        if (RecorderService.recording || RecorderService.starting) {
            startService(new Intent(this, RecorderService.class).setAction(RecorderService.A_STOP));
        } else {
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra("gp.rec", true);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityAndCollapse(i);
        }
        sync();
    }
}
