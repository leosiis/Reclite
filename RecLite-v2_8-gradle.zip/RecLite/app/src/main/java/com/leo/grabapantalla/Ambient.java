package com.leo.grabapantalla;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.FrameLayout;
import java.util.Random;

/** Puntos de color que flotan despacio de fondo. Solo animan propiedades de vistas: gasto minimo. */
public class Ambient extends FrameLayout {
    int color, n;
    ObjectAnimator[] an;
    boolean built;

    public Ambient(Context c, int color, int n) {
        super(c);
        this.color = color;
        this.n = n;
        setClickable(false);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (!built && w > 0 && h > 0) build(w, h);
    }

    void build(int w, int h) {
        built = true;
        float d = getResources().getDisplayMetrics().density;
        Random r = new Random(11);
        an = new ObjectAnimator[n];
        for (int i = 0; i < n; i++) {
            int s = (int) ((5 + r.nextInt(12)) * d);
            View v = new View(getContext());
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(color);
            v.setBackground(g);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(s, s);
            lp.leftMargin = r.nextInt(Math.max(1, w - s));
            lp.topMargin = r.nextInt(Math.max(1, h - s));
            addView(v, lp);
            float rise = (40 + r.nextInt(70)) * d;
            ObjectAnimator a = ObjectAnimator.ofPropertyValuesHolder(v,
                    PropertyValuesHolder.ofFloat("translationY", rise / 2f, -rise / 2f),
                    PropertyValuesHolder.ofFloat("translationX", -12 * d, 12 * d),
                    PropertyValuesHolder.ofFloat("alpha", 0.10f, 0.45f));
            a.setDuration(4200 + r.nextInt(4200));
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setRepeatMode(ValueAnimator.REVERSE);
            a.setStartDelay(r.nextInt(1500));
            an[i] = a;
            if (isAttachedToWindow()) a.start();
        }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (an != null) for (int i = 0; i < an.length; i++) if (!an[i].isStarted()) an[i].start();
    }

    @Override protected void onDetachedFromWindow() {
        if (an != null) for (int i = 0; i < an.length; i++) an[i].cancel();
        super.onDetachedFromWindow();
    }

    @Override protected void onWindowVisibilityChanged(int vis) {
        super.onWindowVisibilityChanged(vis);
        if (an == null) return;
        for (int i = 0; i < an.length; i++) {
            if (vis == VISIBLE) { if (an[i].isPaused()) an[i].resume(); }
            else if (an[i].isRunning()) an[i].pause();
        }
    }
}
