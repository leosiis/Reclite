package com.leo.grabapantalla;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

/** Ondas suaves hechas con vistas animadas por propiedades (casi no gastan CPU: no se redibuja nada). */
public class Rings extends FrameLayout {
    int color;
    float inner;
    int n;
    ObjectAnimator[] an;
    View[] vs;
    boolean built;

    /** inner = tamano inicial de la onda (fraccion del tamano final, 0..1) */
    public Rings(Context c, int color, float inner, int n) {
        super(c);
        this.color = color;
        this.inner = inner;
        this.n = n;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (!built && w > 0 && h > 0) build(Math.min(w, h));
    }

    void build(int s) {
        built = true;
        vs = new View[n];
        an = new ObjectAnimator[n];
        for (int i = 0; i < n; i++) {
            View v = new View(getContext());
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(color);
            v.setBackground(g);
            v.setAlpha(0f);
            addView(v, new FrameLayout.LayoutParams(s, s, Gravity.CENTER));
            ObjectAnimator a = ObjectAnimator.ofPropertyValuesHolder(v,
                    PropertyValuesHolder.ofFloat("scaleX", inner, 1f),
                    PropertyValuesHolder.ofFloat("scaleY", inner, 1f),
                    PropertyValuesHolder.ofFloat("alpha", 0.30f, 0f));
            a.setDuration(2800);
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setInterpolator(new DecelerateInterpolator(1.2f));
            a.setStartDelay(i * 2800L / n);
            vs[i] = v;
            an[i] = a;
            if (isAttachedToWindow()) a.start();
        }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (an != null) for (int i = 0; i < an.length; i++) if (!an[i].isStarted()) an[i].start();
    }

    @Override protected void onDetachedFromWindow() {
        if (an != null) for (int i = 0; i < an.length; i++) an[i].cancel();
        super.onDetachedFromWindow();
    }

    @Override protected void onWindowVisibilityChanged(int vis) {
        super.onWindowVisibilityChanged(vis);
        if (an == null) return;
        for (int i = 0; i < an.length; i++) {
            if (vis == VISIBLE) { if (an[i].isPaused()) an[i].resume(); }
            else if (an[i].isRunning()) an[i].pause();
        }
    }
}
