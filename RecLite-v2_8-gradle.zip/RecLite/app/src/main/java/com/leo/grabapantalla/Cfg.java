package com.leo.grabapantalla;

import android.app.ActivityManager;
import android.content.Context;
import android.media.AudioManager;
import android.content.SharedPreferences;
import android.media.MediaCodecList;
import android.media.MediaCodecInfo;
import android.os.Build;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Range;
import android.view.WindowManager;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class Cfg {
    public static final int RES_I = 0, FPS_I = 1, BUF_I = 2, COD_I = 3, AUD_I = 4, CNT_I = 5, LIM_I = 6,
            GAL_I = 7, THM_I = 8, AMO_I = 9, ORI_I = 10,
            BRM_I = 11, SIZ_I = 12, PRO_I = 13, MOD_I = 14;

    public static final String[] KEYS = {"res", "fps3", "buf", "cod2", "aud", "cnt", "lim", "gal", "thm", "amo", "ori", "brm", "siz", "pro", "mod"};
    public static final String[] TITLES = {"Resolución", "Fotogramas por segundo", "Calidad de imagen", "Códec de video",
            "Audio", "Cuenta atrás", "Límite de tiempo", "Copiar a la galería",
            "Tema de color", "Fondo AMOLED", "Orientación del video",
            "Bitrate manual", "Límite de tamaño", "Protección térmica",
            "Modo claro / oscuro"};
    public static final String[] DESCS = {
            "Nativa conserva todo el detalle de tu pantalla. Menos resolución = archivo más liviano.",
            "60 se ve más fluido (juegos). 30 basta para tutoriales y pesa casi la mitad. 120, 90 y 45 dependen de tu pantalla y de tu codificador: si no los soporta, baja solo al siguiente nivel.",
            "Datos que usa el codificador por segundo. Máxima = sin pérdida visible.",
            "HEVC (H.265) da la misma calidad con ~35 % menos peso. H.264 abre en cualquier equipo. Auto usa HEVC solo si tu teléfono lo codifica por hardware; si no, H.264.",
            "Sin audio: video mudo. Micrófono: tu voz. Sonido interno: lo que suena en el teléfono (Android 10+; algunas apps lo bloquean). Interno + mic: los dos mezclados. La sincronía con la imagen es automática.",
            "Segundos de espera con animación sobre la pantalla (usa el permiso «Mostrar sobre otras apps»).",
            "Detiene la grabación sola al llegar al tiempo.",
            "Guarda una copia en Movies/GrabaPantalla al terminar, visible en la galería.",
            "Material You es automático: toma los colores de tu fondo de pantalla y sigue el modo claro / oscuro del sistema.",
            "Negro puro con bordes sutiles: ahorra batería en pantallas AMOLED. Fuerza el modo oscuro.",
            "Automática usa la orientación que tenga la pantalla cuando termina la cuenta atrás (gira el teléfono o abre tu juego antes). Horizontal es lo ideal para juegos: si no, el video queda con bandas negras.",
            "Automático calcula el bitrate según resolución, fps y calidad. Manual lo fija en Mbps: más alto = más nitidez y más peso. Si tu codificador no lo admite, se ajusta a su límite.",
            "Detiene y guarda la grabación al llegar a ese tamaño, para que el archivo nunca quede dañado ni pase el límite de tu almacenamiento.",
            "Vigila la temperatura de la batería: avisa cuando el teléfono se calienta y guarda la grabación antes de que se apague o se congele.",
            "Automático sigue el modo del sistema (solo con Material You). Claro es fondo blanco, Oscuro es fondo negro. AMOLED fuerza el oscuro."};

    public static final String[] RES = {"Nativa", "1080p", "720p", "480p", "320p"};
    public static final int[] RES_PX = {0, 1080, 720, 480, 320};
    public static final String[] FPS = {"120 fps", "90 fps", "60 fps", "45 fps", "30 fps", "24 fps", "15 fps"};
    public static final int[] FPS_V = {120, 90, 60, 45, 30, 24, 15};
    public static final String[] BUF = {"Máxima", "Normal", "Baja", "Mínima"};
    public static final float[] BUF_BPP = {0.22f, 0.13f, 0.08f, 0.045f};
    public static final String[] COD = {"Auto (recomendado)", "H.264 (compatible)", "HEVC (más liviano)"};
    public static final String[] AUD = {"Sin audio", "Micrófono", "Sonido interno", "Interno + mic"};
    public static final String[] CNT = {"Sin cuenta", "3 s", "5 s", "10 s"};
    public static final int[] CNT_V = {0, 3, 5, 10};
    public static final String[] LIM = {"Sin límite", "1 min", "5 min", "10 min", "30 min", "60 min"};
    public static final int[] LIM_V = {0, 60, 300, 600, 1800, 3600};
    public static final String[] NOYES = {"No", "Sí"};
    public static final String[] ORI = {"Automática", "Vertical", "Horizontal"};
    public static final String[] BRM = {"Automático", "2 Mbps", "4 Mbps", "6 Mbps", "8 Mbps", "12 Mbps", "16 Mbps", "24 Mbps", "32 Mbps", "40 Mbps"};
    public static final int[] BRM_V = {0, 2, 4, 6, 8, 12, 16, 24, 32, 40};
    public static final String[] SIZ = {"Sin límite", "500 MB", "1 GB", "2 GB", "4 GB"};
    public static final int[] SIZ_V = {0, 500, 1000, 2000, 4000};
    public static final String[] MOD = {"Automático", "Claro", "Oscuro"};

    // textos de la página de audio del tutorial (mismo orden que AUD)
    public static final String[] AUD_TITLE = {"Sin audio", "Solo micrófono", "Sonido del teléfono", "Teléfono + micrófono"};
    public static final String[] AUD_DESC = {
            "Video mudo. Lo más liviano.",
            "Graba tu voz. Ideal para tutoriales o comentar mientras juegas.",
            "Graba lo que suena en el teléfono: juego, música, videos. Requiere Android 10 o más.",
            "El sonido del teléfono y tu voz, juntos. Ideal para gameplay con comentarios."};
    public static final int[] AUD_ICON = {IconView.MICOFF, IconView.MIC, IconView.SPEAKER, IconView.SPEAKER};

    public static final String[][] OPTS = {RES, FPS, BUF, COD, AUD, CNT, LIM, NOYES, Theme.NAMES, NOYES, ORI, BRM, SIZ, NOYES, MOD};
    // 1080p, 60fps (indice 2), normal, auto, sin audio, 3s, sin limite, no, no, material you, no
    public static final int[] DEF = {1, 2, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0};

    public static final String[] PRESET_NAMES = {"Máxima calidad", "Equilibrado", "Juegos", "Ahorro", "Ultraligero"};
    public static final String[] PRESET_DESC = {"Todo el detalle · ideal para editar", "Recomendado para casi todo",
            "Resolución nativa a 60 fps: máxima fluidez", "Archivos livianos · tutoriales", "Lo más chico · para enviar rápido"};
    public static final int[] PRESET_ICON = {IconView.STAR, IconView.SCALE, IconView.GAME, IconView.LEAF, IconView.BOLT};
    // res, fps (indice de FPS_V: 2=60, 4=30, 5=24), buf, cod, bitrate (indice de BRM: 9=40, 5=12, 8=32, 3=6, 1=2 Mbps)
    public static final int[][] PRESETS = {{0, 2, 0, 0, 9}, {1, 4, 1, 0, 5}, {0, 2, 1, 0, 8}, {2, 4, 2, 0, 3}, {3, 5, 3, 0, 1}};

    /** Bitrate (Mbps) de un perfil. */
    public static int presetMbps(int p) { return BRM_V[PRESETS[p][4]]; }

    public static int get(SharedPreferences sp, int k) {
        int v = sp.getInt(KEYS[k], DEF[k]);
        if (v < 0 || v >= OPTS[k].length) v = DEF[k];
        return v;
    }

    public static void applyPreset(SharedPreferences sp, int p) {
        SharedPreferences.Editor e = sp.edit();
        for (int i = 0; i < 4; i++) e.putInt(KEYS[i], PRESETS[p][i]);
        e.putInt(KEYS[BRM_I], PRESETS[p][4]);
        e.apply();
    }

    /** MB por minuto estimados de un perfil (con el audio elegido ahora) */
    public static double mbPreset(Context c, SharedPreferences sp, int p) {
        boolean hv = hevcHw();
        int[] s = size(c, sp, PRESETS[p][0], hv);
        int br = bitrate(s[0], s[1], FPS_V[PRESETS[p][1]], PRESETS[p][2], hv)
                + (get(sp, AUD_I) > 0 ? audioRate(PRESETS[p][2]) : 0);
        return br / 8.0 * 60 / 1048576.0;
    }

    // ---------- MIS PERFILES (guardados por el usuario) ----------

    public static final String MINE_KEY = "mine";
    public static final int MINE_MAX = 6;

    /** Un perfil propio: nombre + {res, fps, buf, cod, bitrate} (indices, igual que PRESETS). */
    public static class Mine {
        public String name;
        public int[] v;
        public Mine(String name, int[] v) { this.name = name; this.v = v; }
    }

    static String cleanName(String s) {
        s = s == null ? "" : s.replaceAll("[|;\\r\\n]", " ").trim();
        return s.length() > 20 ? s.substring(0, 20).trim() : s;
    }

    public static ArrayList<Mine> mine(SharedPreferences sp) {
        ArrayList<Mine> r = new ArrayList<Mine>();
        String s = sp.getString(MINE_KEY, "");
        if (s.length() == 0) return r;
        String[] es = s.split(";");
        for (int i = 0; i < es.length && r.size() < MINE_MAX; i++) {
            String[] f = es[i].split("\\|", -1);
            if (f.length != 6) continue;
            try {
                int[] v = new int[5];
                for (int k = 0; k < 5; k++) v[k] = Integer.parseInt(f[k + 1].trim());
                if (v[0] < 0 || v[0] >= RES.length || v[1] < 0 || v[1] >= FPS.length || v[2] < 0 || v[2] >= BUF.length
                        || v[3] < 0 || v[3] >= COD.length || v[4] < 0 || v[4] >= BRM.length) continue;
                String n = cleanName(f[0]);
                if (n.length() > 0) r.add(new Mine(n, v));
            } catch (Exception e) {}
        }
        return r;
    }

    static void saveMine(SharedPreferences sp, ArrayList<Mine> l) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            Mine m = l.get(i);
            if (i > 0) b.append(';');
            b.append(m.name);
            for (int k = 0; k < 5; k++) b.append('|').append(m.v[k]);
        }
        sp.edit().putString(MINE_KEY, b.toString()).apply();
    }

    /** Valores actuales de los 5 ajustes que forman un perfil. */
    public static int[] currentVals(SharedPreferences sp) {
        return new int[]{get(sp, RES_I), get(sp, FPS_I), get(sp, BUF_I), get(sp, COD_I), get(sp, BRM_I)};
    }

    /** Guarda los ajustes actuales con ese nombre (si ya existe uno igual lo reemplaza). 1 = guardado, 0 = nombre vacio, -1 = lleno. */
    public static int addMine(SharedPreferences sp, String name) {
        name = cleanName(name);
        if (name.length() == 0) return 0;
        ArrayList<Mine> l = mine(sp);
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).name.equalsIgnoreCase(name)) { l.set(i, new Mine(name, currentVals(sp))); saveMine(sp, l); return 1; }
        }
        if (l.size() >= MINE_MAX) return -1;
        l.add(new Mine(name, currentVals(sp)));
        saveMine(sp, l);
        return 1;
    }

    public static void deleteMine(SharedPreferences sp, int i) {
        ArrayList<Mine> l = mine(sp);
        if (i < 0 || i >= l.size()) return;
        l.remove(i);
        saveMine(sp, l);
    }

    public static void applyMine(SharedPreferences sp, Mine m) {
        SharedPreferences.Editor e = sp.edit();
        e.putInt(KEYS[RES_I], m.v[0]);
        e.putInt(KEYS[FPS_I], m.v[1]);
        e.putInt(KEYS[BUF_I], m.v[2]);
        e.putInt(KEYS[COD_I], m.v[3]);
        e.putInt(KEYS[BRM_I], m.v[4]);
        e.apply();
    }

    public static boolean matchMine(SharedPreferences sp, Mine m) {
        int[] c = currentVals(sp);
        for (int k = 0; k < 5; k++) if (c[k] != m.v[k]) return false;
        return true;
    }

    /** "12 Mbps" o "Auto" cuando el bitrate es automatico. */
    public static String mbpsText(int[] v) { return BRM_V[v[4]] > 0 ? BRM_V[v[4]] + " Mbps" : "Auto"; }

    public static int matchPreset(SharedPreferences sp) {
        for (int p = 0; p < PRESETS.length; p++) {
            boolean ok = get(sp, BRM_I) == PRESETS[p][4];
            for (int i = 0; i < 4 && ok; i++) ok = get(sp, i) == PRESETS[p][i];
            if (ok) return p;
        }
        return -1;
    }

    // ---------- capacidades REALES del codificador del equipo ----------

    static class Enc {
        MediaCodecInfo.VideoCapabilities vc;
        boolean hw, cbr;
        String name;
        MediaCodecInfo.CodecProfileLevel[] pl;
    }

    static final HashMap<String, Enc> ENC = new HashMap<String, Enc>();

    static boolean soft(String n) {
        n = n.toLowerCase(Locale.US);
        return n.startsWith("omx.google.") || n.startsWith("c2.android.") || n.contains(".sw.");
    }

    /** Primer codificador de hardware para ese tipo (si no hay, el de software). Es el que usa el grabador. */
    static Enc enc(boolean hevc) {
        String mime = hevc ? "video/hevc" : "video/avc";
        Enc cached = ENC.get(mime);
        if (cached != null) return cached;
        Enc r = new Enc();
        if (!hevc || Build.VERSION.SDK_INT >= 24) {
            try {
                MediaCodecInfo[] all = new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos();
                MediaCodecInfo.VideoCapabilities swCaps = null;
                String swName = null;
                boolean swCbr = false;
                MediaCodecInfo.CodecProfileLevel[] swPl = null;
                for (int i = 0; i < all.length && r.vc == null; i++) {
                    if (!all[i].isEncoder()) continue;
                    String[] t = all[i].getSupportedTypes();
                    for (int j = 0; j < t.length; j++) {
                        if (!t[j].equalsIgnoreCase(mime)) continue;
                        MediaCodecInfo.CodecCapabilities cc = all[i].getCapabilitiesForType(mime);
                        MediaCodecInfo.VideoCapabilities v = cc.getVideoCapabilities();
                        if (v == null) continue;
                        boolean cb = false;
                        try { cb = cc.getEncoderCapabilities().isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR); } catch (Throwable x) {}
                        if (soft(all[i].getName())) { if (swCaps == null) { swCaps = v; swName = all[i].getName(); swCbr = cb; swPl = cc.profileLevels; } }
                        else { r.vc = v; r.hw = true; r.name = all[i].getName(); r.cbr = cb; r.pl = cc.profileLevels; }
                        break;
                    }
                }
                if (r.vc == null && swCaps != null) { r.vc = swCaps; r.hw = false; r.name = swName; r.cbr = swCbr; r.pl = swPl; }
            } catch (Throwable e) { r.vc = null; }
        }
        ENC.put(mime, r);
        return r;
    }

    /** Nombre del codificador elegido (hardware primero) o null si no se pudo saber. */
    public static String encName(boolean hevc) { return enc(hevc).name; }

    /** true si ese codificador admite bitrate constante (CBR). */
    public static boolean cbrOk(boolean hevc) { return enc(hevc).cbr; }

    /**
     * Nivel H.264 (perfil High) que corresponde a ese tamaño y fps, solo si el codificador lo declara.
     * 0 = que el codificador decida solo. Declarar el nivel real evita que un codificador asuma un nivel bajo
     * (4.0) y se ahogue en 1080p a 60/90/120 fps.
     */
    public static int avcLevel(int w, int h, int fps) {
        Enc e = enc(false);
        if (e.pl == null) return 0;
        int mbs = ((w + 15) / 16) * ((h + 15) / 16);
        long mbps = (long) mbs * fps;
        int[][] t = {
                {MediaCodecInfo.CodecProfileLevel.AVCLevel31, 108000, 3600},
                {MediaCodecInfo.CodecProfileLevel.AVCLevel32, 216000, 5120},
                {MediaCodecInfo.CodecProfileLevel.AVCLevel4, 245760, 8192},
                {MediaCodecInfo.CodecProfileLevel.AVCLevel42, 522240, 8704},
                {MediaCodecInfo.CodecProfileLevel.AVCLevel5, 589824, 22080},
                {MediaCodecInfo.CodecProfileLevel.AVCLevel51, 983040, 36864},
                {MediaCodecInfo.CodecProfileLevel.AVCLevel52, 2073600, 36864}};
        for (int i = 0; i < t.length; i++) {
            if (mbps > t[i][1] || mbs > t[i][2]) continue;
            for (int k = 0; k < e.pl.length; k++) {
                if (e.pl[k].profile == MediaCodecInfo.CodecProfileLevel.AVCProfileHigh && e.pl[k].level >= t[i][0]) return t[i][0];
            }
            return 0;
        }
        return 0;
    }

    public static boolean hasHevc() { return Build.VERSION.SDK_INT >= 24 && enc(true).vc != null; }

    static boolean hevcHw() { return Build.VERSION.SDK_INT >= 24 && enc(true).vc != null && enc(true).hw; }

    /** Auto: HEVC solo si el telefono lo codifica por hardware (en gama baja el de software no aguanta). */
    public static boolean useHevc(SharedPreferences sp) {
        if (Build.VERSION.SDK_INT < 24) return false;
        int c = get(sp, COD_I);
        if (c == 1) return false;
        if (c == 2) return hasHevc();
        return hevcHw();
    }

    static boolean supports(MediaCodecInfo.VideoCapabilities vc, int w, int h) {
        if (vc == null) return true;
        try { return vc.isSizeSupported(w, h); } catch (Throwable e) { return true; }
    }

    /** true si el codificador declara que aguanta ese tamano a esos fps (o si no se puede saber) */
    public static boolean rateOk(int w, int h, int fps, boolean hevc) {
        MediaCodecInfo.VideoCapabilities vc = enc(hevc).vc;
        if (vc == null) return true;
        try { return vc.areSizeAndRateSupported(w, h, fps); } catch (Throwable e) { return true; }
    }

    /** Hz reales de la pantalla ahora mismo (un video no puede tener mas fotogramas distintos que esto) */
    public static int refreshHz(Context c) {
        try {
            return Math.round(((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRefreshRate());
        } catch (Throwable e) { return 60; }
    }

    static int up(int v, int a) { return ((v + a - 1) / a) * a; }

    /**
     * {ancho, alto, dpi} REALES a grabar. Respeta la proporcion de la pantalla, usa la alineacion
     * que pide el codificador (2 o 16 px, sin forzar 16 siempre) y, si el tamano no lo soporta el equipo,
     * baja de a poco en vez de fallar.
     */
    public static int[] size(Context c, int resIdx, int ori, boolean hevc) {
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        int sw = dm.widthPixels, sh = dm.heightPixels;
        if ((ori == 1 && sw > sh) || (ori == 2 && sw < sh)) { int t = sw; sw = sh; sh = t; }
        int shortSide = Math.min(sw, sh);
        int target = RES_PX[resIdx];
        double k = target > 0 ? (double) target / shortSide : 1.0;   // tambien sube: en 720p, "1080p" graba a 1080p

        MediaCodecInfo.VideoCapabilities vc = enc(hevc).vc;
        int wa = 2, ha = 2;
        if (vc != null) {
            try { wa = Math.max(2, vc.getWidthAlignment()); ha = Math.max(2, vc.getHeightAlignment()); } catch (Throwable e) {}
        }
        int w = up((int) Math.round(sw * k), wa);
        int h = up((int) Math.round(sh * k), ha);
        int guard = 0;
        while (guard++ < 40 && !supports(vc, w, h) && Math.min(w, h) > 64) {
            k *= 0.94;
            w = up((int) Math.round(sw * k), wa);
            h = up((int) Math.round(sh * k), ha);
        }
        int dpi = Math.max(72, (int) Math.round(dm.densityDpi * (double) w / sw));
        return new int[]{w, h, dpi};
    }

    public static int[] size(Context c, SharedPreferences sp, int resIdx, boolean hevc) {
        return size(c, resIdx, get(sp, ORI_I), hevc);
    }

    public static int bitrate(int w, int h, int fps, int buf, boolean hevc) {
        double b = (double) w * h * fps * BUF_BPP[buf];
        if (hevc) b *= 0.6;
        if (b < 250000) b = 250000;
        if (b > 40000000) b = 40000000;
        MediaCodecInfo.VideoCapabilities vc = enc(hevc).vc;
        if (vc != null) {
            try {
                Range<Integer> r = vc.getBitrateRange();
                if (b > r.getUpper().intValue()) b = r.getUpper().intValue();
                if (b < r.getLower().intValue()) b = r.getLower().intValue();
            } catch (Throwable e) {}
        }
        return (int) b;
    }

    /** Bitrate real a usar: el manual (Mbps) si se eligio, si no el calculado. Siempre dentro del limite del codificador. */
    public static int bitrateFor(SharedPreferences sp, int w, int h, int fps, int buf, boolean hevc) {
        int mbps = BRM_V[get(sp, BRM_I)];
        if (mbps <= 0) return bitrate(w, h, fps, buf, hevc);
        double b = mbps * 1000000.0;
        MediaCodecInfo.VideoCapabilities vc = enc(hevc).vc;
        if (vc != null) {
            try {
                Range<Integer> r = vc.getBitrateRange();
                if (b > r.getUpper().intValue()) b = r.getUpper().intValue();
                if (b < r.getLower().intValue()) b = r.getLower().intValue();
            } catch (Throwable e) {}
        }
        return (int) b;
    }

    public static int audioRate(int buf) { return buf == 0 ? 128000 : (buf >= 2 ? 64000 : 96000); }

    /** MB por minuto estimados (maximo; si la pantalla esta quieta pesa menos) */
    public static double mbPerMin(Context c, SharedPreferences sp) {
        int[] s = size(c, sp, get(sp, RES_I), useHevc(sp));
        int br = bitrateFor(sp, s[0], s[1], FPS_V[get(sp, FPS_I)], get(sp, BUF_I), useHevc(sp))
                + (get(sp, AUD_I) > 0 ? audioRate(get(sp, BUF_I)) : 0);
        return br / 8.0 * 60 / 1048576.0;
    }

    public static String summary(Context c, SharedPreferences sp) {
        int[] s = size(c, sp, get(sp, RES_I), useHevc(sp));
        return s[0] + "×" + s[1] + " · " + FPS_V[get(sp, FPS_I)] + " fps · " + (useHevc(sp) ? "HEVC" : "H.264");
    }

    /** Avisos utiles sobre la configuracion actual (null si todo esta bien). */
    public static String hint(Context c, SharedPreferences sp) {
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        int shortSide = Math.min(dm.widthPixels, dm.heightPixels);
        StringBuilder b = new StringBuilder();
        int target = RES_PX[get(sp, RES_I)];
        if (target > shortSide + 8)
            b.append("• ").append(target).append("p es más grande que tu pantalla (").append(shortSide)
                    .append("): se escala hacia arriba, no gana detalle y el archivo pesa más.\n");
        int hz = refreshHz(c), fps = FPS_V[get(sp, FPS_I)];
        if (fps > hz + 1)
            b.append("• Tu pantalla va a ").append(hz).append(" Hz: más de ").append(hz).append(" fps no agrega fotogramas reales.\n");
        int[] hs = size(c, sp, get(sp, RES_I), useHevc(sp));
        if (fps > 30 && !rateOk(hs[0], hs[1], fps, useHevc(sp)))
            b.append("• Tu codificador no declara que aguante ").append(hs[0]).append("×").append(hs[1]).append(" a ").append(fps)
                    .append(" fps: puede ir a tirones. Si pasa, baja los fps o la resolución.\n");
        if (get(sp, AUD_I) >= 2 && Build.VERSION.SDK_INT < 29)
            b.append("• El sonido interno requiere Android 10: se usará el micrófono.\n");
        if (lowEnd(c) && fps > 30 && (target == 0 || target >= 1080))
            b.append("• Tu equipo es de gama baja: a ").append(target == 0 ? "resolución nativa" : "1080p").append(" y ").append(fps)
                    .append(" fps el juego puede ir con lag. Lo ideal aquí es 720p a 30 fps (perfil Ahorro).\n");
        int ori = get(sp, ORI_I);
        boolean portrait = dm.widthPixels < dm.heightPixels;
        if (ori == 2 && portrait) b.append("• Grabarás en horizontal con el teléfono en vertical: el contenido quedará con bandas negras.\n");
        if (ori == 1 && !portrait) b.append("• Grabarás en vertical con el teléfono en horizontal: el contenido quedará con bandas negras.\n");
        if (get(sp, COD_I) == 2 && !hasHevc()) b.append("• Tu equipo no tiene codificador HEVC: se usará H.264.\n");
        if (BRM_V[get(sp, BRM_I)] >= 24 && fps <= 30)
            b.append("• Con ").append(BRM_V[get(sp, BRM_I)]).append(" Mbps a ").append(fps).append(" fps el archivo pesará mucho sin ganar casi nada.\n");
        if (b.length() == 0) return null;
        return b.toString().trim();
    }

    static String capLine(String name, boolean hevc) {
        Enc e = enc(hevc);
        if (e.vc == null) return name + ": no disponible";
        String r = name + " (" + (e.hw ? "hardware" : "software") + "): ";
        try {
            int mw = e.vc.getSupportedWidths().getUpper().intValue(), mh = e.vc.getSupportedHeights().getUpper().intValue();
            r += "hasta " + Math.max(mw, mh) + "×" + Math.min(mw, mh);
            try {
                r += " · " + e.vc.getSupportedFrameRatesFor(1920, 1080).getUpper().intValue() + " fps a 1080p";
            } catch (Throwable x) {
                r += " · " + e.vc.getSupportedFrameRates().getUpper().intValue() + " fps";
            }
            r += " · hasta " + (e.vc.getBitrateRange().getUpper().intValue() / 1000000) + " Mbps";
        } catch (Throwable x) {}
        return r;
    }

    /** Informe de lo que el equipo puede grabar de verdad. */
    public static String deviceReport(Context c) {
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        return "Pantalla: " + dm.widthPixels + "×" + dm.heightPixels + " · " + refreshHz(c) + " Hz\n"
                + capLine("H.264", false) + "\n"
                + (Build.VERSION.SDK_INT >= 24 ? capLine("HEVC", true) : "HEVC: requiere Android 7")
                + "\nSonido interno: " + (Build.VERSION.SDK_INT >= 29 ? "disponible" : "requiere Android 10");
    }

    /** true si este equipo puede grabar ese perfil con TODOS sus numeros: tamano y fps que declara el codificador,
     *  fps que da la pantalla y bitrate dentro del limite del codificador. */
    public static boolean presetFits(Context c, int p) {
        int[] s = size(c, PRESETS[p][0], 0, false);
        int fps = FPS_V[PRESETS[p][1]];
        if (!rateOk(s[0], s[1], fps, false)) return false;
        if (fps > refreshHz(c) + 1) return false;
        MediaCodecInfo.VideoCapabilities vc = enc(false).vc;
        if (vc != null) {
            try { if (presetMbps(p) * 1000000L > vc.getBitrateRange().getUpper().intValue()) return false; } catch (Throwable e) {}
        }
        return true;
    }

    /** Texto con los numeros reales de un perfil: "1080p · 30 fps · 12 Mbps". */
    public static String presetNums(int p) {
        return RES[PRESETS[p][0]] + " · " + FPS_V[PRESETS[p][1]] + " fps · " + presetMbps(p) + " Mbps";
    }

    /** Perfil recomendado para este equipo (indice de PRESETS): el mejor que el equipo aguanta completo. */
    public static int recommended(Context c) {
        Enc e = enc(false);
        if (e.vc == null || !e.hw) return 4;                                   // Ultraligero
        int[] s1080 = size(c, 1, 0, false);
        if (presetFits(c, 1) && rateOk(s1080[0], s1080[1], 60, false)) return 1;   // Equilibrado (1080p30 y aguanta 60)
        if (presetFits(c, 3)) return 3;                                        // Ahorro (720p30)
        return 4;
    }

    // ---------- equipo de gama baja ----------

    static Boolean LOW;

    /** true si el equipo es modesto (poca RAM, pocos núcleos o sin codificador por hardware): se usan valores más ligeros. */
    public static boolean lowEnd(Context c) {
        if (LOW != null) return LOW.booleanValue();
        boolean low = false;
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= 19 && am.isLowRamDevice()) low = true;
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            if (mi.totalMem > 0 && mi.totalMem < 3400L * 1048576L) low = true;
        } catch (Throwable e) {}
        try { if (Runtime.getRuntime().availableProcessors() <= 4) low = true; } catch (Throwable e) {}
        try { if (!enc(false).hw) low = true; } catch (Throwable e) {}
        LOW = Boolean.valueOf(low);
        return low;
    }

    /**
     * Compensación AUTOMÁTICA (ms) para el sonido interno: se captura en el mezclador, un poco antes de que
     * salga por la bocina, así que se retrasa lo que tarda en salir (estimado con el búfer de salida del equipo).
     */
    public static int autoAudioMs(Context c) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int fpb = Integer.parseInt(am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER));
            int sr = Integer.parseInt(am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE));
            if (fpb <= 0 || sr <= 0) return 20;
            int ms = Math.round(fpb * 2000f / sr);
            return Math.max(10, Math.min(40, ms));
        } catch (Throwable e) {
            return 20;
        }
    }

    public static File dir(Context c) {
        File d = c.getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        if (d == null) d = new File(c.getFilesDir(), "Movies");
        d.mkdirs();
        return d;
    }

    public static String mb(double v) { return String.format(Locale.US, "%.0f", v); }
}
