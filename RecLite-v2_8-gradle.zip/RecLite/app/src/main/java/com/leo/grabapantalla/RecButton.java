package com.leo.grabapantalla;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/**
 * Boton grande de grabar. Dibujado a mano:
 *  - listo: circulo del color principal con un punto (respira suave)
 *  - grabando: el punto se transforma en cuadrado y salen ondas rojas
 *  - en pausa: sin ondas
 */
public class RecButton extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    RectF rf = new RectF();
    float morph, ring;
    int mode;
    ValueAnimator ringAnim, morphAnim;

    public RecButton(Context c) { super(c); }

    /** 0 = listo, 1 = grabando, 2 = en pausa */
    public void setMode(int m, boolean animate) {
        mode = m;
        float to = m == 0 ? 0f : 1f;
        if (morphAnim != null) morphAnim.cancel();
        if (!animate) { morph = to; invalidate(); return; }
        morphAnim = ValueAnimator.ofFloat(morph, to);
        morphAnim.setDuration(340);
        morphAnim.setInterpolator(new DecelerateInterpolator(1.6f));
        morphAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator a) {
                morph = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        morphAnim.start();
    }

    @Override protected void onWindowVisibilityChanged(int vis) {
        super.onWindowVisibilityChanged(vis);
        if (vis != VISIBLE) { if (ringAnim != null) ringAnim.cancel(); ringAnim = null; }
        else if (ringAnim == null && isAttachedToWindow()) startRing();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startRing();
    }

    void startRing() {
        if (ringAnim != null) ringAnim.cancel();
        ringAnim = ValueAnimator.ofFloat(0f, 1f);
        ringAnim.setDuration(2400);
        ringAnim.setInterpolator(new LinearInterpolator());
        ringAnim.setRepeatCount(ValueAnimator.INFINITE);
        ringAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator a) {
                float nr = ((int) ((Float) a.getAnimatedValue() * 72)) / 72f;   // ~30 fps: menos CPU y bateria
                if (nr != ring) { ring = nr; invalidate(); }
            }
        });
        ringAnim.start();
    }

    @Override protected void onDetachedFromWindow() {
        if (ringAnim != null) ringAnim.cancel();
        if (morphAnim != null) morphAnim.cancel();
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float s = Math.min(w, h), cx = w / 2f, cy = h / 2f;
        float R0 = s * 0.30f, maxR = s * 0.5f;
        // respira suave junto con las ondas (no cuesta nada extra: ya se redibuja por las ondas)
        float R = mode == 2 ? R0 : R0 * (1f + 0.03f * (float) Math.sin(ring * 2 * Math.PI));
        float m = Math.max(0f, Math.min(1f, morph));

        // ondas
        if (mode != 2) {
            int rc = mode == 1 ? Theme.REC : Theme.PRI;
            float strength = mode == 1 ? 0.40f : 0.22f;
            p.setStyle(Paint.Style.FILL);
            for (int k = 0; k < 2; k++) {
                float t = (ring + k * 0.5f) % 1f;
                p.setColor(rc);
                p.setAlpha((int) (255 * strength * (1f - t)));
                c.drawCircle(cx, cy, R0 + (maxR - R0) * t, p);
            }
        }

        // disco central
        int busyColor = mode == 2 ? Theme.mix(Theme.REC, Theme.SURF3, 0.45f) : Theme.REC;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Theme.mix(Theme.PRI, busyColor, m));
        p.setAlpha(255);
        c.drawCircle(cx, cy, R, p);

        // icono: anillo + punto  ->  cuadrado
        int ic = Theme.mix(Theme.ON_PRI, 0xFFFFFFFF, m);
        if (m < 1f) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * 0.028f);
            p.setColor(ic);
            p.setAlpha((int) (255 * (1f - m)));
            c.drawCircle(cx, cy, R * 0.66f, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(ic);
        p.setAlpha(255);
        float hf = R * (0.36f - 0.06f * m);
        float rad = hf - (hf - R * 0.10f) * m;
        rf.set(cx - hf, cy - hf, cx + hf, cy + hf);
        c.drawRoundRect(rf, rad, rad, p);
    }
}
