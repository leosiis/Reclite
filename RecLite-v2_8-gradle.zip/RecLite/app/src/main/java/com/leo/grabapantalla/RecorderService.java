package com.leo.grabapantalla;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.StatFs;
import android.os.SystemClock;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;

public class RecorderService extends Service {

    public static final String A_STOP = "gp.stop";
    public static final String A_PAUSE = "gp.pause";
    public static volatile boolean recording, paused, starting, finishing;
    public static volatile int secs, left;
    public static volatile String info = "";
    public static volatile String live = "";
    public static volatile Runnable onChange;

    static final String CH = "gp_rec";

    Handler h = new Handler(Looper.getMainLooper());
    MediaProjection mp;
    Pipe pipe;
    File out;
    CountdownView cv;
    int amode;
    SharedPreferences sp;
    Intent data;
    int resultCode, cnt, limit;
    int recW, recH;
    boolean heatWarned;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        String a = i == null ? null : i.getAction();
        if (A_STOP.equals(a)) {
            if (recording) stopRec();
            else if (starting) cancel();
            else if (!finishing) stopSelf();
            return START_NOT_STICKY;
        }
        if (A_PAUSE.equals(a)) { togglePause(); return START_NOT_STICKY; }
        if (i == null || recording || starting || finishing) return START_NOT_STICKY;

        sp = getSharedPreferences("cfg", 0);
        resultCode = i.getIntExtra("code", 0);
        data = (Intent) i.getParcelableExtra("data");
        starting = true;
        secs = 0;
        mkChannel();
        startForeground(1, notif("Preparando…", false));
        cnt = Cfg.CNT_V[Cfg.get(sp, Cfg.CNT_I)];
        startCount();
        fire();
        return START_NOT_STICKY;
    }

    /** Con cuenta atrás: overlay animado. Si no hay permiso de overlay, cae a números en Toast. */
    void startCount() {
        if (cnt <= 0) { left = 0; fire(); h.post(beginRun); return; }
        if (showCount(cnt)) return;
        h.post(countdown);
    }

    Runnable beginRun = new Runnable() {
        public void run() { if (starting && !recording) begin(); }
    };

    /** Sin overlay: un número por segundo en Toast (como antes). */
    Runnable countdown = new Runnable() {
        public void run() {
            if (!starting) return;
            if (cnt > 0) {
                left = cnt;
                fire();
                Pill.show(RecorderService.this, "" + cnt, false);
                cnt--;
                h.postDelayed(this, 1000);
            } else {
                left = 0;
                fire();
                begin();
            }
        }
    };

    boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    /** true si el overlay se mostró y la animación está corriendo. */
    boolean showCount(int total) {
        if (!canOverlay()) return false;
        try {
            int size = (int) (180 * getResources().getDisplayMetrics().density);
            int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.CENTER;
            CountdownView v = new CountdownView(this);
            ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).addView(v, lp);
            cv = v;
            left = total;
            v.start(total, new CountdownView.Listener() {
                public void onNumber(int n) { left = n; fire(); }
                public void onFinish() {
                    left = 0;
                    fire();
                    hideCount();
                    // deja unos cuadros para que el overlay no salga en el video
                    h.postDelayed(beginRun, 180);
                }
            });
            return true;
        } catch (Throwable e) {
            hideCount();
            return false;
        }
    }

    void hideCount() {
        if (cv == null) return;
        cv.stopAnim();
        try { ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).removeView(cv); } catch (Throwable e) {}
        cv = null;
    }

    void cancel() {
        hideCount();
        h.removeCallbacksAndMessages(null);
        starting = false;
        stopForeground(true);
        stopSelf();
        fire();
    }

    void fail(String msg) {
        hideCount();
        Pill.show(this, msg, true);
        starting = false;
        if (mp != null) { try { mp.stop(); } catch (Exception e) {} mp = null; }
        stopForeground(true);
        stopSelf();
        fire();
    }

    void begin() {
        File dir = Cfg.dir(this);
        if (freeMb(dir) < 100) { fail("Poco espacio libre (menos de 100 MB)"); return; }

        try {
            MediaProjectionManager pm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mp = pm.getMediaProjection(resultCode, data);
        } catch (Exception e) { fail("No se pudo iniciar la captura"); return; }
        if (mp == null) { fail("Captura cancelada"); return; }

        mp.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                h.post(new Runnable() { public void run() { if (recording) stopRec(); } });
            }
        }, h);

        int resIdx = Cfg.get(sp, Cfg.RES_I);
        int fps = Cfg.FPS_V[Cfg.get(sp, Cfg.FPS_I)];
        int buf = Cfg.get(sp, Cfg.BUF_I);
        amode = Cfg.get(sp, Cfg.AUD_I);
        if (amode > 0 && !hasMic()) amode = 0;
        if (amode >= 2 && Build.VERSION.SDK_INT < 29) {
            amode = 1;
            Pill.show(this, "El sonido interno requiere Android 10; se usa el micrófono", true);
        }
        boolean hevc = Cfg.useHevc(sp);

        out = new File(dir, "GP_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4");

        // Intentos {resolución, fps, hevc}: primero EXACTAMENTE lo pedido (tamaño real, con la
        // alineación y límites del codificador de este equipo); si no arranca, baja de a un paso.
        ArrayList<int[]> tries = new ArrayList<int[]>();
        tries.add(new int[]{resIdx, fps, hevc ? 1 : 0});
        if (hevc) tries.add(new int[]{resIdx, fps, 0});
        for (int f = 0; f < Cfg.FPS_V.length; f++) {      // baja por escalones: 120 > 60 > 45 > 30 > 24
            int v = Cfg.FPS_V[f];
            if (v < fps && v >= 24) tries.add(new int[]{resIdx, v, 0});
        }
        for (int r = resIdx + 1; r < Cfg.RES_PX.length; r++) tries.add(new int[]{r, Math.min(fps, 30), 0});

        int[] s0 = Cfg.size(this, sp, resIdx, hevc);
        int[] s = s0;
        int usedFps = fps;
        boolean usedHevc = hevc;
        boolean ok = false;
        HashSet<String> seen = new HashSet<String>();
        for (int t = 0; t < tries.size() && !ok; t++) {
            int[] tr = tries.get(t);
            boolean hv = tr[2] == 1;
            int[] sz = Cfg.size(this, sp, tr[0], hv);
            // los escalones de abajo solo bajan: nunca grabar MAS grande que lo pedido
            if (tr[0] != resIdx && (long) sz[0] * sz[1] >= (long) s0[0] * s0[1]) continue;
            String key = sz[0] + "x" + sz[1] + "@" + tr[1] + (hv ? "h" : "a");
            if (!seen.add(key)) continue;
            // si el codificador declara que no aguanta ese tamaño/fps, no gastes el intento
            if (t > 0 && t < tries.size() - 1 && !Cfg.rateOk(sz[0], sz[1], tr[1], hv)) continue;
            ok = tryStart(sz[0], sz[1], sz[2], tr[1], buf, hv);
            if (ok) { s = sz; usedFps = tr[1]; usedHevc = hv; }
        }
        recW = s[0];
        recH = s[1];
        info = s[0] + "×" + s[1] + " · " + usedFps + " fps · " + (usedHevc ? "HEVC" : "H.264");
        if (!ok) {
            try { if (out != null) out.delete(); } catch (Exception e) {}
            fail("Este equipo no pudo iniciar la grabación");
            return;
        }
        if (s[0] != s0[0] || s[1] != s0[1] || usedFps != fps || (hevc && !usedHevc)) {
            Pill.show(this, "Tu equipo no pudo grabar como pediste. Grabando " + info, true);
        }
        int hz = Cfg.refreshHz(this);
        if (usedFps > hz + 1) {
            Pill.show(this, "Tu pantalla va a " + hz + " Hz: no habrá más de " + hz + " fotogramas reales por segundo", true);
        }

        if (pipe != null && pipe.audioNote != null) Pill.show(this, pipe.audioNote, true);
        starting = false;
        recording = true;
        paused = false;
        secs = 0;
        limit = Cfg.LIM_V[Cfg.get(sp, Cfg.LIM_I)];
        heatWarned = false;
        freeCache = 0;
        live = "";
        update(notif("Grabando", true));
        h.postDelayed(tick, 1000);
        fire();
    }

    boolean tryStart(int w, int hh, int dpi, int fps, int buf, boolean hevc) {
        Pipe.Params q = new Pipe.Params();
        q.w = w;
        q.h = hh;
        q.dpi = dpi;
        q.fps = fps;
        q.hevc = hevc;
        q.bitrate = Cfg.bitrateFor(sp, w, hh, fps, buf, hevc);
        q.amode = amode;
        q.audioRate = Cfg.audioRate(buf);
        q.maxBytes = Cfg.SIZ_V[Cfg.get(sp, Cfg.SIZ_I)] * 1048576L;
        q.autoAudioMs = Cfg.autoAudioMs(this);
        q.low = Cfg.lowEnd(this);
        q.out = out;
        Pipe pp = new Pipe(q, new Pipe.Listener() {
            public void onSizeLimit() {
                h.post(new Runnable() {
                    public void run() {
                        Pill.show(RecorderService.this, "Límite de tamaño alcanzado: grabación guardada", true);
                        if (recording) stopRec();
                    }
                });
            }
            public void onFatal() {
                h.post(new Runnable() {
                    public void run() {
                        if (recording) {
                            Pill.show(RecorderService.this, "El codificador falló: se guarda lo grabado", true);
                            stopRec();
                        }
                    }
                });
            }
        });
        if (pp.start(mp)) {
            pipe = pp;
            return true;
        }
        pp.release();
        return false;
    }

    Runnable tick = new Runnable() {
        public void run() {
            if (!recording) return;
            if (!paused) {
                secs++;
                if (limit > 0 && secs >= limit) {
                    Pill.show(RecorderService.this, "Límite de tiempo alcanzado", false);
                    stopRec();
                    return;
                }
            }
            if (secs % 5 == 0 && out != null && freeMb(out.getParentFile()) < 40) {
                Pill.show(RecorderService.this, "Sin espacio: grabación detenida", true);
                stopRec();
                return;
            }
            updLive();
            if (secs % 10 == 0 && checkHeat()) return;
            if (secs % 10 == 0) update(notif(paused ? "En pausa" : "Grabando", !paused));
            fire();
            h.postDelayed(this, 1000);
        }
    };

    static String dur(long sec) {
        if (sec >= 3600) return (sec / 3600) + " h " + ((sec % 3600) / 60) + " min";
        if (sec >= 60) return (sec / 60) + " min";
        return sec + " s";
    }

    /** Tamaño actual del archivo y cuanto tiempo mas cabe con el espacio libre (segun el ritmo real). */
    long freeCache;

    void updLive() {
        long len = out != null ? out.length() : 0;
        String r = Media.bytes(len);
        if (secs >= 5 && len > 0 && out != null) {
            if (freeCache == 0 || secs % 5 == 0) freeCache = freeMb(out.getParentFile());
            double rate = (double) len / secs;
            double room = Math.max(0L, freeCache - 40L) * 1048576.0;
            r += " · caben ~" + dur((long) (room / rate)) + " más";
        }
        live = r;
    }

    /** true si detuvo la grabacion por calor extremo o bateria casi vacia. */
    boolean checkHeat() {
        if (sp == null || Cfg.get(sp, Cfg.PRO_I) != 1) return false;
        try {
            Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b == null) return false;
            float temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 100);
            int plug = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            String tt = String.format(Locale.US, "%.0f", temp);
            if (temp >= 48f) {
                Pill.show(this, "El teléfono está a " + tt + " °C: grabación guardada para protegerlo", true);
                stopRec();
                return true;
            }
            if (lvl <= 3 && plug == 0) {
                Pill.show(this, "Batería casi vacía: grabación guardada", true);
                stopRec();
                return true;
            }
            if (temp >= 44f && !heatWarned) {
                heatWarned = true;
                if (pipe != null) pipe.setBitrateScale(0.6f);   // menos datos = menos trabajo y menos calor, sin cortar la grabación
                Pill.show(this, "El teléfono se está calentando (" + tt + " °C): bajé la calidad un poco para que no se trabe", true);
            } else if (temp < 41f && heatWarned) {
                heatWarned = false;
                if (pipe != null) pipe.setBitrateScale(1f);
            }
        } catch (Throwable e) {}
        return false;
    }


    void stopRec() {
        if (!recording) return;
        recording = false;
        paused = false;
        live = "";
        h.removeCallbacksAndMessages(null);
        final Pipe pp = pipe;
        pipe = null;
        finishing = true;
        fire();
        // cerrar el archivo toma un instante: se hace fuera del hilo principal
        new Thread(new Runnable() {
            public void run() {
                final boolean ok = pp != null && pp.finish();
                final double fr = pp != null ? pp.realFps() : 0;
                h.post(new Runnable() {
                    public void run() {
                        if (mp != null) { try { mp.stop(); } catch (Exception e) {} mp = null; }
                        finishing = false;
                        realFps = fr;
                        done(ok);
                    }
                });
            }
        }, "rl-finish").start();
    }

    double realFps;

    void done(boolean ok) {
        if (!ok && out != null) out.delete();
        final String name = out != null ? out.getName() : "";
        final int pw = recW, ph = recH;
        final double rf = realFps;
        stopForeground(true);
        final Context ctx = getApplicationContext();
        if (!ok) {
            Pill.show(this, "Grabación muy corta, descartada", true);
        } else if (out != null) {
            // lee el archivo ya guardado y muestra la resolución REAL que quedó grabada
            Media.load(out, new Media.Cb() {
                public void done(Media.Info i) {
                    String t = "Guardado: " + name;
                    if (i != null && i.w > 0 && i.h > 0) {
                        t += "\n" + i.w + "×" + i.h + " (real)";
                        if (i.w != pw || i.h != ph) t += " · el equipo ajustó la resolución";
                        if (rf > 1) t += " · " + Math.round(rf) + " fps reales";
                    }
                    Pill.show(ctx, t, true);
                }
            });
        }
        if (ok && out != null && sp != null && Cfg.get(sp, Cfg.GAL_I) == 1) {
            if (Media.canExport(ctx)) {
                Media.export(ctx, out, new Media.Done() {
                    public void done(boolean r) {
                        Pill.show(ctx, r ? "Copiado a la galería" : "No se pudo copiar a la galería", false);
                    }
                });
            } else {
                Pill.show(ctx, "Sin permiso para copiar a la galería (ábrela desde la app)", true);
            }
        }
        stopSelf();
        fire();
    }

    void togglePause() {
        if (!recording || pipe == null) return;
        paused = !paused;
        pipe.setPaused(paused);
        update(notif(paused ? "En pausa" : "Grabando", !paused));
        fire();
    }

    boolean hasMic() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED;
    }

    long freeMb(File d) {
        try { return new StatFs(d.getPath()).getAvailableBytes() / 1048576L; }
        catch (Exception e) { return 9999; }
    }

    void fire() {
        Runnable r = onChange;
        if (r != null) r.run();
    }

    // ---------- notificación ----------

    void mkChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "Grabación", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    PendingIntent pi(String action, int code) {
        Intent i = new Intent(this, RecorderService.class);
        i.setAction(action);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getService(this, code, i, fl);
    }

    Notification notif(String text, boolean chrono) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        int ic = getResources().getIdentifier("ic_stat", "drawable", getPackageName());
        b.setSmallIcon(ic != 0 ? ic : android.R.drawable.ic_menu_camera);
        if (Build.VERSION.SDK_INT >= 21) b.setColor(0xFFD0BCFF);
        b.setContentTitle("RecLite");
        b.setContentText(recording && info.length() > 0 ? text + " · " + info + (live.length() > 0 ? " · " + live : "") : text);
        b.setOngoing(true);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        b.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), fl));
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, recording ? "Detener" : "Cancelar", pi(A_STOP, 1));
        if (recording) {
            b.addAction(android.R.drawable.ic_media_pause, paused ? "Reanudar" : "Pausar", pi(A_PAUSE, 2));
        }
        if (chrono) {
            b.setUsesChronometer(true);
            b.setShowWhen(true);
            b.setWhen(System.currentTimeMillis() - secs * 1000L);
        }
        return b.build();
    }

    void update(Notification n) {
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(1, n);
    }

    @Override public void onDestroy() {
        hideCount();
        if (recording) stopRec();
        starting = false;
        super.onDestroy();
    }
}
