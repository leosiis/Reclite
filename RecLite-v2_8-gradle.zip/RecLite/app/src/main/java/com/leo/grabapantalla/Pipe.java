package com.leo.grabapantalla;

import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTimestamp;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.view.Surface;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

/**
 * Motor de grabación propio (reemplaza a MediaRecorder + el "pegado" de audio y video al final).
 *
 *  - Video: codificador MediaCodec con superficie de entrada (la pantalla va directo al codificador, sin copias).
 *  - Audio: AudioRecord (sonido interno y/o micrófono) -> AAC.
 *  - Los dos van al MISMO MediaMuxer, con UN solo reloj (el reloj monotónico del sistema), así el audio
 *    y el video quedan sincronizados sin importar los fps y no hay que unirlos después.
 *  - El video se repite solo si la pantalla se queda quieta (nada de "pegados") y el bitrate es constante
 *    (CBR) cuando el equipo lo permite, para que no haya tirones al reproducir.
 */
public class Pipe {

    public static class Params {
        public int w, h, dpi, fps, bitrate;
        public boolean hevc;
        public int amode;          // 0 sin audio, 1 micrófono, 2 sonido interno, 3 interno + mic
        public int audioRate;      // bps AAC (mono)
        public long maxBytes;      // 0 = sin límite
        public int autoAudioMs;    // compensación automática del sonido interno (ms)
        public boolean low;        // equipo de gama baja: todo lo más liviano posible
        public File out;
    }

    public interface Listener {
        void onSizeLimit();
        void onFatal();
    }

    static class Pend {
        boolean video;
        byte[] d;
        long pts;
        int flags;
    }

    final Params p;
    final Listener lis;
    final Object lock = new Object();

    MediaCodec venc;
    Surface isurf;
    VirtualDisplay vd;
    MediaMuxer mux;
    Thread vth;
    AudioPart aud;

    int vTrack = -1, aTrack = -1;
    boolean muxStarted, needAudio, muxFailed, released;
    long vTrackAt;
    final ArrayList<Pend> pend = new ArrayList<Pend>();
    long pendBytes;

    volatile boolean paused, stopping, waitKey;
    volatile long baseUs, pausedUs, pauseAt, stopAt;
    long bytes, lastV = -1, lastA = -1;
    int vFrames;
    boolean limitFired;

    /** Mensaje para mostrar al usuario si el audio no pudo arrancar tal como lo pidió (null = todo bien). */
    public volatile String audioNote;
    /** true si el audio se está grabando. */
    public volatile boolean audioOn;

    public Pipe(Params p, Listener l) {
        this.p = p;
        this.lis = l;
    }

    static long nowUs() { return System.nanoTime() / 1000L; }

    // ------------------------------------------------------------------ arranque

    public boolean start(MediaProjection mp) {
        try {
            venc = makeVideo();
            if (venc == null) { release(); return false; }
            mux = new MediaMuxer(p.out.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            venc.start();

            if (p.amode > 0) {
                AudioPart ap = new AudioPart();
                if (ap.open(mp)) { aud = ap; needAudio = true; }
                else { ap.closeAll(); if (audioNote == null) audioNote = "No se pudo capturar el audio; se graba sin sonido"; }
            }

            baseUs = nowUs();
            vth = new Thread(videoLoop, "rl-video");
            vth.start();
            if (aud != null) {
                if (aud.begin()) audioOn = true;
                else { aud.closeAll(); aud = null; audioDied(); audioNote = "No se pudo capturar el audio; se graba sin sonido"; }
            }

            vd = mp.createVirtualDisplay("RecLite", p.w, p.h, p.dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, isurf, null, null);
            if (vd == null) throw new IllegalStateException("sin pantalla virtual");
            return true;
        } catch (Throwable e) {
            release();
            return false;
        }
    }

    /** Crea el codificador de video; si el equipo rechaza alguna opción "extra", reintenta con menos. */
    MediaCodec makeVideo() {
        String mime = p.hevc ? "video/hevc" : "video/avc";
        String name = Cfg.encName(p.hevc);
        for (int attempt = 0; attempt < 3; attempt++) {
            MediaCodec c = null;
            try {
                if (name != null) {
                    try { c = MediaCodec.createByCodecName(name); } catch (Throwable e) { c = null; }
                }
                if (c == null) c = MediaCodec.createEncoderByType(mime);
            } catch (Throwable e) {
                return null;
            }
            try {
                MediaFormat f = MediaFormat.createVideoFormat(mime, p.w, p.h);
                f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                f.setInteger(MediaFormat.KEY_BIT_RATE, p.bitrate);
                f.setInteger(MediaFormat.KEY_FRAME_RATE, p.fps);
                f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
                if (attempt < 2) {
                    // bitrate constante: evita que el codificador "se duerma" en escenas quietas y luego se ahogue
                    if (attempt == 0 && Cfg.cbrOk(p.hevc)) f.setInteger("bitrate-mode", MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR);
                    // tiempo real y a la velocidad pedida: que el codificador reserve recursos para los fps
                    f.setInteger("priority", 0);
                    f.setInteger("operating-rate", p.fps);
                    // si la pantalla se queda quieta, repite el último cuadro (el video nunca se "pega")
                    long rep = 2000000L / Math.max(1, p.fps);
                    long repMin = p.low ? 66000L : 40000L;      // en gama baja: menos cuadros repetidos = menos trabajo
                    if (rep < repMin) rep = repMin;
                    if (rep > 120000L) rep = 120000L;
                    f.setLong("repeat-previous-frame-after", rep);
                    // no entregar más fps de los pedidos (en 30 fps con pantalla de 60 Hz, mitad de trabajo)
                    if (attempt == 0) f.setFloat("max-fps-to-encoder", p.fps);
                    // perfil High con el nivel que de verdad hace falta (mejor compresión y sin límites de nivel bajo)
                    if (attempt == 0 && !p.hevc) {
                        int lv = Cfg.avcLevel(p.w, p.h, p.fps);
                        if (lv > 0) {
                            f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh);
                            f.setInteger(MediaFormat.KEY_LEVEL, lv);
                        }
                    }
                }
                c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                isurf = c.createInputSurface();
                return c;
            } catch (Throwable e) {
                try { c.release(); } catch (Throwable x) {}
                isurf = null;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ hilo de video

    final Runnable videoLoop = new Runnable() {
        public void run() {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT); } catch (Throwable e) {}
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            long vOff = Long.MIN_VALUE;
            boolean eos = false;
            int iter = 0;
            while (!eos) {
                if ((++iter & 63) == 0) checkAudioTimeout();
                int o;
                try {
                    o = venc.dequeueOutputBuffer(bi, 10000);
                } catch (Throwable e) {
                    if (!stopping && lis != null) lis.onFatal();
                    break;
                }
                if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (stopping && nowUs() - stopAt > 3500000L) break;
                    checkAudioTimeout();
                    continue;
                }
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    try { addVideoTrack(venc.getOutputFormat()); } catch (Throwable e) { muxFailed = true; }
                    continue;
                }
                if (o < 0) continue;
                try {
                    ByteBuffer ob = venc.getOutputBuffer(o);
                    boolean cfg = (bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
                    eos = (bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    if (!cfg && bi.size > 0 && ob != null) {
                        long now = nowUs();
                        if (vOff == Long.MIN_VALUE) {
                            // ¿el reloj de los cuadros es el mismo que el nuestro? si no, se traduce
                            vOff = Math.abs(bi.presentationTimeUs - now) < 3000000L ? 0L : bi.presentationTimeUs - (now - 30000L);
                        }
                        videoSample(ob, bi, vOff);
                    }
                } catch (Throwable e) {
                    muxFailed = true;
                }
                try { venc.releaseOutputBuffer(o, false); } catch (Throwable e) {}
            }
        }
    };

    void videoSample(ByteBuffer ob, MediaCodec.BufferInfo bi, long vOff) {
        if (paused) return;
        boolean key = (bi.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
        if (waitKey) {
            if (!key) return;      // tras reanudar, el primer cuadro guardado tiene que ser clave
            waitKey = false;
        }
        long t = bi.presentationTimeUs - vOff - baseUs - pausedUs;
        if (t < 0) t = 0;
        if (t <= lastV) t = lastV + 1;
        lastV = t;
        vFrames++;
        write(true, ob, bi.offset, bi.size, t, key ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0);
    }

    void addVideoTrack(MediaFormat f) {
        synchronized (lock) {
            if (vTrack >= 0 || mux == null) return;
            vTrack = mux.addTrack(f);
            vTrackAt = System.nanoTime() / 1000000L;
            tryStartMux();
        }
    }

    void addAudioTrack(MediaFormat f) {
        synchronized (lock) {
            if (aTrack >= 0 || mux == null || !needAudio) return;
            aTrack = mux.addTrack(f);
            tryStartMux();
        }
    }

    /** Si el audio muere o no llega, no dejes el video esperando: arranca solo con video. */
    void audioDied() {
        synchronized (lock) {
            if (aTrack < 0) {
                needAudio = false;
                tryStartMux();
            }
        }
        audioOn = false;
    }

    void checkAudioTimeout() {
        synchronized (lock) {
            if (!muxStarted && vTrack >= 0 && needAudio && aTrack < 0
                    && System.nanoTime() / 1000000L - vTrackAt > 3000) {
                needAudio = false;
                audioOn = false;
                if (audioNote == null) audioNote = "El audio no respondió; se graba sin sonido";
                tryStartMux();
            }
        }
    }

    /** (dentro de lock) arranca el muxer cuando están todas las pistas y vacía lo que esperaba. */
    void tryStartMux() {
        if (muxStarted || muxFailed || vTrack < 0 || (needAudio && aTrack < 0)) return;
        try {
            mux.start();
            muxStarted = true;
            for (int i = 0; i < pend.size(); i++) {
                Pend q = pend.get(i);
                if (!q.video && aTrack < 0) continue;
                put(q.video, ByteBuffer.wrap(q.d), 0, q.d.length, q.pts, q.flags);
            }
        } catch (Throwable e) {
            muxFailed = true;
        }
        pend.clear();
        pendBytes = 0;
    }

    /** Escribe una muestra (video o audio). Antes de que el muxer arranque, la guarda en una cola. */
    void write(boolean video, ByteBuffer src, int off, int size, long pts, int flags) {
        synchronized (lock) {
            if (muxFailed || released) return;
            if (!video && !needAudio) return;
            if (!muxStarted) {
                if (pendBytes + size > 32L * 1048576L) return;
                Pend q = new Pend();
                q.video = video;
                q.d = new byte[size];
                q.pts = pts;
                q.flags = flags;
                src.limit(off + size);
                src.position(off);
                src.get(q.d);
                pend.add(q);
                pendBytes += size;
                return;
            }
            put(video, src, off, size, pts, flags);
        }
    }

    final MediaCodec.BufferInfo wbi = new MediaCodec.BufferInfo();

    /** (dentro de lock, muxer ya iniciado) */
    void put(boolean video, ByteBuffer src, int off, int size, long pts, int flags) {
        try {
            src.limit(off + size);
            src.position(off);
            wbi.set(off, size, pts, flags);
            mux.writeSampleData(video ? vTrack : aTrack, src, wbi);
            bytes += size;
        } catch (Throwable e) {
            return;
        }
        if (p.maxBytes > 0 && bytes >= p.maxBytes && !limitFired) {
            limitFired = true;
            if (lis != null) lis.onSizeLimit();
        }
    }

    // ------------------------------------------------------------------ pausa

    public void setPaused(boolean pz) {
        if (pz == paused || stopping) return;
        long now = nowUs();
        if (pz) {
            pauseAt = now;
            paused = true;
        } else {
            pausedUs = pausedUs + (now - pauseAt);
            waitKey = true;
            try {
                Bundle b = new Bundle();
                b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                venc.setParameters(b);
            } catch (Throwable e) {}
            paused = false;
        }
    }

    /** Baja (o restaura) el bitrate en caliente, sin reiniciar nada. s = 1 es el bitrate pedido. */
    public void setBitrateScale(float s) {
        try {
            Bundle b = new Bundle();
            b.putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, Math.max(250000, (int) (p.bitrate * s)));
            if (venc != null && !stopping) venc.setParameters(b);
        } catch (Throwable e) {}
    }

    // ------------------------------------------------------------------ info en vivo

    public long size() { return p.out.length(); }

    /** fps reales que quedaron en el video (cuadros guardados / segundos). */
    public double realFps() {
        long t = lastV;
        return t > 1000000L ? vFrames * 1000000.0 / t : 0;
    }

    // ------------------------------------------------------------------ cierre

    /** Termina y cierra el archivo. Bloquea unos instantes: llamar fuera del hilo principal. */
    public boolean finish() {
        stopping = true;
        stopAt = nowUs();
        if (paused) { pausedUs = pausedUs + (stopAt - pauseAt); paused = false; }
        try { if (vd != null) vd.release(); } catch (Throwable e) {}
        vd = null;
        try { if (venc != null) venc.signalEndOfInputStream(); } catch (Throwable e) {}
        if (aud != null) aud.stopAndFlush();
        if (vth != null) {
            try { vth.join(4500); } catch (InterruptedException e) {}
        }
        boolean ok = false;
        synchronized (lock) {
            if (muxStarted && !muxFailed && vFrames > 0) {
                try { mux.stop(); ok = true; } catch (Throwable e) { ok = false; }
            }
            try { if (mux != null) mux.release(); } catch (Throwable e) {}
            mux = null;
            released = true;
        }
        closeVideo();
        if (aud != null) aud.closeAll();
        return ok;
    }

    void closeVideo() {
        try { if (venc != null) { venc.stop(); } } catch (Throwable e) {}
        try { if (venc != null) venc.release(); } catch (Throwable e) {}
        try { if (isurf != null) isurf.release(); } catch (Throwable e) {}
        venc = null;
        isurf = null;
    }

    /** Limpieza cuando el arranque falla (también borra el archivo a medias). */
    public void release() {
        stopping = true;
        try { if (vd != null) vd.release(); } catch (Throwable e) {}
        vd = null;
        if (aud != null) { aud.run = false; aud.closeAll(); aud = null; }
        closeVideo();
        synchronized (lock) {
            released = true;
            try { if (mux != null) mux.release(); } catch (Throwable e) {}
            mux = null;
        }
        try { p.out.delete(); } catch (Throwable e) {}
    }

    // ================================================================== audio

    /** Captura (interno y/o micrófono), mezcla, codifica a AAC y entrega al muxer con el reloj común. */
    class AudioPart implements Runnable {
        static final int FR = 1024;
        int sr = 48000, ch = 1;
        AudioRecord internal, mic, master;
        MediaCodec enc;
        Thread th;
        volatile boolean run;
        long fed, aus, skip, startTl;
        boolean micLost;

        boolean open(MediaProjection mp) {
            int[] rates = {48000, 44100};
            for (int r = 0; r < rates.length; r++) {
                sr = rates[r];
                if (tryRecords(mp) && tryEncoder()) return true;
                closeAll();
            }
            return false;
        }

        boolean tryRecords(MediaProjection mp) {
            audioNote = null;
            boolean wantInt = p.amode >= 2;
            boolean wantMic = p.amode == 1 || p.amode == 3;
            if (wantInt) {
                if (Build.VERSION.SDK_INT >= 29) {
                    try { internal = buildInternal(mp); } catch (Throwable e) { internal = null; }
                }
                if (internal != null && internal.getState() != AudioRecord.STATE_INITIALIZED) {
                    try { internal.release(); } catch (Throwable e) {}
                    internal = null;
                }
                if (internal == null) {
                    if (!wantMic) { audioNote = "No se pudo capturar el sonido interno; se graba sin audio"; return false; }
                    audioNote = "No se pudo capturar el sonido interno; se graba solo el micrófono";
                }
            }
            if (wantMic) {
                mic = buildMic();
                if (mic == null) {
                    if (internal == null) return false;
                    audioNote = "No se pudo usar el micrófono; se graba solo el sonido interno";
                }
            }
            if (internal == null && mic == null) return false;
            ch = internal != null ? 2 : 1;
            master = internal != null ? internal : mic;
            return true;
        }

        AudioRecord buildMic() {
            try {
                int min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) return null;
                AudioRecord r = new AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min * 2, sr * 2));
                if (r.getState() != AudioRecord.STATE_INITIALIZED) { r.release(); return null; }
                return r;
            } catch (Throwable e) {
                return null;
            }
        }

        /** Reflexión para no depender de que el android.jar sea API 29+ */
        AudioRecord buildInternal(MediaProjection mp) throws Exception {
            Class<?> cb = Class.forName("android.media.AudioPlaybackCaptureConfiguration$Builder");
            Object b = cb.getConstructor(MediaProjection.class).newInstance(mp);
            java.lang.reflect.Method add = cb.getMethod("addMatchingUsage", int.class);
            add.invoke(b, AudioAttributes.USAGE_MEDIA);
            add.invoke(b, AudioAttributes.USAGE_GAME);
            add.invoke(b, AudioAttributes.USAGE_UNKNOWN);
            Object cfg = cb.getMethod("build").invoke(b);
            AudioRecord.Builder ab = new AudioRecord.Builder();
            AudioRecord.Builder.class.getMethod("setAudioPlaybackCaptureConfig", Class.forName("android.media.AudioPlaybackCaptureConfiguration")).invoke(ab, cfg);
            ab.setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build());
            int min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            ab.setBufferSizeInBytes(Math.max(min * 2, sr * 4));
            return ab.build();
        }

        boolean tryEncoder() {
            try {
                MediaFormat f = MediaFormat.createAudioFormat("audio/mp4a-latm", sr, ch);
                f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                f.setInteger(MediaFormat.KEY_BIT_RATE, ch == 2 ? p.audioRate + 32000 : p.audioRate);
                f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
                enc = MediaCodec.createEncoderByType("audio/mp4a-latm");
                enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                enc.start();
                return true;
            } catch (Throwable e) {
                try { if (enc != null) enc.release(); } catch (Throwable x) {}
                enc = null;
                return false;
            }
        }

        boolean begin() {
            try {
                if (internal != null) internal.startRecording();
                if (mic != null) mic.startRecording();
                run = true;
                th = new Thread(this, "rl-audio");
                th.start();
                return true;
            } catch (Throwable e) {
                run = false;
                return false;
            }
        }

        /** Instante (reloj común, µs) en que se capturó el cuadro 0 de la grabación, o -1 si el equipo no lo da. */
        long frame0Us() {
            if (Build.VERSION.SDK_INT < 24) return -1;
            return Ts.frame0(master, sr);
        }

        public void run() {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO); } catch (Throwable e) {}
            short[] in = new short[FR * ch];
            short[] mc = new short[FR];
            short[] sil = new short[FR * ch];
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            long total = 0;
            boolean anchored = false;
            long refLag = Long.MIN_VALUE, winMin = Long.MAX_VALUE, winStart = 0;
            boolean lagReset = true;
            try {
                while (run) {
                    int n = master.read(in, 0, FR * ch);
                    if (n < 0) { if (run) { audioDied(); } break; }
                    if (n == 0) continue;
                    int frames = n / ch;
                    long tRead = nowUs();
                    total += frames;
                    if (internal != null && mic != null) {
                        int mn = mic.read(mc, 0, frames);
                        if (mn < 0) mn = 0;
                        for (int i = 0; i < frames; i++) {
                            int m = i < mn ? mc[i] : 0;
                            int l = in[2 * i] + m, r = in[2 * i + 1] + m;
                            in[2 * i] = (short) Math.max(-32768, Math.min(32767, l));
                            in[2 * i + 1] = (short) Math.max(-32768, Math.min(32767, r));
                        }
                    }
                    if (!anchored) {
                        long f0 = frame0Us();
                        if (f0 < 0) f0 = tRead - total * 1000000L / sr - 30000L;     // sin marca de tiempo: estimación
                        startTl = f0 - baseUs + (internal != null ? p.autoAudioMs * 1000L : 0L);
                        if (startTl < 0) {
                            skip = (-startTl) * sr / 1000000L;       // audio anterior al inicio del video: se descarta
                            startTl = 0;
                        }
                        anchored = true;
                    }
                    int off = 0;
                    if (skip > 0) {
                        int s = (int) Math.min(skip, (long) frames);
                        skip -= s;
                        off = s;
                    }
                    if (paused || stopping) {
                        lagReset = true;
                        continue;
                    }
                    if (frames - off > 0) {
                        feed(in, off * ch, (frames - off) * ch, bi);
                    }
                    if (skip > 0 || fed == 0) {          // todavía descartando el audio previo: no medir
                        lagReset = true;
                        continue;
                    }

                    // --- vigilancia de desfase: si el audio se queda atrás (huecos) se rellena con silencio ---
                    long tl = tRead - baseUs - pausedUs;
                    long lag = tl - (startTl + fed * 1000000L / sr);
                    if (lagReset) { lagReset = false; winMin = Long.MAX_VALUE; winStart = tRead; }
                    if (lag < winMin) winMin = lag;
                    if (tRead - winStart >= 1000000L) {
                        if (refLag == Long.MIN_VALUE) {
                            refLag = winMin;
                        } else {
                            long d = winMin - refLag;
                            if (d > 120000L) {
                                long miss = d * sr / 1000000L;
                                while (miss > 0 && run) {
                                    int c = (int) Math.min(miss, (long) FR);
                                    feed(sil, 0, c * ch, bi);
                                    miss -= c;
                                }
                            } else if (d < -120000L) {
                                skip += (-d) * sr / 1000000L;
                            }
                        }
                        winMin = Long.MAX_VALUE;
                        winStart = tRead;
                        lagReset = true;
                    }
                }
                // fin: vaciar el codificador
                int idx = -1;
                for (int k = 0; k < 40 && idx < 0; k++) {
                    idx = enc.dequeueInputBuffer(10000);
                    if (idx < 0) drain(bi, false);
                }
                if (idx >= 0) enc.queueInputBuffer(idx, 0, 0, fed * 1000000L / sr, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                drain(bi, true);
            } catch (Throwable e) {
                if (aTrack < 0) audioDied();
            }
        }

        /** Pasa PCM al codificador sin perder nada: si está ocupado, vacía su salida y reintenta. */
        void feed(short[] d, int off, int cnt, MediaCodec.BufferInfo bi) {
            int tries = 0;
            while (cnt > 0) {
                int idx = enc.dequeueInputBuffer(5000);
                if (idx < 0) {
                    drain(bi, false);
                    if (++tries > 300) return;
                    continue;
                }
                ByteBuffer bb = enc.getInputBuffer(idx);
                bb.clear();
                bb.order(ByteOrder.nativeOrder());
                int n = Math.min(cnt, bb.capacity() / 2);
                n -= n % ch;
                if (n <= 0) { enc.queueInputBuffer(idx, 0, 0, 0, 0); return; }
                bb.asShortBuffer().put(d, off, n);
                enc.queueInputBuffer(idx, 0, n * 2, fed * 1000000L / sr, 0);
                fed += n / ch;
                off += n;
                cnt -= n;
                tries = 0;
            }
            drain(bi, false);
        }

        void drain(MediaCodec.BufferInfo bi, boolean untilEos) {
            int guard = 0;
            while (true) {
                int o = enc.dequeueOutputBuffer(bi, untilEos ? 10000 : 0);
                if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!untilEos || ++guard > 100) return;
                    continue;
                }
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    addAudioTrack(enc.getOutputFormat());
                    continue;
                }
                if (o < 0) continue;
                ByteBuffer ob = enc.getOutputBuffer(o);
                boolean cfg = (bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
                boolean end = (bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                if (!cfg && bi.size > 0 && ob != null) {
                    // la hora sale de contar muestras (exacto) y no de los relojes de cada paso
                    long pts = startTl + aus * 1024L * 1000000L / sr;
                    aus++;
                    if (pts <= lastA) pts = lastA + 1;
                    lastA = pts;
                    write(false, ob, bi.offset, bi.size, pts, MediaCodec.BUFFER_FLAG_KEY_FRAME);
                }
                enc.releaseOutputBuffer(o, false);
                if (end) return;
            }
        }

        void stopAndFlush() {
            run = false;
            try { if (internal != null) internal.stop(); } catch (Throwable e) {}
            try { if (mic != null) mic.stop(); } catch (Throwable e) {}
            if (th != null) {
                try { th.join(3500); } catch (InterruptedException e) {}
            }
        }

        void closeAll() {
            try { if (internal != null) internal.release(); } catch (Throwable e) {}
            try { if (mic != null) mic.release(); } catch (Throwable e) {}
            try { if (enc != null) { try { enc.stop(); } catch (Throwable x) {} enc.release(); } } catch (Throwable e) {}
            internal = null;
            mic = null;
            master = null;
            enc = null;
        }
    }

    /** Aislado para que equipos con Android < 7 nunca carguen AudioTimestamp. */
    static class Ts {
        static long frame0(AudioRecord r, int sr) {
            try {
                AudioTimestamp ts = new AudioTimestamp();
                if (r.getTimestamp(ts, AudioTimestamp.TIMEBASE_MONOTONIC) != AudioRecord.SUCCESS) return -1;
                if (ts.framePosition < 0 || ts.nanoTime <= 0) return -1;
                return ts.nanoTime / 1000L - ts.framePosition * 1000000L / sr;
            } catch (Throwable e) {
                return -1;
            }
        }
    }
}
