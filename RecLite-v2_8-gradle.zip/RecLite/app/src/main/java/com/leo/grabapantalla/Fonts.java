package com.leo.grabapantalla;

import android.content.Context;
import android.graphics.Typeface;

/** Fuente redondeada Nunito (en assets/fonts). Si no se puede cargar, usa la del sistema. */
public class Fonts {
    public static Typeface light, reg, semi, bold;
    static boolean done;

    public static void init(Context c) {
        if (done) return;
        done = true;
        light = load(c, "Light", "sans-serif-light");
        reg = load(c, "Regular", "sans-serif");
        semi = load(c, "SemiBold", "sans-serif-medium");
        bold = load(c, "Bold", "sans-serif-medium");
    }

    static Typeface load(Context c, String w, String fallback) {
        try {
            return Typeface.createFromAsset(c.getAssets(), "fonts/Nunito-" + w + ".ttf");
        } catch (Throwable e) {
            return Typeface.create(fallback, Typeface.NORMAL);
        }
    }
}
